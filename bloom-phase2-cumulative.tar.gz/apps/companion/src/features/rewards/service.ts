import {
  bloomError,
  DAILY_SMALL_WIN_LIMIT,
  POINT_AWARDS,
  REFERRAL_POINTS,
  pointsToNextRank,
  rankForPoints,
  type CorrelationId,
  type GuildId,
  type PointKind,
  type Rank,
  type UserId,
} from '@bloom/shared-types';
import type { PlatformConfig } from '@bloom/config';
import type { PointEvent, Repositories } from '@bloom/database';
import type { MessagingService } from '@bloom/discord';
import type { Logger } from '@bloom/logging';
import {
  DAY_MS,
  idempotencyKey,
  localDateIn,
  localDaysBetween,
  shiftLocalDate,
  systemClock,
  type Clock,
  type LocalDate,
} from '@bloom/utils';

/**
 * Bloom Rewards.
 *
 * The whole of the points economy lives behind this class: check-ins, shared
 * wins, balances, ranks and the leaderboard. Nothing else in Companion calls
 * `repositories.rewards` directly, which keeps every rule about what an action
 * is worth in one readable file.
 *
 * ## What this deliberately does not do
 *
 * No streak bonuses, no multipliers, no catch-up awards, no "you are on fire"
 * escalation. A streak is *displayed* because it is a true fact about someone's
 * participation, but it changes nothing about what they earn. The moment a
 * streak pays, missing a day acquires a cost, and a wellbeing community that
 * charges people for a bad week has picked the wrong incentive.
 *
 * ## Rewards can be switched off
 *
 * With `FEATURE_REWARDS=false` the community features still work — a check-in
 * is still recorded, a win is still shared — and simply pay nothing. That is a
 * more honest degradation than hiding the commands, and it means a server can
 * run Bloom's community loop without a points economy at all.
 */

export interface ReferralAwardRequest {
  readonly guildId: GuildId;
  /** The person who gets the points. Never the member who was invited. */
  readonly inviterUserId: UserId;
  readonly referredUserId: UserId;
  readonly referralId: string;
  /** The trigger's own identity, reused so a replay cannot double-pay. */
  readonly idempotencyKey: string;
  readonly correlationId?: CorrelationId | null;
}

export type ReferralAwardResult =
  | {
      readonly kind: 'paid';
      readonly pointEventId: string;
      readonly balance: number;
      /** True when this trigger had already produced the ledger row. */
      readonly alreadyPaid: boolean;
    }
  | { readonly kind: 'failed'; readonly reason: 'insufficient' };

export interface RewardsServiceOptions {
  readonly config: PlatformConfig;
  readonly repositories: Repositories;
  readonly messaging: MessagingService;
  readonly logger: Logger;
  readonly clock?: Clock;
}

export interface CheckInRequest {
  readonly guildId: GuildId;
  readonly userId: UserId;
  readonly correlationId: CorrelationId;
}

export interface RankMove {
  readonly from: Rank;
  readonly to: Rank;
}

export type CheckInResult =
  | {
      readonly kind: 'recorded';
      readonly pointsAwarded: number;
      readonly balance: number;
      readonly streak: number;
      readonly rankMove: RankMove | null;
    }
  | { readonly kind: 'already_today'; readonly streak: number };

export interface ShareWinRequest {
  readonly guildId: GuildId;
  readonly userId: UserId;
  /** Already sanitised by the command layer before it reaches here. */
  readonly description: string;
  readonly interactionId: string;
  readonly correlationId: CorrelationId;
}

export type ShareWinResult =
  | {
      readonly kind: 'shared';
      readonly pointsAwarded: number;
      readonly balance: number;
      readonly rankMove: RankMove | null;
      /** True when the win posted publicly; false when no channel is configured. */
      readonly posted: boolean;
    }
  | {
      /** Shared and posted, but past the daily cap, so it paid nothing. */
      readonly kind: 'shared_unpaid';
      readonly balance: number;
      readonly posted: boolean;
    }
  | { readonly kind: 'duplicate' };

export interface ManualAwardRequest {
  readonly guildId: GuildId;
  readonly userId: UserId;
  /** Signed. Positive is an award, negative is a correction. */
  readonly points: number;
  readonly reason: string;
  readonly actorId: UserId;
  readonly interactionId: string;
  readonly correlationId: CorrelationId;
}

export type ManualAwardResult =
  | { readonly kind: 'applied'; readonly balance: number }
  | { readonly kind: 'insufficient'; readonly balance: number }
  | { readonly kind: 'duplicate'; readonly balance: number };

export interface MemberProfile {
  readonly userId: UserId;
  readonly balance: number;
  readonly rank: Rank;
  readonly next: { readonly rank: Rank; readonly remaining: number } | null;
  readonly streak: number;
  readonly checkInsLast30Days: number;
  readonly recent: readonly PointEvent[];
  /** False when FEATURE_REWARDS is off, so the caller can say so plainly. */
  readonly rewardsEnabled: boolean;
}

/** How far back a streak is allowed to reach. Bounds the query, and no one */
/** needs to be told their streak is 400 days for it to mean something. */
const STREAK_WINDOW_DAYS = 120;

export interface AchievementAwardRequest {
  readonly guildId: GuildId;
  readonly userId: UserId;
  /** The definition key, which is what makes the payment idempotent. */
  readonly awardKey: string;
  readonly points: number;
  readonly correlationId?: CorrelationId | null;
}

export type AchievementAwardResult =
  | { readonly kind: 'paid'; readonly alreadyPaid: boolean; readonly balance: number }
  | { readonly kind: 'failed'; readonly reason: 'insufficient' };

export interface ActivityAwardRequest {
  readonly guildId: GuildId;
  readonly userId: UserId;
  /** `challenge_completion` or `event_completion`. */
  readonly kind: Extract<PointKind, 'challenge_completion' | 'event_completion'>;
  readonly points: number;
  /** Derived from the activity and member by the caller, never per attempt. */
  readonly idempotencyKey: string;
  readonly correlationId?: CorrelationId | null;
}

export type ActivityAwardResult =
  | {
      readonly kind: 'paid';
      readonly alreadyPaid: boolean;
      readonly balance: number;
      /**
       * The ledger row this payment is recorded in.
       *
       * Returned so the caller can store the link back on its own record.
       * Present on a duplicate too, and deliberately so: a retry that finds
       * the payment already made still needs the id, because the reason it
       * is retrying is usually that the link was never written.
       */
      readonly eventId: string;
    }
  | { readonly kind: 'failed'; readonly reason: 'insufficient' };

export class RewardsService {
  private readonly clock: Clock;
  private readonly logger: Logger;

  public constructor(private readonly options: RewardsServiceOptions) {
    this.clock = options.clock ?? systemClock;
    this.logger = options.logger.child({ context: { feature: 'rewards' } });
  }

  private get enabled(): boolean {
    return this.options.config.features.rewards;
  }

  /** The community's calendar date right now. */
  public today(): LocalDate {
    return localDateIn(this.clock.date(), this.options.config.runtime.timezone);
  }

  /**
   * A member marking that they showed up today.
   *
   * The database decides whether today is already claimed — the primary key on
   * `check_ins` is the once-a-day rule — so two taps a second apart cannot both
   * pay. Nothing the member writes is stored: `/checkin` records attendance,
   * not a mood log.
   */
  public async checkIn(request: CheckInRequest): Promise<CheckInResult> {
    const today = this.today();
    const before = await this.options.repositories.rewards.balance(
      request.guildId,
      request.userId,
    );

    const outcome = await this.options.repositories.rewards.recordCheckIn({
      guildId: request.guildId,
      userId: request.userId,
      localDate: today,
      points: this.enabled ? POINT_AWARDS.check_in : 0,
      correlationId: request.correlationId,
    });

    if (outcome.kind === 'already_today') {
      return {
        kind: 'already_today',
        streak: await this.streak(request.guildId, request.userId, today),
      };
    }

    const streak = await this.streak(request.guildId, request.userId, today);
    const awarded = outcome.event?.points ?? 0;

    await this.options.repositories.audit.append({
      guildId: request.guildId,
      botName: 'companion',
      event: 'rewards.check_in',
      actorId: request.userId,
      targetId: request.userId,
      severity: 'info',
      source: 'checkin',
      correlationId: request.correlationId,
      // The date and the award, never how anyone said they were feeling.
      details: { localDate: today, points: awarded, streak },
    });

    return {
      kind: 'recorded',
      pointsAwarded: awarded,
      balance: outcome.balance,
      streak,
      rankMove: rankMove(before, outcome.balance),
    };
  }

  /**
   * A member sharing something that went well.
   *
   * The text goes to the small-wins channel and nowhere else. It is not written
   * to the ledger, the audit row or the logs — a member's own words belong in
   * the place they chose to put them, and a database of everybody's good news
   * is a data-protection liability with no operational purpose.
   */
  public async shareWin(request: ShareWinRequest): Promise<ShareWinResult> {
    const rewards = this.options.repositories.rewards;

    /*
     * The claim comes before the post, and that order is the duplicate
     * prevention.
     *
     * Discord redelivers interactions, and a member can submit twice faster
     * than the first call returns. Posting first and reconciling afterwards
     * would put the same win in the channel twice while paying for it once —
     * the visible half of the failure, and the half the ledger cannot fix.
     *
     * The ledger's own idempotency key would cover the paid path, but not the
     * unpaid one: a win past the daily cap writes no ledger row and would have
     * nothing to collide with. So the claim is taken here, for every win,
     * whether or not it earns anything.
     */
    const claim = await this.options.repositories.idempotency.claim(
      idempotencyKey('rewards.small_win', request.guildId, request.interactionId),
      {
        botName: 'companion',
        operation: 'rewards.small_win',
        guildId: request.guildId,
        correlationId: request.correlationId,
      },
    );

    if (!claim.claimed) return { kind: 'duplicate' };

    const paidToday = await rewards.countKindSince(
      request.guildId,
      request.userId,
      'small_win',
      this.startOfToday(),
    );
    const withinCap = this.enabled && paidToday < DAILY_SMALL_WIN_LIMIT;

    const posted = await this.postWin(request);

    if (!withinCap) {
      /*
       * Past the cap, or rewards are off. The win was still shared — capping
       * the reward must never cap the participation, so there is no refusal
       * here and no telling-off, just no points.
       */
      return {
        kind: 'shared_unpaid',
        balance: await rewards.balance(request.guildId, request.userId),
        posted,
      };
    }

    const before = await rewards.balance(request.guildId, request.userId);
    const outcome = await rewards.award({
      guildId: request.guildId,
      userId: request.userId,
      kind: 'small_win',
      points: POINT_AWARDS.small_win,
      /*
       * Keyed on the interaction as well as the claim above. Belt and braces,
       * and cheap: the claim guards the post, this guards the payment, and the
       * two are written by different tables in different transactions.
       */
      idempotencyKey: `small_win:${request.guildId}:${request.interactionId}`,
      correlationId: request.correlationId,
    });

    if (outcome.kind === 'insufficient') {
      // Unreachable for a positive award; narrowing rather than a cast.
      throw bloomError('INVALID_INPUT', {
        operatorHint: 'A small-win award must be positive.',
      });
    }

    if (outcome.kind === 'duplicate') {
      return { kind: 'duplicate' };
    }

    await this.options.repositories.audit.append({
      guildId: request.guildId,
      botName: 'companion',
      event: 'rewards.small_win',
      actorId: request.userId,
      targetId: request.userId,
      severity: 'info',
      source: 'win',
      correlationId: request.correlationId,
      // Deliberately no description of the win. See the doc comment above.
      details: { points: outcome.event.points, posted },
    });

    return {
      kind: 'shared',
      pointsAwarded: outcome.event.points,
      balance: outcome.balance,
      rankMove: rankMove(before, outcome.balance),
      posted,
    };
  }

  /**
   * A staff award or correction.
   *
   * Lives here rather than in the command because the ledger rules are the
   * service's job: the sign decides the kind, the reason and the actor are
   * mandatory in both directions, and the audit row is written at **warn**
   * severity. Changing a member's standing in a shared economy by hand should
   * be as findable a year later as a timeout is.
   */
  public async manualAward(request: ManualAwardRequest): Promise<ManualAwardResult> {
    const outcome = await this.options.repositories.rewards.award({
      guildId: request.guildId,
      userId: request.userId,
      // The sign is the intent: a correction is not a negative award, it is an
      // adjustment, and the ledger says which it was.
      kind: request.points >= 0 ? 'manual_award' : 'adjustment',
      points: request.points,
      reason: request.reason,
      awardedBy: request.actorId,
      idempotencyKey: `manual:${request.guildId}:${request.interactionId}`,
      correlationId: request.correlationId,
    });

    if (outcome.kind === 'insufficient') {
      return { kind: 'insufficient', balance: outcome.balance };
    }
    if (outcome.kind === 'duplicate') {
      return { kind: 'duplicate', balance: outcome.balance };
    }

    await this.options.repositories.audit.append({
      guildId: request.guildId,
      botName: 'companion',
      event: request.points >= 0 ? 'rewards.manual_award' : 'rewards.adjustment',
      actorId: request.actorId,
      targetId: request.userId,
      // Warn, like every other discretionary staff action. This is quiet,
      // unilateral, and affects how a member is seen by everyone else.
      severity: 'warn',
      source: 'companion admin award',
      correlationId: request.correlationId,
      details: { points: request.points, reason: request.reason },
    });

    return { kind: 'applied', balance: outcome.balance };
  }

  /**
   * Pay a community activity completion.
   *
   * The single entry point for challenge and event rewards, and the reason
   * `CommunityService` holds no repository write path to the ledger. The
   * caller supplies the idempotency key because it owns the identity of the
   * completion; this service owns everything about how a payment is made.
   */
  public async awardActivity(
    request: ActivityAwardRequest,
  ): Promise<ActivityAwardResult> {
    if (request.points <= 0 || !Number.isInteger(request.points)) {
      throw bloomError('INVALID_INPUT', {
        operatorHint: `A community reward must be a positive whole number; got ${String(request.points)}.`,
      });
    }

    const outcome = await this.options.repositories.rewards.award({
      guildId: request.guildId,
      userId: request.userId,
      kind: request.kind,
      points: request.points,
      // Automatic kinds carry no reason and no actor; the activity id in the
      // audit row is a better record than a sentence.
      reason: null,
      awardedBy: null,
      idempotencyKey: request.idempotencyKey,
      correlationId: request.correlationId ?? null,
    });

    if (outcome.kind === 'insufficient') {
      // Unreachable: validated positive above, and the insufficient rule
      // applies only to debits. Handled rather than asserted, as elsewhere.
      return { kind: 'failed', reason: 'insufficient' };
    }

    return {
      kind: 'paid',
      alreadyPaid: outcome.kind === 'duplicate',
      balance: outcome.balance,
      eventId: outcome.event.id,
    };
  }

  /**
   * Pay the points attached to an unlocked achievement.
   *
   * The only route by which an award becomes points, and it goes through the
   * same ledger write as everything else — there is no balance to mutate and
   * no second economy here.
   *
   * The idempotency key is derived from the award rather than from the
   * attempt: `achievement:{guild}:{user}:{key}`. An award is unique per
   * member by primary key, so that string is unique per payable event, and a
   * retry after a crash between the grant and the payment collides with the
   * ledger's unique index and returns `duplicate`. Two concurrent
   * evaluations therefore produce one ledger row even if both somehow reach
   * this method.
   */
  public async awardAchievement(
    request: AchievementAwardRequest,
  ): Promise<AchievementAwardResult> {
    if (request.points <= 0) {
      throw bloomError('INVALID_INPUT', {
        operatorHint: `Achievement ${request.awardKey} asked to pay ${String(request.points)} points; achievement rewards must be positive.`,
      });
    }

    const outcome = await this.options.repositories.rewards.award({
      guildId: request.guildId,
      userId: request.userId,
      kind: 'achievement_reward',
      points: request.points,
      // The schema forbids a reason and an actor on automatic kinds; the
      // award key in the audit row is the better record anyway.
      reason: null,
      awardedBy: null,
      idempotencyKey: `achievement:${request.guildId}:${request.userId}:${request.awardKey}`,
      correlationId: request.correlationId ?? null,
    });

    if (outcome.kind === 'insufficient') {
      // Unreachable: the amount is validated positive above, and the
      // insufficient rule only applies to debits. Handled rather than
      // asserted, for the same reason as the referral path.
      return { kind: 'failed', reason: 'insufficient' };
    }

    const alreadyPaid = outcome.kind === 'duplicate';

    if (!alreadyPaid) {
      await this.options.repositories.audit.append({
        guildId: request.guildId,
        botName: 'companion',
        event: 'rewards.achievement',
        targetId: request.userId,
        // Info, not warn: a published rule applied by the platform, with no
        // staff discretion involved.
        severity: 'info',
        source: 'awards',
        correlationId: request.correlationId ?? null,
        details: { points: request.points, award: request.awardKey },
      });
    }

    return { kind: 'paid', alreadyPaid, balance: outcome.balance };
  }

  /**
   * Pay a qualified referral.
   *
   * The only way a `referral` point event is ever created. Guardian decided
   * *that* a referral earned something; this decides *what*, and it is the
   * only side of the boundary that may.
   *
   * Three things make a replay safe, and all three are load-bearing:
   *
   *   - the amount comes from REFERRAL_POINTS, not from the caller, so a
   *     malformed trigger cannot name its own price;
   *   - the idempotency key is the trigger's own identity, so a second
   *     attempt collapses onto the first ledger row instead of adding one;
   *   - `awardedBy` is null, which the schema requires for an automatic kind
   *     and which stops a referral being laundered into a staff grant.
   */
  public async awardReferral(
    request: ReferralAwardRequest,
  ): Promise<ReferralAwardResult> {
    const outcome = await this.options.repositories.rewards.award({
      guildId: request.guildId,
      userId: request.inviterUserId,
      kind: 'referral',
      points: REFERRAL_POINTS,
      // No reason text: the schema forbids one for automatic kinds, and the
      // trigger id in the audit row is a better record than a sentence.
      reason: null,
      awardedBy: null,
      idempotencyKey: request.idempotencyKey,
      correlationId: request.correlationId ?? null,
    });

    if (outcome.kind === 'insufficient') {
      /*
       * Unreachable by construction — REFERRAL_POINTS is positive and the
       * insufficient-balance rule only applies to debits — but handled rather
       * than asserted, because an unreachable branch that throws is how a
       * future negative constant becomes a crash in production.
       */
      return { kind: 'failed', reason: 'insufficient' };
    }

    const alreadyPaid = outcome.kind === 'duplicate';

    if (!alreadyPaid) {
      await this.options.repositories.audit.append({
        guildId: request.guildId,
        botName: 'companion',
        event: 'rewards.referral',
        targetId: request.inviterUserId,
        // Info: the platform applying a published rule, with no staff
        // discretion involved. Manual awards are warn because a person chose.
        severity: 'info',
        source: 'referral consumer',
        correlationId: request.correlationId ?? null,
        details: {
          points: REFERRAL_POINTS,
          referral_id: request.referralId,
          referred_user_id: request.referredUserId,
        },
      });
    }

    return {
      kind: 'paid',
      pointEventId: outcome.event.id,
      balance: outcome.balance,
      alreadyPaid,
    };
  }

  public async profile(guildId: GuildId, userId: UserId): Promise<MemberProfile> {
    const rewards = this.options.repositories.rewards;
    const today = this.today();

    const [balance, recent, dates] = await Promise.all([
      rewards.balance(guildId, userId),
      rewards.recentEvents(guildId, userId, 5),
      rewards.checkInDates(guildId, userId, shiftLocalDate(today, -STREAK_WINDOW_DAYS)),
    ]);

    const monthAgo = shiftLocalDate(today, -29);

    return {
      userId,
      balance,
      rank: rankForPoints(balance),
      next: pointsToNextRank(balance),
      streak: streakFrom(dates, today),
      checkInsLast30Days: dates.filter((date) => date >= monthAgo).length,
      recent,
      rewardsEnabled: this.enabled,
    };
  }

  /**
   * The top of the board over a rolling window.
   *
   * Takes a number of days rather than an instant, so the clock stays inside
   * this class. The command layer computing its own `since` from `Date.now()`
   * is the kind of thing that works in production and quietly returns an empty
   * board under a test clock — which is exactly how it was caught.
   */
  public leaderboard(
    guildId: GuildId,
    options: { readonly days: number; readonly limit?: number },
  ): Promise<readonly { userId: UserId; points: number; events: number }[]> {
    const since = new Date(this.clock.now() - options.days * DAY_MS);
    return Promise.resolve(
      this.options.repositories.rewards.leaderboard(guildId, {
        since,
        ...(options.limit === undefined ? {} : { limit: options.limit }),
      }),
    );
  }

  /** Midnight this morning, in the community's timezone, as an instant. */
  private startOfToday(): Date {
    const today = this.today();
    const guess = new Date(`${today}T00:00:00Z`);
    /*
     * `today` is a wall-clock date, so midnight there is not midnight UTC. Walk
     * back hour by hour until the instant lands on the previous local day, then
     * step forward one: correct in every timezone including the half-hour and
     * three-quarter-hour offsets, without a timezone database of our own.
     */
    for (let hours = -14; hours <= 14; hours += 1) {
      const candidate = new Date(guess.getTime() + hours * 3_600_000);
      if (localDateIn(candidate, this.options.config.runtime.timezone) === today) {
        return candidate;
      }
    }
    return guess;
  }

  private async streak(
    guildId: GuildId,
    userId: UserId,
    today: LocalDate,
  ): Promise<number> {
    const dates = await this.options.repositories.rewards.checkInDates(
      guildId,
      userId,
      shiftLocalDate(today, -STREAK_WINDOW_DAYS),
    );
    return streakFrom(dates, today);
  }

  private async postWin(request: ShareWinRequest): Promise<boolean> {
    const channel = this.options.config.channels.smallWins;
    if (!channel) {
      this.logger.debug(
        'rewards.win_not_posted',
        'CHANNEL_SMALL_WINS is not configured, so the win was not posted.',
      );
      return false;
    }

    try {
      await this.options.messaging.sendToChannel(request.guildId, channel, {
        content: `<@${request.userId}> shared a small win:\n> ${request.description}`,
      });
      return true;
    } catch (error) {
      /*
       * A failed post must not cost the member their points. The win happened;
       * Discord being unavailable is our problem, not theirs.
       */
      this.logger.warn(
        'rewards.win_post_failed',
        'Could not post a small win to the configured channel.',
        { error },
      );
      return false;
    }
  }
}

/** Rank before and after an award, or null when nothing changed. */
function rankMove(before: number, after: number): RankMove | null {
  const from = rankForPoints(before);
  const to = rankForPoints(after);
  return from === to ? null : { from, to };
}

/**
 * Consecutive days ending today or yesterday.
 *
 * Derived from the dates, never stored. A stored counter has to be maintained
 * by something that runs every night, and the night it does not run it starts
 * lying — which is worse than the feature not existing, because members compare
 * these with each other.
 *
 * Yesterday counts as an unbroken streak so that someone who has not checked in
 * *yet* today is not told their streak is zero at nine in the morning.
 */
export function streakFrom(dates: readonly LocalDate[], today: LocalDate): number {
  const present = new Set(dates);
  const start = present.has(today) ? today : shiftLocalDate(today, -1);
  if (!present.has(start)) return 0;

  let streak = 0;
  let cursor = start;
  while (present.has(cursor)) {
    streak += 1;
    cursor = shiftLocalDate(cursor, -1);
    // A window this wide has already stopped being a useful number.
    if (localDaysBetween(cursor, today) > STREAK_WINDOW_DAYS) break;
  }
  return streak;
}
