import type { PlatformConfig } from '@bloom/config';
import { CommandDispatcher, CommandRegistry } from '@bloom/commands';
import { Scheduler } from '@bloom/events';
import { DatabaseJobGate, JobSettingsService } from '@bloom/discord';
import { DatabaseRateLimiter, TokenBucketRateLimiter } from '@bloom/security';
import {
  createTestLogger,
  fakeInvocation,
  fakeRepositories,
  FakeChannelModerationService,
  FakeInviteQuery,
  FakeGuild,
  FakeJobLock,
  FakeMessaging,
  FakeModerationService,
  FakeRoleService,
  TEST_CHANNEL_IDS,
  TEST_GUILD_ID,
  testConfig,
  type FakeRepositories,
} from '@bloom/testing';
import type { GuardianDeps } from './deps.js';
import { OnboardingService } from './features/onboarding/service.js';
import { JoinSurveillanceService } from './features/security/service.js';
import { AutoModSignalService } from './features/security/automod.js';
import { ReferralService } from './features/referrals/service.js';
import { ModerationActionService } from './features/moderation/service.js';
import { CaseService } from './features/moderation/case-service.js';
import { guardianCommands } from './commands.js';
import { createStaleCaseSweepJob } from './features/jobs/stale-case-sweep.js';
import { createRetentionSweepJob } from './features/jobs/retention-sweep.js';

/**
 * A whole Guardian, in memory.
 *
 * Shared by the onboarding and moderation command tests because both need the
 * same thing: the *real* `CommandDispatcher` with the *real* command set, so
 * authorization is genuinely exercised. A test that called `execute` directly
 * would skip the policy layer entirely and prove nothing about who may run
 * what.
 *
 * Not in `@bloom/testing`: that package cannot depend on an app without
 * inverting the dependency graph. It lives here, excluded from the build
 * alongside the tests it serves.
 */
export interface GuardianHarness {
  readonly dispatch: (
    options: Parameters<typeof fakeInvocation>[0],
  ) => Promise<ReturnType<typeof fakeInvocation>>;
  readonly deps: GuardianDeps;
  readonly repositories: FakeRepositories;
  readonly guild: FakeGuild;
  readonly roles: FakeRoleService;
  readonly messaging: FakeMessaging;
  readonly moderation: FakeModerationService;
  readonly channels: FakeChannelModerationService;
  readonly invites: FakeInviteQuery;
  readonly logs: ReturnType<typeof createTestLogger>['sink'];
  /** The scheduler the harness built, with Guardian's real jobs registered. */
  readonly scheduler: Scheduler;
  readonly lock: FakeJobLock;
  readonly jobSettings: JobSettingsService;
}

export interface GuardianHarnessOptions {
  /**
   * Unset the reports channel, to exercise the "stored but nobody was alerted"
   * path. Explicit rather than inferred: it is a configuration mistake with
   * real consequences, so a test has to ask for it.
   */
  readonly reportsChannel?: null;
  /**
   * Unset the moderation channel, so the stale-case job has nowhere to post.
   * Exercises the "registered but disabled" path.
   */
  readonly moderationChannel?: null;
  /** Turn FEATURE_SCHEDULED_MESSAGES off. Defaults to on inside the harness. */
  readonly scheduledMessages?: false;
  /**
   * The clock the referral service reads.
   *
   * Qualification is entirely about elapsed time, so a test has to be able to
   * stand a week later without waiting one.
   */
  readonly now?: () => Date;
  /** Override anti-raid thresholds, so a test can state the numbers it means. */
  readonly raid?: Partial<PlatformConfig['security']['raid']>;
  /** Turn FEATURE_RAID_DETECTION off. Defaults to on inside the harness. */
  readonly raidDetection?: false;
  /** Turn FEATURE_AUTOMOD_SIGNALS off. Defaults to on inside the harness. */
  readonly autoModSignals?: false;
  /** Override the per-rule AutoMod alert throttle. */
  readonly autoModAlertCooldownSeconds?: number;
}

export function guardianHarness(options: GuardianHarnessOptions = {}): GuardianHarness {
  const clock = options.now ?? ((): Date => new Date('2026-01-01T12:00:00.000Z'));
  // testConfig() already configures every channel, reports included.
  const base = testConfig();
  const config: PlatformConfig = {
    ...base,
    channels: {
      ...base.channels,
      ...(options.reportsChannel === null ? { reports: null } : {}),
      ...(options.moderationChannel === null ? { moderation: null } : {}),
    },
    security: {
      ...base.security,
      raid: { ...base.security.raid, ...(options.raid ?? {}) },
      autoMod: {
        alertCooldownSeconds:
          options.autoModAlertCooldownSeconds ??
          base.security.autoMod.alertCooldownSeconds,
      },
    },
    // On by default: a harness where every job is switched off would make the
    // job tests pass without running anything.
    features: {
      ...base.features,
      scheduledMessages: options.scheduledMessages !== false,
      raidDetection: options.raidDetection !== false,
      autoModSignals: options.autoModSignals !== false,
    },
  };
  const guild = new FakeGuild().withStandardRoles();
  guild.withChannels(
    TEST_CHANNEL_IDS.welcome,
    TEST_CHANNEL_IDS.reports,
    TEST_CHANNEL_IDS.moderation,
  );

  const roles = new FakeRoleService(guild);
  const messaging = new FakeMessaging(guild);
  const moderation = new FakeModerationService(guild);
  const channels = new FakeChannelModerationService();
  /*
   * One clock for the fakes and the services. Without this the in-memory
   * rows carry the default fixture date while the service reads the test's
   * clock, and anything time-based — a referral waiting seven days — is
   * measured against two different "now"s.
   */
  const repositories = fakeRepositories({ now: () => clock() });
  const invites = new FakeInviteQuery();
  const { logger, sink } = createTestLogger();

  const lock = new FakeJobLock();
  const jobSettings = new JobSettingsService(repositories.settings, 'guardian');
  const scheduler = new Scheduler({
    bot: 'guardian',
    logger,
    timezone: config.runtime.timezone,
    lock,
    // The real gate over the fake settings repository, so a test that disables
    // a job exercises the same path production does.
    gate: new DatabaseJobGate(jobSettings, TEST_GUILD_ID),
    ...(config.features.scheduledMessages ? {} : { globallyDisabled: true }),
  });

  const deps: GuardianDeps = {
    bot: 'guardian',
    config,
    logger,
    repositories,
    scheduler,
    jobSettings,
    guilds: guild,
    invites,
    roles,
    messaging,
    discordModeration: moderation,
    channelModeration: channels,
    onboarding: new OnboardingService({
      config,
      repositories,
      roles,
      messaging,
      guilds: guild,
      logger,
    }),
    referrals: new ReferralService({
      repositories,
      guilds: guild,
      invites,
      logger,
      now: () => clock(),
    }),
    joinSurveillance: new JoinSurveillanceService({
      config,
      repositories,
      messaging,
      logger,
      now: () => clock(),
    }),
    autoModSignals: new AutoModSignalService({
      config,
      repositories,
      messaging,
      logger,
    }),
    moderation: new ModerationActionService({
      config,
      repositories,
      guilds: guild,
      discord: moderation,
      channels,
      messaging,
      logger,
    }),
    cases: new CaseService({ config, repositories, messaging, logger }),
    verifyLimiter: new DatabaseRateLimiter(
      repositories.cooldowns,
      TEST_GUILD_ID,
      'onboarding.verify',
      30,
    ),
    moderationLimiter: new TokenBucketRateLimiter({
      capacity: 10,
      refillPerSecond: 0.5,
    }),
    reportLimiter: new DatabaseRateLimiter(
      repositories.cooldowns,
      TEST_GUILD_ID,
      'moderation.report',
      60,
    ),
  };

  /*
   * The same registration `main.ts` performs, so the command tests inspect the
   * real job list rather than a fixture that can drift from it.
   */
  scheduler
    .register(createStaleCaseSweepJob(deps))
    .register(createRetentionSweepJob(deps));

  const registry = new CommandRegistry<GuardianDeps>('guardian').registerAll(
    guardianCommands,
  );

  const dispatcher = new CommandDispatcher<GuardianDeps>({
    bot: 'guardian',
    config,
    logger,
    registry,
    deps,
    telemetry: { record: () => Promise.resolve() },
  });

  return {
    async dispatch(options) {
      const fake = fakeInvocation(options);
      await dispatcher.dispatch(fake.invocation);
      return fake;
    },
    deps,
    repositories,
    guild,
    roles,
    messaging,
    moderation,
    channels,
    invites,
    logs: sink,
    scheduler,
    lock,
    jobSettings,
  };
}
