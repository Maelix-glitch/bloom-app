/**
 * Join-burst raid detection.
 *
 * A pure function over numbers. It performs no I/O, reads no clock of its
 * own, and has no dependency on Discord or the database — the service around
 * it gathers the facts, this decides what they mean. That separation is the
 * point: a security decision that can only be exercised by standing up a
 * database and a gateway is a security decision nobody will test properly,
 * and the deterministic core here can be driven through every boundary case
 * in microseconds.
 *
 * ## What it looks at, and what it refuses to look at
 *
 * Two signals, both metadata:
 *
 *   1. **Join velocity.** How many members joined inside a rolling window.
 *   2. **Account-age concentration.** What share of those joiners hold
 *      accounts created very recently.
 *
 * Nothing else. No message content, no profile text, no avatar hashes, no
 * behavioural history. Bloom does not hold the `MESSAGE_CONTENT` intent and
 * this feature is not a reason to ask for it: the two signals above are
 * derivable from a user id and a join timestamp, both of which the platform
 * already has for its own onboarding.
 *
 * ## Why both signals, joined by AND
 *
 * Either alone is a false-positive generator.
 *
 * Velocity alone fires on every organic surge — a creator's shoutout, a
 * cross-post that lands, a product launch. Those are the best days a
 * community has, and a security system that cries raid on them gets muted,
 * which is how it fails silently three months later.
 *
 * Account age alone fires on perfectly ordinary trickles. Plenty of real
 * people make an account specifically to join a server they just heard
 * about; one of them arriving is not an incident.
 *
 * It is the conjunction that is hard to produce accidentally: a sudden burst
 * of joins where most of the accounts were created days ago. That is what a
 * scripted raid looks like and what an organic surge does not.
 *
 * ## Explainability
 *
 * The assessment carries the numbers that produced it, not just a verdict.
 * A moderator reading an alert can see "14 joins in 60s, threshold 10" and
 * "11 of 14 accounts under 7 days old, threshold 50%" and decide for
 * themselves — and an operator tuning thresholds can see exactly which one
 * was too tight. A bare "RAID DETECTED" is not actionable and not auditable.
 */

/** One signal's contribution, in the terms that produced it. */
export interface RaidSignal {
  readonly name: 'join_velocity' | 'account_age_concentration';
  readonly fired: boolean;
  /** The measured value. */
  readonly observed: number;
  /** The value it had to reach. */
  readonly threshold: number;
  /** Human-readable, already resolved to the numbers. For the alert. */
  readonly detail: string;
}

export interface RaidAssessment {
  /** True only when every signal fired. */
  readonly raidSuspected: boolean;
  readonly signals: readonly RaidSignal[];
  /** Joins counted in the window. */
  readonly joinsInWindow: number;
  /** How many of the sampled accounts were newer than the age threshold. */
  readonly youngAccounts: number;
  /** How many accounts the ratio was computed over. */
  readonly sampleSize: number;
  /** The window, in seconds, the counts refer to. */
  readonly windowSeconds: number;
}

export interface RaidThresholds {
  /** Rolling window for the velocity count. */
  readonly windowSeconds: number;
  /** Joins within the window needed to fire the velocity signal. */
  readonly joinThreshold: number;
  /** An account younger than this many days counts as "young". */
  readonly youngAccountDays: number;
  /** Share of the sample that must be young, 0..1. */
  readonly youngAccountRatio: number;
}

export interface RaidEvaluationInput {
  readonly joinsInWindow: number;
  /** Account creation instants for the sampled joiners. */
  readonly sampledAccountAges: readonly Date[];
  readonly now: Date;
  readonly thresholds: RaidThresholds;
}

const MS_PER_DAY = 24 * 60 * 60 * 1000;

/**
 * Decide whether a burst of joins looks like a raid.
 *
 * Deterministic: the same inputs always produce the same assessment. There
 * is no randomness, no clock read, and no dependence on evaluation order.
 */
export function evaluateRaid(input: RaidEvaluationInput): RaidAssessment {
  const { joinsInWindow, sampledAccountAges, now, thresholds } = input;

  const velocityFired = joinsInWindow >= thresholds.joinThreshold;

  const sampleSize = sampledAccountAges.length;
  const youngCutoff = now.getTime() - thresholds.youngAccountDays * MS_PER_DAY;
  const youngAccounts = sampledAccountAges.filter(
    (createdAt) => createdAt.getTime() > youngCutoff,
  ).length;

  /*
   * An empty sample is not a raid.
   *
   * Dividing by zero would give NaN, and `NaN >= ratio` is false, so the
   * arithmetic happens to behave. Relying on that would be a trap for the
   * next person: it is stated as a rule instead.
   */
  const youngRatio = sampleSize === 0 ? 0 : youngAccounts / sampleSize;
  const concentrationFired = sampleSize > 0 && youngRatio >= thresholds.youngAccountRatio;

  const signals: readonly RaidSignal[] = [
    {
      name: 'join_velocity',
      fired: velocityFired,
      observed: joinsInWindow,
      threshold: thresholds.joinThreshold,
      detail:
        `${String(joinsInWindow)} joins in ${String(thresholds.windowSeconds)}s ` +
        `(threshold ${String(thresholds.joinThreshold)})`,
    },
    {
      name: 'account_age_concentration',
      fired: concentrationFired,
      observed: Math.round(youngRatio * 100),
      threshold: Math.round(thresholds.youngAccountRatio * 100),
      detail:
        `${String(youngAccounts)} of ${String(sampleSize)} accounts under ` +
        `${String(thresholds.youngAccountDays)} days old ` +
        `(${String(Math.round(youngRatio * 100))}%, threshold ` +
        `${String(Math.round(thresholds.youngAccountRatio * 100))}%)`,
    },
  ];

  return {
    // AND, not OR, and not a weighted score. See the note above: either
    // signal alone has a false-positive mode that would get this muted.
    raidSuspected: signals.every((signal) => signal.fired),
    signals,
    joinsInWindow,
    youngAccounts,
    sampleSize,
    windowSeconds: thresholds.windowSeconds,
  };
}
