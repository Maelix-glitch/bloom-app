import type { PlatformConfig } from '@bloom/config';
import type { GuardianRepositories } from '@bloom/database';
import type { Logger } from '@bloom/logging';
import type { MessagingService } from '@bloom/discord';
import { snowflakeCreatedAt } from '@bloom/events';
import type { CorrelationId, GuildId, UserId } from '@bloom/shared-types';
import { evaluateRaid, type RaidAssessment } from './raid-detector.js';
import { raidAlertMessage } from './messages.js';

/**
 * Join surveillance.
 *
 * Watches the rate and shape of arrivals, and tells moderators when it looks
 * wrong. It does not act. There is no path from this file to a kick, a ban,
 * a timeout, a role change or a verification state — none of those services
 * are among its dependencies, so the restraint is structural rather than a
 * promise. That is deliberate for a first release: the thresholds have never
 * been tested against a real raid, and a detector with an unmeasured false
 * positive rate must not be able to lock anybody out.
 *
 * ## Why this reads the database rather than counting in memory
 *
 * An in-process counter would be faster and would be wrong in two ways that
 * matter. It would reset on deploy — and a raid during a rolling restart is
 * not a hypothetical — and it would be per process, so two Guardian
 * instances would each see half a raid and neither would reach the
 * threshold. `guild_members.joined_at` is already written by the onboarding
 * path on every join; counting the rows that exist is both cheaper to
 * maintain and correct across restarts and instances.
 *
 * ## What it stores
 *
 * Nothing. No new table, no new column, no record of anyone's account age.
 * Account age is decoded from the user id — a Discord snowflake embeds its
 * creation timestamp — at the moment of evaluation and then discarded. The
 * platform already holds every user id it uses here for onboarding, so this
 * feature collects nothing it did not already have.
 */

export interface JoinSurveillanceOptions {
  readonly config: PlatformConfig;
  readonly repositories: GuardianRepositories;
  readonly messaging: MessagingService;
  readonly logger: Logger;
  readonly now: () => Date;
}

export interface JoinObservation {
  readonly guildId: GuildId;
  readonly userId: UserId;
  readonly isBot: boolean;
  readonly correlationId: CorrelationId;
}

/** What the service decided, for tests and for the caller's logs. */
export interface SurveillanceOutcome {
  readonly evaluated: boolean;
  readonly assessment: RaidAssessment | null;
  readonly alerted: boolean;
  readonly reason?: 'disabled' | 'bot_join' | 'no_channel' | 'throttled' | 'quiet';
}

/** Cooldown scope for the alert throttle. */
const ALERT_SCOPE = 'security.raid_alert';

/**
 * One subject per guild.
 *
 * The throttle is per guild rather than per assessment, because the thing
 * being rate-limited is "telling the moderators about this raid" and a raid
 * produces one of those per joining account. Keying it any more finely would
 * mean the alert channel absorbs the attack.
 */
const ALERT_SUBJECT = 'guild';

export class JoinSurveillanceService {
  public constructor(private readonly options: JoinSurveillanceOptions) {}

  /**
   * Evaluate a join.
   *
   * Returns rather than throws on every expected condition. The caller is the
   * member-join handler, and a member's onboarding must not fail because a
   * detector could not reach the database.
   */
  public async observeJoin(input: JoinObservation): Promise<SurveillanceOutcome> {
    const { raid } = this.options.config.security;

    if (!this.options.config.features.raidDetection) {
      return { evaluated: false, assessment: null, alerted: false, reason: 'disabled' };
    }

    /*
     * Bots do not raid.
     *
     * A bot is added by someone with Manage Guild, which is a different
     * threat with a different control. Counting bot joins towards a raid
     * would mean onboarding three integrations in a minute reads as an
     * attack.
     */
    if (input.isBot) {
      return { evaluated: false, assessment: null, alerted: false, reason: 'bot_join' };
    }

    const now = this.options.now();
    const since = new Date(now.getTime() - raid.windowSeconds * 1000);

    const [joinsInWindow, sampleIds] = await Promise.all([
      this.options.repositories.identity.countJoinsSince(input.guildId, since),
      this.options.repositories.identity.recentJoinerIds(
        input.guildId,
        since,
        JOIN_SAMPLE_SIZE,
      ),
    ]);

    const assessment = evaluateRaid({
      joinsInWindow,
      sampledAccountAges: sampleIds.map((id) => snowflakeCreatedAt(id)),
      now,
      thresholds: {
        windowSeconds: raid.windowSeconds,
        joinThreshold: raid.joinThreshold,
        youngAccountDays: raid.youngAccountDays,
        youngAccountRatio: raid.youngAccountRatio,
      },
    });

    if (!assessment.raidSuspected) {
      return { evaluated: true, assessment, alerted: false, reason: 'quiet' };
    }

    const channelId = this.options.config.channels.moderation;
    if (!channelId) {
      /*
       * Nowhere to tell anyone. Logged once per detection rather than
       * silently dropped, because "the detector is on but has no channel"
       * is a configuration mistake an operator needs to find.
       */
      this.options.logger.warn(
        'security.raid_no_channel',
        'A join pattern looked like a raid, but no moderation channel is configured.',
        { guild_id: input.guildId, context: this.explain(assessment) },
      );
      return { evaluated: true, assessment, alerted: false, reason: 'no_channel' };
    }

    /*
     * Claim the alert before writing it.
     *
     * `tryAcquire` is an atomic insert against a unique key, so a hundred
     * accounts arriving at once produce exactly one claim and one alert. The
     * audit row is written on the same branch, so the trail records alerts
     * rather than detections — a hundred audit rows for one incident would
     * bury the incident.
     */
    const claim = await this.options.repositories.cooldowns.tryAcquire(
      input.guildId,
      ALERT_SCOPE,
      ALERT_SUBJECT,
      raid.alertCooldownSeconds,
    );

    if (!claim.allowed) {
      return { evaluated: true, assessment, alerted: false, reason: 'throttled' };
    }

    await this.options.messaging.sendToChannel(
      input.guildId,
      channelId,
      raidAlertMessage(assessment, now),
    );

    /*
     * No actor: nobody did this. No `target_id` either — the alert is about
     * a pattern, and naming the member who happened to trip the threshold
     * would turn an aggregate signal into a permanent record against one
     * person who has done nothing but join.
     */
    await this.options.repositories.audit.append({
      guildId: input.guildId,
      botName: 'guardian',
      event: 'security.raid_suspected',
      severity: 'warn',
      actorId: null,
      channelId,
      source: 'security.join_surveillance',
      correlationId: input.correlationId,
      details: this.explain(assessment),
    });

    this.options.logger.warn(
      'security.raid_suspected',
      'A join pattern matched the raid heuristic; moderators have been alerted.',
      { guild_id: input.guildId, context: this.explain(assessment) },
    );

    return { evaluated: true, assessment, alerted: true };
  }

  /** Counts only. Never a member id. */
  private explain(assessment: RaidAssessment): Record<string, number | boolean> {
    return {
      joins_in_window: assessment.joinsInWindow,
      window_seconds: assessment.windowSeconds,
      young_accounts: assessment.youngAccounts,
      sample_size: assessment.sampleSize,
      velocity_fired: assessment.signals[0]?.fired ?? false,
      concentration_fired: assessment.signals[1]?.fired ?? false,
    };
  }
}

/**
 * How many recent joiners the age ratio is computed over.
 *
 * The velocity count is an aggregate and sees every join; this is only the
 * sample whose ages are decoded. Bounded because an unbounded read during a
 * raid is the detector joining in. The repository clamps to its own ceiling
 * as well, so this cannot be widened from here by accident.
 */
const JOIN_SAMPLE_SIZE = 50;
