import { noticeEmbed, type BloomMessage } from '@bloom/embeds';
import { discordTimestamp } from '@bloom/utils';
import type { AutoModActionPayload } from '@bloom/events';
import type { RaidAssessment } from './raid-detector.js';

/**
 * The raid alert.
 *
 * Addressed to moderators in the moderation channel, and written for someone
 * who has just been pulled away from something else. It states what was
 * measured, against what threshold, and what Bloom did — which is nothing.
 *
 * Three deliberate omissions:
 *
 *   • **No member is named.** The alert is about a pattern, not a person.
 *     Listing fourteen user ids invites a moderator to work down the list
 *     banning people on the strength of an account-age heuristic, which is
 *     exactly the irreversible action this feature refuses to automate. If a
 *     specific account needs acting on, it should be because a human looked
 *     at it.
 *   • **No ping.** No `@here`, no role mention. A detector with a false
 *     positive rate that nobody has measured yet does not get to wake people
 *     up. Moderators watch this channel; that is enough until the thresholds
 *     have been proven.
 *   • **No "RAID DETECTED".** It says *looks like*, because that is what a
 *     two-signal heuristic can honestly claim.
 */
export function raidAlertMessage(assessment: RaidAssessment, at: Date): BloomMessage {
  const lines = [
    `An unusual pattern of joins ${discordTimestamp(at, 'R')}.`,
    '',
    ...assessment.signals.map((signal) => `· ${signal.detail}`),
    '',
    'Bloom has taken no action. Nobody has been removed, restricted or ' +
      'flagged, and verification is unchanged.',
    '',
    'If this looks like a raid, the usual moderation tools apply. If it ' +
      'looks like a quiet afternoon, the thresholds are too tight — the ' +
      'numbers above are what to tune against.',
  ];

  return {
    embeds: [
      noticeEmbed({
        title: 'Join pattern worth a look',
        description: lines.join('\n'),
        footer: 'Detection only. No automatic enforcement.',
      }),
    ],
  };
}

/** What Discord actually did, in words a moderator does not have to decode. */
const ACTION_PHRASES: Readonly<Record<string, string>> = {
  block_message: 'blocked the message',
  send_alert_message: 'logged it to the AutoMod alert channel',
  timeout: 'timed the member out',
  block_member_interaction: 'blocked the member from interacting',
  unknown: 'took an action this version of Bloom does not recognise',
};

const TRIGGER_PHRASES: Readonly<Record<string, string>> = {
  keyword: 'a keyword rule',
  spam: 'the spam filter',
  keyword_preset: 'a preset keyword list',
  mention_spam: 'the mention limit',
  member_profile: 'a member-profile rule',
  unknown: 'a rule type this version of Bloom does not recognise',
};

/**
 * The AutoMod alert.
 *
 * What it does *not* say is the point. There is no message text, no matched
 * keyword and no quote, because Bloom never received any — the alert can
 * only be as revealing as the payload behind it, and that payload carries
 * identifiers. A moderator who needs the content has somewhere to go for it:
 * Discord's own AutoMod alert channel, where Discord put it.
 *
 * No `@here` or `@everyone`, for the same reason as the raid alert. This
 * fires on routine rule hits; a mass ping on routine events trains people to
 * mute the channel.
 */
export function autoModAlertMessage(payload: AutoModActionPayload): BloomMessage {
  const action = ACTION_PHRASES[payload.action] ?? ACTION_PHRASES['unknown'];
  const trigger = TRIGGER_PHRASES[payload.trigger] ?? TRIGGER_PHRASES['unknown'];

  const lines = [
    `Discord AutoMod ${String(action)} — ${String(trigger)} matched.`,
    '',
    `· Member: <@${payload.userId}>`,
    `· Rule: \`${payload.ruleId}\``,
    ...(payload.channelId ? [`· Channel: <#${payload.channelId}>`] : []),
    ...(payload.timeoutSeconds !== null
      ? [`· Timeout: ${String(payload.timeoutSeconds)}s, applied by Discord`]
      : []),
    `· Seen ${discordTimestamp(payload.detectedAt, 'R')}`,
    '',
    'Bloom has added nothing to this. The action above is the one Discord ' +
      'already took, and no Bloom moderation record has been opened.',
    '',
    'Bloom does not receive message content, so the text is not shown here. ' +
      "Discord's own AutoMod alert channel has it if the rule logs there.",
  ];

  return {
    embeds: [
      noticeEmbed({
        title: 'AutoMod acted',
        description: lines.join('\n'),
        footer: 'Recorded by Guardian. No Bloom enforcement applied.',
      }),
    ],
  };
}
