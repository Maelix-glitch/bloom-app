import { describe, expect, it } from 'vitest';
import { unsafeSnowflake, bloomError, type GuildId } from '@bloom/shared-types';
import { EventDispatcher, type AutoModActionPayload } from '@bloom/events';
import { createTestLogger, TEST_CHANNEL_IDS, TEST_GUILD_ID } from '@bloom/testing';
import type { GuardianDeps } from '../../deps.js';
import { guardianHarness } from '../../guardian.harness.js';
import { autoModActionHandler, autoModDedupeKey } from './handlers.js';

/**
 * The Discord AutoMod execution consumer.
 *
 * Driven through the real `EventDispatcher` wherever the behaviour under
 * test belongs to the dispatcher — ownership, deduplication and failure
 * isolation all live there, and calling `handle` directly would test a
 * version of the pipeline that does not exist in production.
 */

const RULE = '200000000000000002';
const OFFENDER = unsafeSnowflake('300000000000000003');
const MESSAGE = unsafeSnowflake('500000000000000005');

function payload(overrides: Partial<AutoModActionPayload> = {}): AutoModActionPayload {
  return {
    guildId: TEST_GUILD_ID,
    ruleId: RULE,
    trigger: 'keyword',
    action: 'block_message',
    rawActionType: 1,
    rawTriggerType: 1,
    userId: OFFENDER,
    channelId: TEST_CHANNEL_IDS.welcome,
    messageId: MESSAGE,
    alertMessageId: null,
    timeoutSeconds: null,
    detectedAt: new Date('2026-02-01T10:00:00.000Z'),
    ...overrides,
  } as AutoModActionPayload;
}

function harness(
  options: Parameters<typeof guardianHarness>[0] & { readonly withDedupe?: boolean } = {},
) {
  const { withDedupe, ...harnessOptions } = options;
  const built = guardianHarness(harnessOptions);
  /*
   * A separate logger for the dispatcher only. The services under test were
   * constructed by the harness with the harness logger, so their warnings
   * land in `built.logs` — assertions about service behaviour must read that
   * sink, not this one.
   */
  const dispatcherLogs = createTestLogger();

  const seen = new Set<string>();
  const dispatcher = new EventDispatcher<GuardianDeps>({
    bot: 'guardian',
    logger: dispatcherLogs.logger,
    deps: { ...built.deps, logger: dispatcherLogs.logger },
    ...(withDedupe === false
      ? {}
      : {
          dedupe: {
            tryClaim: (key) => {
              if (seen.has(key)) return Promise.resolve(false);
              seen.add(key);
              return Promise.resolve(true);
            },
          },
        }),
  }).register(autoModActionHandler);

  return { ...built, dispatcher, dispatcherLogs };
}

const auditOf = (h: ReturnType<typeof harness>) =>
  h.repositories.audit.events.filter(
    (event) => event.event === 'security.automod_action',
  );

describe('AutoMod execution consumer', () => {
  it('records the execution and alerts moderators', async () => {
    const h = harness();
    await h.dispatcher.dispatch('autoModerationActionExecution', payload());

    expect(auditOf(h)).toHaveLength(1);
    expect(h.messaging.sent).toHaveLength(1);
    expect(h.messaging.sent[0]?.channelId).toBe(TEST_CHANNEL_IDS.moderation);
  });

  it('does nothing when the feature flag is off', async () => {
    const h = harness({ autoModSignals: false });
    await h.dispatcher.dispatch('autoModerationActionExecution', payload());

    expect(auditOf(h)).toHaveLength(0);
    expect(h.messaging.sent).toHaveLength(0);
  });

  /*
   * Bloom is configured for one guild. An execution from elsewhere means the
   * app was installed somewhere nobody intended, and folding another
   * community's moderation events into this audit trail would be worse than
   * dropping them.
   */
  it('refuses an execution from a guild Bloom is not configured for', async () => {
    const h = harness();
    const foreign = unsafeSnowflake<GuildId>('999900000000000009');
    await h.dispatcher.dispatch(
      'autoModerationActionExecution',
      payload({ guildId: foreign }),
    );

    expect(auditOf(h)).toHaveLength(0);
    expect(h.messaging.sent).toHaveLength(0);
    expect(h.logs.has('security.automod_foreign_guild')).toBe(true);
  });

  describe('no enforcement', () => {
    /*
     * The central guarantee. AutoMod already acted; the execution event is a
     * notification of a completed action, not authorisation for a second one.
     */
    it('never bans, kicks, times out or re-roles anyone', async () => {
      const h = harness();
      for (const action of [
        'block_message',
        'send_alert_message',
        'timeout',
        'block_member_interaction',
        'unknown',
      ] as const) {
        await h.dispatcher.dispatch(
          'autoModerationActionExecution',
          payload({
            action,
            messageId: unsafeSnowflake(`5000000000000000${String(action.length)}`),
          }),
        );
      }

      expect(h.moderation.calls).toHaveLength(0);
      expect(h.moderation.bans.size).toBe(0);
      expect(h.roles.changes).toHaveLength(0);
    });

    it('opens no Bloom moderation case', async () => {
      const h = harness();
      await h.dispatcher.dispatch('autoModerationActionExecution', payload());

      // Named collections, not an optional lookup: `?? []` would make this
      // pass against a property that does not exist.
      expect(h.repositories.cases.cases).toHaveLength(0);
      expect(h.repositories.cases.events).toHaveLength(0);
      expect(h.repositories.moderation.actions).toHaveLength(0);
    });
  });

  describe('idempotency', () => {
    it('records and alerts once for a redelivered event', async () => {
      const h = harness();
      await h.dispatcher.dispatch('autoModerationActionExecution', payload());
      await h.dispatcher.dispatch('autoModerationActionExecution', payload());

      expect(auditOf(h)).toHaveLength(1);
      expect(h.messaging.sent).toHaveLength(1);
    });

    /*
     * A gateway resume redelivers the *same* payload, but Bloom stamps
     * receipt time at the edge — so the redelivery carries a later
     * `detectedAt`. If that field leaked into the key, dedupe would silently
     * stop working during exactly the event it exists for.
     */
    it('deduplicates despite a different receipt time', async () => {
      const h = harness();
      await h.dispatcher.dispatch('autoModerationActionExecution', payload());
      await h.dispatcher.dispatch(
        'autoModerationActionExecution',
        payload({ detectedAt: new Date('2026-02-01T10:05:00.000Z') }),
      );

      expect(auditOf(h)).toHaveLength(1);
    });

    it('handles concurrent duplicate delivery', async () => {
      const h = harness();
      await Promise.all([
        h.dispatcher.dispatch('autoModerationActionExecution', payload()),
        h.dispatcher.dispatch('autoModerationActionExecution', payload()),
        h.dispatcher.dispatch('autoModerationActionExecution', payload()),
      ]);

      expect(auditOf(h)).toHaveLength(1);
      expect(h.messaging.sent).toHaveLength(1);
    });

    /*
     * One rule can specify several actions, and a single violation then
     * produces several execution events differing only in action type.
     * Collapsing those would lose the timeout behind the blocked message.
     */
    it('keeps separate actions from one rule distinct', async () => {
      const h = harness();
      await h.dispatcher.dispatch(
        'autoModerationActionExecution',
        payload({ action: 'block_message', rawActionType: 1 }),
      );
      await h.dispatcher.dispatch(
        'autoModerationActionExecution',
        payload({ action: 'timeout', rawActionType: 3, timeoutSeconds: 600 }),
      );

      expect(auditOf(h)).toHaveLength(2);
    });

    it('keeps distinct messages distinct', () => {
      const first = autoModDedupeKey(payload());
      const second = autoModDedupeKey(
        payload({ messageId: unsafeSnowflake('500000000000000099') }),
      );
      expect(first).not.toBe(second);
    });

    it('falls back to the AutoMod alert id when the message was blocked', () => {
      const key = autoModDedupeKey(
        payload({
          messageId: null,
          alertMessageId: unsafeSnowflake('600000000000000006'),
        }),
      );
      expect(key).toContain('600000000000000006');
    });

    it('never puts receipt time in the key', () => {
      const key = autoModDedupeKey(payload());
      expect(key).not.toContain('2026');
      expect(autoModDedupeKey(payload({ detectedAt: new Date(0) }))).toBe(key);
    });
  });

  describe('audit record', () => {
    it('records the metadata a moderator needs', async () => {
      const h = harness();
      await h.dispatcher.dispatch(
        'autoModerationActionExecution',
        payload({ action: 'timeout', rawActionType: 3, timeoutSeconds: 600 }),
      );

      const entry = auditOf(h)[0];
      expect(entry?.botName).toBe('guardian');
      expect(entry?.severity).toBe('warn');
      expect(entry?.source).toBe('discord.automod');
      expect(entry?.targetId).toBe(OFFENDER);
      expect(entry?.channelId).toBe(TEST_CHANNEL_IDS.welcome);
      expect(entry?.correlationId).toBeTruthy();
      expect(entry?.details).toMatchObject({
        rule_id: RULE,
        trigger: 'keyword',
        action: 'timeout',
        raw_action_type: 3,
        timeout_seconds: 600,
        content_ingested: false,
      });
    });

    /*
     * No actor. Nobody at Bloom did this, and attributing it to a moderator
     * or to the bot would make the trail claim something untrue.
     */
    it('attributes the action to nobody', async () => {
      const h = harness();
      await h.dispatcher.dispatch('autoModerationActionExecution', payload());
      expect(auditOf(h)[0]?.actorId ?? null).toBeNull();
    });

    it('persists no message content and no raw Discord payload', async () => {
      const h = harness();
      const forbidden = 'FORBIDDEN-CONTENT-STRING';
      await h.dispatcher.dispatch(
        'autoModerationActionExecution',
        // Even if a future payload smuggled extra keys, they must not land.
        { ...payload(), content: forbidden, matchedKeyword: forbidden },
      );

      const serialised = JSON.stringify(auditOf(h));
      expect(serialised).not.toContain(forbidden);
      expect(serialised).not.toContain('matchedKeyword');
    });
  });

  describe('moderator alert', () => {
    it('explains the action without quoting anything', async () => {
      const h = harness();
      await h.dispatcher.dispatch(
        'autoModerationActionExecution',
        payload({ action: 'timeout', rawActionType: 3, timeoutSeconds: 600 }),
      );

      const alert = JSON.stringify(h.messaging.sent[0]);
      expect(alert).toContain('timed the member out');
      expect(alert).toContain(RULE);
      expect(alert).toContain(OFFENDER);
      expect(alert).toContain('600');
    });

    it('uses no mass ping', async () => {
      const h = harness();
      await h.dispatcher.dispatch('autoModerationActionExecution', payload());

      const alert = JSON.stringify(h.messaging.sent[0]);
      expect(alert).not.toContain('@here');
      expect(alert).not.toContain('@everyone');
    });

    it('names an unrecognised action honestly rather than guessing', async () => {
      const h = harness();
      await h.dispatcher.dispatch(
        'autoModerationActionExecution',
        payload({ action: 'unknown', rawActionType: 99 }),
      );

      expect(JSON.stringify(h.messaging.sent[0])).toContain('does not recognise');
    });

    /*
     * One misconfigured keyword rule can fire hundreds of times a minute.
     * The audit trail absorbs that; the moderation channel must not.
     */
    it('throttles repeat alerts per rule but still records every execution', async () => {
      const h = harness({ withDedupe: false });
      for (let index = 0; index < 5; index += 1) {
        await h.dispatcher.dispatch(
          'autoModerationActionExecution',
          payload({ messageId: unsafeSnowflake(`50000000000000001${String(index)}`) }),
        );
      }

      expect(auditOf(h)).toHaveLength(5);
      expect(h.messaging.sent).toHaveLength(1);
    });

    it('lets a different rule through the throttle', async () => {
      const h = harness({ withDedupe: false });
      await h.dispatcher.dispatch('autoModerationActionExecution', payload());
      await h.dispatcher.dispatch(
        'autoModerationActionExecution',
        payload({ ruleId: '200000000000000099' }),
      );

      expect(h.messaging.sent).toHaveLength(2);
    });

    it('records the execution even with no moderation channel configured', async () => {
      const h = harness({ moderationChannel: null });
      await h.dispatcher.dispatch('autoModerationActionExecution', payload());

      expect(auditOf(h)).toHaveLength(1);
      expect(h.messaging.sent).toHaveLength(0);
      expect(h.logs.has('security.automod_no_channel')).toBe(true);
    });
  });

  describe('failure handling', () => {
    /*
     * The audit row is already written when the alert fails. Losing it
     * because Discord was unreachable would be the wrong trade.
     */
    it('keeps the record when the alert cannot be delivered', async () => {
      const h = harness();
      h.guild.unpostableChannels.add(TEST_CHANNEL_IDS.moderation);

      await h.dispatcher.dispatch('autoModerationActionExecution', payload());

      expect(auditOf(h)).toHaveLength(1);
      expect(h.logs.has('security.automod_alert_failed')).toBe(true);
    });

    it('sends no alert when the record could not be written', async () => {
      const h = harness();
      h.repositories.audit.append = () =>
        Promise.reject(bloomError('DATABASE_UNAVAILABLE', { operatorHint: 'down' }));

      await h.dispatcher.dispatch('autoModerationActionExecution', payload());

      expect(h.messaging.sent).toHaveLength(0);
      expect(h.logs.has('security.automod_record_failed')).toBe(true);
    });

    /*
     * The dispatcher is the boundary with discord.js: a rejection escaping
     * it becomes an unhandled rejection and kills the process.
     */
    it('never throws into the gateway loop', async () => {
      const h = harness();
      h.repositories.audit.append = () => Promise.reject(new Error('catastrophic'));
      h.repositories.cooldowns.tryAcquire = () => Promise.reject(new Error('also down'));

      await expect(
        h.dispatcher.dispatch('autoModerationActionExecution', payload()),
      ).resolves.toBeUndefined();
    });

    it('survives a payload with missing optional fields', async () => {
      const h = harness();
      await expect(
        h.dispatcher.dispatch(
          'autoModerationActionExecution',
          payload({ channelId: null, messageId: null, alertMessageId: null }),
        ),
      ).resolves.toBeUndefined();

      expect(auditOf(h)).toHaveLength(1);
      expect(auditOf(h)[0]?.channelId ?? null).toBeNull();
    });
  });
});
