import { newCorrelationId } from '@bloom/utils';
import type { AutoModActionPayload, EventHandler } from '@bloom/events';
import type { GuardianDeps } from '../../deps.js';

/**
 * Guardian's AutoMod execution handler.
 *
 * Guardian owns `autoModerationActionExecution` in `EVENT_OWNERSHIP`, and
 * registration throws if another bot claims it. It is also the only bot that
 * *could* receive it — Discord sends AutoMod executions solely to
 * applications holding Manage Server — but the declaration is what makes
 * that a rule rather than a coincidence of current permissions.
 */

/**
 * The strongest stable identity Discord offers for an execution.
 *
 * There is no execution id in the dispatch data. Discord simply does not
 * provide one, so the identity has to be composed, and each part earns its
 * place:
 *
 *   • **guild, rule, user** — the obvious triple.
 *   • **action type** — load-bearing. One rule can specify several actions,
 *     and a single violation then produces several execution events that
 *     differ *only* here. Leaving it out would collapse "blocked the message
 *     and timed them out" into one record and lose the timeout.
 *   • **message id, falling back to the AutoMod alert id** — what separates
 *     two different violations by the same person against the same rule.
 *
 * `detectedAt` is deliberately absent. It is receipt time, so a redelivered
 * event carries a different value, and including it would defeat the entire
 * mechanism at precisely the moment it is needed.
 *
 * ### The honest limitation
 *
 * When AutoMod blocks a message there is no message id — the message was
 * never created — and unless the rule also posts an alert there is no alert
 * id either. The key then degrades to guild+rule+user+action, so a member
 * tripping the same rule repeatedly inside the dedupe window is recorded
 * once rather than once per attempt.
 *
 * That is a limit of the Discord payload, not a choice, and it fails in the
 * safer direction: under-recording a repeat offender is recoverable, whereas
 * duplicating audit rows on every gateway resume would corrupt the trail
 * permanently. The repetition is also still visible — Discord's own AutoMod
 * alert channel shows every hit.
 */
export function autoModDedupeKey(payload: AutoModActionPayload): string {
  const reference = payload.messageId ?? payload.alertMessageId ?? 'none';
  return [
    payload.guildId,
    payload.ruleId,
    payload.userId,
    String(payload.rawActionType),
    reference,
  ].join(':');
}

export const autoModActionHandler: EventHandler<AutoModActionPayload, GuardianDeps> = {
  bot: 'guardian',
  event: 'autoModerationActionExecution',
  name: 'security.automod-action',

  dedupeKey: autoModDedupeKey,

  async handle(payload, deps) {
    await deps.autoModSignals.consume(payload, newCorrelationId());
  },
};
