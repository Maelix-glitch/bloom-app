import type { PlatformConfig } from '@bloom/config';
import type { GuardianRepositories } from '@bloom/database';
import type { MessagingService } from '@bloom/discord';
import type { AutoModActionPayload } from '@bloom/events';
import type { Logger } from '@bloom/logging';
import { BloomError, type CorrelationId, type JsonObject } from '@bloom/shared-types';
import { autoModAlertMessage } from './messages.js';

/**
 * The Discord AutoMod execution consumer.
 *
 * The flow is: Discord AutoMod inspects a message, acts on it, and tells
 * Bloom what it did. Bloom writes that down and nudges a moderator. That is
 * the entire feature.
 *
 * ## Bloom does not act
 *
 * There is no ban, kick, timeout, role change, quarantine or lockdown here,
 * and as with join surveillance the restraint is structural: this service's
 * dependencies are config, repositories, messaging and a logger. No role
 * service, no moderation service. It could not punish anyone if it tried.
 *
 * That is a deliberate position, not an omission. AutoMod has *already*
 * applied whatever the rule specified — blocked the message, timed the
 * member out. The execution event is the notification of a completed action,
 * not a request for a second one. Treating "Discord acted" as grounds for
 * "therefore Bloom should also act" would double every punishment and hand
 * control of Bloom's moderation to whoever last edited an AutoMod rule.
 *
 * ## Record always, alert sometimes
 *
 * The audit row and the moderator alert are throttled differently on
 * purpose.
 *
 * The audit trail is the record, so every execution Bloom sees is written
 * down — losing one means the history is wrong. The alert is an
 * interruption, and a single misconfigured keyword rule on a busy server can
 * fire hundreds of times a minute. So alerts are throttled per rule: the
 * first execution of a rule pings moderators, the rest land silently in the
 * audit trail where they belong. One noisy rule cannot bury the channel, and
 * a second rule firing during the storm still gets through.
 */

export interface AutoModConsumerOptions {
  readonly config: PlatformConfig;
  readonly repositories: GuardianRepositories;
  readonly messaging: MessagingService;
  readonly logger: Logger;
}

export type AutoModOutcome =
  'recorded_and_alerted' | 'recorded' | 'ignored_disabled' | 'ignored_foreign_guild';

export interface AutoModResult {
  readonly outcome: AutoModOutcome;
  /** False when the alert was throttled, undeliverable, or the channel is unset. */
  readonly alerted: boolean;
}

/** Cooldown scope for the moderator alert. */
const ALERT_SCOPE = 'security.automod_alert';

export class AutoModSignalService {
  public constructor(private readonly options: AutoModConsumerOptions) {}

  /**
   * Handle one AutoMod execution.
   *
   * Never throws. The caller is a gateway event handler; the dispatcher
   * already contains failures, but a security consumer should not rely on
   * someone else's catch block to stay quiet, and the distinction between
   * "the database rejected this" and "the alert could not be delivered"
   * matters enough to be logged separately rather than collapsed into one
   * generic handler failure.
   */
  public async consume(
    payload: AutoModActionPayload,
    correlationId: CorrelationId,
  ): Promise<AutoModResult> {
    if (!this.options.config.features.autoModSignals) {
      return { outcome: 'ignored_disabled', alerted: false };
    }

    /*
     * Guild isolation.
     *
     * Bloom is configured for exactly one guild. An execution from anywhere
     * else means the application was added to a server nobody intended, and
     * recording it would mix another community's moderation events into this
     * one's audit trail. Dropped, and logged loudly enough to be noticed.
     */
    if (payload.guildId !== this.options.config.discord.guildId) {
      this.options.logger.warn(
        'security.automod_foreign_guild',
        'Ignored an AutoMod execution from a guild Bloom is not configured for.',
        { guild_id: payload.guildId },
      );
      return { outcome: 'ignored_foreign_guild', alerted: false };
    }

    /*
     * The audit row comes first, and its failure is fatal to this call.
     *
     * If the record cannot be written there is nothing to alert *about* —
     * a ping with no durable trail behind it is worse than silence, because
     * a moderator who investigates finds nothing and learns to distrust the
     * channel. The error is translated and logged, not rethrown.
     */
    try {
      await this.options.repositories.audit.append({
        guildId: payload.guildId,
        botName: 'guardian',
        event: 'security.automod_action',
        severity: 'warn',
        actorId: null,
        targetId: payload.userId,
        channelId: payload.channelId,
        source: 'discord.automod',
        correlationId,
        details: this.describe(payload),
      });
    } catch (error) {
      const bloom = BloomError.from(error);
      this.options.logger.error(
        'security.automod_record_failed',
        'Could not record an AutoMod execution; no alert was sent.',
        { guild_id: payload.guildId, error: bloom, error_code: bloom.code },
      );
      return { outcome: 'recorded', alerted: false };
    }

    const alerted = await this.alert(payload);
    return {
      outcome: alerted ? 'recorded_and_alerted' : 'recorded',
      alerted,
    };
  }

  /** Returns whether moderators were actually told. */
  private async alert(payload: AutoModActionPayload): Promise<boolean> {
    const channelId = this.options.config.channels.moderation;
    if (!channelId) {
      this.options.logger.warn(
        'security.automod_no_channel',
        'AutoMod acted, but no moderation channel is configured to report it to.',
        { guild_id: payload.guildId },
      );
      return false;
    }

    /*
     * Throttled per rule, not per guild and not per member.
     *
     * Per guild would let one chatty rule mute alerts for every other rule
     * during the window. Per member would let a coordinated raid produce one
     * alert per participant, which is the storm this exists to prevent.
     */
    const claim = await this.options.repositories.cooldowns.tryAcquire(
      payload.guildId,
      ALERT_SCOPE,
      payload.ruleId,
      this.options.config.security.autoMod.alertCooldownSeconds,
    );
    if (!claim.allowed) return false;

    /*
     * A failed alert must not undo the record.
     *
     * Missing permission on the moderation channel, a deleted channel, a
     * Discord outage — all real, none of them a reason to lose the audit row
     * that was already written.
     */
    try {
      await this.options.messaging.sendToChannel(
        payload.guildId,
        channelId,
        autoModAlertMessage(payload),
      );
      return true;
    } catch (error) {
      const bloom = BloomError.from(error);
      this.options.logger.error(
        'security.automod_alert_failed',
        'Recorded an AutoMod execution but could not alert moderators.',
        {
          guild_id: payload.guildId,
          channel_id: channelId,
          error: bloom,
          error_code: bloom.code,
        },
      );
      return false;
    }
  }

  /**
   * The audit `details` object.
   *
   * Identifiers, enum names and numbers. No content, no keyword, no raw
   * discord.js object — the payload this reads from does not carry any of
   * those, so this method could not include them even by mistake.
   */
  private describe(payload: AutoModActionPayload): JsonObject {
    return {
      rule_id: payload.ruleId,
      trigger: payload.trigger,
      raw_trigger_type: payload.rawTriggerType,
      action: payload.action,
      raw_action_type: payload.rawActionType,
      message_id: payload.messageId,
      alert_message_id: payload.alertMessageId,
      timeout_seconds: payload.timeoutSeconds,
      detected_at: payload.detectedAt.toISOString(),
      // States the boundary in the record itself, so an auditor reading a
      // row years from now knows the absence of content was by design.
      content_ingested: false,
    };
  }
}
