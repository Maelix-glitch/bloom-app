import { describe, expect, it } from 'vitest';
import { TEST_CHANNEL_IDS, TEST_GUILD_ID } from '@bloom/testing';
import { guardianHarness } from '../../guardian.harness.js';
import { evaluateRaid, type RaidThresholds } from './raid-detector.js';
import type { GuildId, UserId } from '@bloom/shared-types';

/**
 * Anti-raid detection.
 *
 * Two layers, tested differently on purpose. The pure detector is driven
 * directly through its boundaries, because a security decision is only as
 * trustworthy as the cases somebody bothered to enumerate. The service is
 * tested through the harness, because what matters there is the wiring: that
 * it alerts once, writes an audit row, names nobody, and cannot touch a
 * member.
 */

const NOW = new Date('2026-01-01T12:00:00.000Z');

const THRESHOLDS: RaidThresholds = {
  windowSeconds: 60,
  joinThreshold: 5,
  youngAccountDays: 7,
  youngAccountRatio: 0.5,
};

const DISCORD_EPOCH_MS = 1_420_070_400_000n;

/** Mint a snowflake whose embedded creation time is `ageDays` before NOW. */
function idAged(ageDays: number, sequence: number): UserId {
  const created = BigInt(NOW.getTime() - Math.round(ageDays * 86_400_000));
  const id = ((created - DISCORD_EPOCH_MS) << 22n) + BigInt(sequence);
  return String(id) as UserId;
}

function ages(count: number, ageDays: number): Date[] {
  return Array.from(
    { length: count },
    () => new Date(NOW.getTime() - ageDays * 86_400_000),
  );
}

describe('evaluateRaid', () => {
  it('flags a burst of fresh accounts', () => {
    const result = evaluateRaid({
      joinsInWindow: 12,
      sampledAccountAges: [...ages(10, 1), ...ages(2, 400)],
      now: NOW,
      thresholds: THRESHOLDS,
    });

    expect(result.raidSuspected).toBe(true);
    expect(result.youngAccounts).toBe(10);
    expect(result.sampleSize).toBe(12);
  });

  /*
   * The false-positive case the AND exists for. A creator shoutout produces
   * exactly this: a lot of joins, ordinary accounts. Treating it as an attack
   * is how a detector gets muted.
   */
  it('does not flag an organic surge of established accounts', () => {
    const result = evaluateRaid({
      joinsInWindow: 40,
      sampledAccountAges: ages(40, 500),
      now: NOW,
      thresholds: THRESHOLDS,
    });

    expect(result.raidSuspected).toBe(false);
    expect(result.signals[0]?.fired).toBe(true);
    expect(result.signals[1]?.fired).toBe(false);
  });

  /* The other half of the AND: new accounts arriving at a normal rate. */
  it('does not flag a trickle of new accounts', () => {
    const result = evaluateRaid({
      joinsInWindow: 2,
      sampledAccountAges: ages(2, 0.5),
      now: NOW,
      thresholds: THRESHOLDS,
    });

    expect(result.raidSuspected).toBe(false);
    expect(result.signals[0]?.fired).toBe(false);
    expect(result.signals[1]?.fired).toBe(true);
  });

  it('is never suspicious of an empty sample', () => {
    const result = evaluateRaid({
      joinsInWindow: 99,
      sampledAccountAges: [],
      now: NOW,
      thresholds: THRESHOLDS,
    });

    expect(result.raidSuspected).toBe(false);
    expect(result.sampleSize).toBe(0);
    /*
     * And it still explains itself in numbers.
     *
     * Without the explicit zero-sample guard the ratio is 0/0, and `NaN >=
     * 0.5` is false — so the verdict comes out right by accident while the
     * explanation reads "NaN%". A moderator reading that learns nothing, and
     * the accident is one refactor away from becoming a bug. Asserted on the
     * rendered detail because that is what a human actually sees.
     */
    expect(result.signals[1]?.observed).toBe(0);
    expect(result.signals[1]?.detail).toContain('(0%, threshold 50%)');
  });

  /*
   * Boundary arithmetic, pinned in both directions. `>=` versus `>` on either
   * threshold is a one-character mutation that changes who gets alerted on,
   * and nothing else in the suite would catch it.
   */
  it('treats the join threshold as inclusive and one below as quiet', () => {
    const atThreshold = evaluateRaid({
      joinsInWindow: 5,
      sampledAccountAges: ages(5, 1),
      now: NOW,
      thresholds: THRESHOLDS,
    });
    const below = evaluateRaid({
      joinsInWindow: 4,
      sampledAccountAges: ages(4, 1),
      now: NOW,
      thresholds: THRESHOLDS,
    });

    expect(atThreshold.signals[0]?.fired).toBe(true);
    expect(below.signals[0]?.fired).toBe(false);
  });

  it('treats the young-account ratio as inclusive', () => {
    const exactlyHalf = evaluateRaid({
      joinsInWindow: 10,
      sampledAccountAges: [...ages(5, 1), ...ages(5, 500)],
      now: NOW,
      thresholds: THRESHOLDS,
    });
    const justUnder = evaluateRaid({
      joinsInWindow: 10,
      sampledAccountAges: [...ages(4, 1), ...ages(6, 500)],
      now: NOW,
      thresholds: THRESHOLDS,
    });

    expect(exactlyHalf.signals[1]?.fired).toBe(true);
    expect(justUnder.signals[1]?.fired).toBe(false);
  });

  it('counts an account exactly at the age cutoff as established', () => {
    const result = evaluateRaid({
      joinsInWindow: 10,
      sampledAccountAges: ages(10, 7),
      now: NOW,
      thresholds: THRESHOLDS,
    });

    expect(result.youngAccounts).toBe(0);
  });

  it('is deterministic across repeated and reordered evaluation', () => {
    const sample = [...ages(6, 1), ...ages(4, 900)];
    const first = evaluateRaid({
      joinsInWindow: 10,
      sampledAccountAges: sample,
      now: NOW,
      thresholds: THRESHOLDS,
    });
    const again = evaluateRaid({
      joinsInWindow: 10,
      sampledAccountAges: [...sample].reverse(),
      now: NOW,
      thresholds: THRESHOLDS,
    });

    expect(again).toStrictEqual(first);
  });

  it('explains itself in numbers a moderator can act on', () => {
    const result = evaluateRaid({
      joinsInWindow: 12,
      sampledAccountAges: [...ages(9, 1), ...ages(3, 500)],
      now: NOW,
      thresholds: THRESHOLDS,
    });

    expect(result.signals[0]?.detail).toBe('12 joins in 60s (threshold 5)');
    expect(result.signals[1]?.detail).toBe(
      '9 of 12 accounts under 7 days old (75%, threshold 50%)',
    );
  });
});

describe('JoinSurveillanceService', () => {
  /** Seed `count` joiners of a given account age, all inside the window. */
  async function seedJoins(
    harness: ReturnType<typeof guardianHarness>,
    count: number,
    ageDays: number,
    guildId: GuildId = TEST_GUILD_ID,
  ): Promise<UserId[]> {
    const ids: UserId[] = [];
    for (let index = 0; index < count; index += 1) {
      const userId = idAged(ageDays, index + 1);
      ids.push(userId);
      await harness.repositories.identity.ensureMember({
        guildId,
        userId,
        username: `joiner-${String(index)}`,
        joinedAt: NOW,
      });
    }
    return ids;
  }

  function harnessAt(options: Parameters<typeof guardianHarness>[0] = {}) {
    return guardianHarness({ now: () => NOW, raid: { joinThreshold: 5 }, ...options });
  }

  it('alerts the moderation channel when a raid is suspected', async () => {
    const harness = harnessAt();
    const ids = await seedJoins(harness, 8, 1);

    const outcome = await harness.deps.joinSurveillance.observeJoin({
      guildId: TEST_GUILD_ID,
      userId: ids[0]!,
      isBot: false,
      correlationId: 'corr-raid-1' as never,
    });

    expect(outcome.alerted).toBe(true);
    const alert = harness.messaging.sent.at(-1);
    expect(alert?.channelId).toBe(TEST_CHANNEL_IDS.moderation);
    expect(JSON.stringify(alert)).toContain('8 joins in 60s');
  });

  it('stays quiet on an ordinary join', async () => {
    const harness = harnessAt();
    const ids = await seedJoins(harness, 2, 400);

    const outcome = await harness.deps.joinSurveillance.observeJoin({
      guildId: TEST_GUILD_ID,
      userId: ids[0]!,
      isBot: false,
      correlationId: 'corr-quiet' as never,
    });

    expect(outcome.alerted).toBe(false);
    expect(outcome.reason).toBe('quiet');
    expect(harness.messaging.sent).toHaveLength(0);
  });

  /*
   * The property that keeps the alert channel usable during the attack it is
   * reporting. A hundred accounts arrive; moderators get told once.
   */
  it('alerts once per raid, not once per joining account', async () => {
    const harness = harnessAt();
    const ids = await seedJoins(harness, 20, 1);

    for (const userId of ids) {
      await harness.deps.joinSurveillance.observeJoin({
        guildId: TEST_GUILD_ID,
        userId,
        isBot: false,
        correlationId: 'corr-burst' as never,
      });
    }

    expect(harness.messaging.sent).toHaveLength(1);
    const audits = harness.repositories.audit.events.filter(
      (event) => event.event === 'security.raid_suspected',
    );
    expect(audits).toHaveLength(1);
  });

  it('records an explainable audit entry that names nobody', async () => {
    const harness = harnessAt();
    const ids = await seedJoins(harness, 9, 1);

    await harness.deps.joinSurveillance.observeJoin({
      guildId: TEST_GUILD_ID,
      userId: ids[0]!,
      isBot: false,
      correlationId: 'corr-audit' as never,
    });

    const entry = harness.repositories.audit.events.find(
      (event) => event.event === 'security.raid_suspected',
    );
    expect(entry?.actorId ?? null).toBeNull();
    expect(entry?.targetId ?? null).toBeNull();
    expect(entry?.details).toMatchObject({
      joins_in_window: 9,
      window_seconds: 60,
      young_accounts: 9,
      velocity_fired: true,
      concentration_fired: true,
    });
    // No member id anywhere in the record.
    expect(JSON.stringify(entry)).not.toContain(ids[0] as string);
  });

  it('never names a member in the alert itself', async () => {
    const harness = harnessAt();
    const ids = await seedJoins(harness, 8, 1);

    await harness.deps.joinSurveillance.observeJoin({
      guildId: TEST_GUILD_ID,
      userId: ids[0]!,
      isBot: false,
      correlationId: 'corr-privacy' as never,
    });

    const alert = JSON.stringify(harness.messaging.sent.at(-1));
    for (const id of ids) {
      expect(alert).not.toContain(id);
    }
    // And no mass ping, whatever else it says.
    expect(alert).not.toContain('@here');
    expect(alert).not.toContain('@everyone');
  });

  it('takes no action against any member', async () => {
    const harness = harnessAt();
    const ids = await seedJoins(harness, 10, 1);

    await harness.deps.joinSurveillance.observeJoin({
      guildId: TEST_GUILD_ID,
      userId: ids[0]!,
      isBot: false,
      correlationId: 'corr-noaction' as never,
    });

    expect(harness.moderation.calls).toHaveLength(0);
    expect(harness.moderation.bans.size).toBe(0);
    expect(harness.roles.changes).toHaveLength(0);
    // Onboarding state is untouched for every joiner.
    for (const userId of ids) {
      const member = await harness.repositories.identity.findMember(
        TEST_GUILD_ID,
        userId,
      );
      expect(member?.onboardingState).toBe('unverified');
    }
  });

  it('does nothing when the feature flag is off', async () => {
    const harness = harnessAt({ raidDetection: false });
    const ids = await seedJoins(harness, 20, 1);

    const outcome = await harness.deps.joinSurveillance.observeJoin({
      guildId: TEST_GUILD_ID,
      userId: ids[0]!,
      isBot: false,
      correlationId: 'corr-off' as never,
    });

    expect(outcome.reason).toBe('disabled');
    expect(harness.messaging.sent).toHaveLength(0);
  });

  it('does not count bot joins towards a raid', async () => {
    const harness = harnessAt();
    await seedJoins(harness, 20, 1);

    const outcome = await harness.deps.joinSurveillance.observeJoin({
      guildId: TEST_GUILD_ID,
      userId: idAged(1, 999),
      isBot: true,
      correlationId: 'corr-bot' as never,
    });

    expect(outcome.reason).toBe('bot_join');
    expect(harness.messaging.sent).toHaveLength(0);
  });

  it('warns the operator rather than failing when no moderation channel is set', async () => {
    const harness = harnessAt({ moderationChannel: null });
    const ids = await seedJoins(harness, 9, 1);

    const outcome = await harness.deps.joinSurveillance.observeJoin({
      guildId: TEST_GUILD_ID,
      userId: ids[0]!,
      isBot: false,
      correlationId: 'corr-nochannel' as never,
    });

    expect(outcome.assessment?.raidSuspected).toBe(true);
    expect(outcome.reason).toBe('no_channel');
    expect(harness.logs.has('security.raid_no_channel')).toBe(true);
  });

  /*
   * Guild scoping. A raid on one server must not be detected using another
   * server's joins, and must not alert anywhere but its own channel.
   */
  it('counts joins per guild', async () => {
    const harness = harnessAt();
    const other = '999900000000000001' as GuildId;
    await seedJoins(harness, 20, 1, other);
    const mine = await seedJoins(harness, 2, 1);

    const outcome = await harness.deps.joinSurveillance.observeJoin({
      guildId: TEST_GUILD_ID,
      userId: mine[0]!,
      isBot: false,
      correlationId: 'corr-scope' as never,
    });

    expect(outcome.assessment?.joinsInWindow).toBe(2);
    expect(outcome.alerted).toBe(false);
  });

  it('ignores joins that fell out of the rolling window', async () => {
    const harness = harnessAt();
    for (let index = 0; index < 20; index += 1) {
      await harness.repositories.identity.ensureMember({
        guildId: TEST_GUILD_ID,
        userId: idAged(1, 500 + index),
        username: `old-${String(index)}`,
        // Two minutes ago: outside the 60s window.
        joinedAt: new Date(NOW.getTime() - 120_000),
      });
    }

    const outcome = await harness.deps.joinSurveillance.observeJoin({
      guildId: TEST_GUILD_ID,
      userId: idAged(1, 1),
      isBot: false,
      correlationId: 'corr-window' as never,
    });

    expect(outcome.assessment?.joinsInWindow).toBe(0);
    expect(outcome.alerted).toBe(false);
  });
});
