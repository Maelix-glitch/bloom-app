import { beforeEach, describe, expect, it } from 'vitest';
import {
  unsafeSnowflake,
  bloomError,
  type GuildId,
  type UserId,
} from '@bloom/shared-types';
import {
  TEST_CHANNEL_IDS,
  TEST_GUILD_ID,
  TEST_ROLE_IDS,
  TEST_USER_IDS,
  testSubject,
  type RecordingResponder,
} from '@bloom/testing';
import { newCorrelationId } from '@bloom/utils';
import { guardianHarness, type GuardianHarness } from '../../guardian.harness.js';

/**
 * AutoMod security history inside the case view.
 *
 * Task 4 consolidated the standalone "Security history" block into the
 * unified timeline, so these assertions now key off the `AUTOMOD` category
 * tag rather than a section heading. The behaviour under test — scoping,
 * authorization, privacy, bounding — is unchanged; only where it surfaces
 * moved.
 *
 * A read-only enrichment, so the tests that matter are not about rendering.
 * They are about the three boundaries it could quietly breach: authorization
 * (can someone who cannot read cases learn this?), scoping (can one guild or
 * one member's history leak into another's?), and privacy (can message
 * content reach a screen?).
 *
 * Dispatched through the real command pipeline rather than calling the
 * service, because authorization lives in the pipeline — a test that called
 * `detail()` directly would pass regardless of who is allowed to run it.
 */

const REFUSAL = 'Not available to you';

let h: GuardianHarness;

const MEMBER = TEST_USER_IDS.member;
const MODERATOR = TEST_USER_IDS.moderator;
const OTHER = TEST_USER_IDS.betaTester;

const asMember = (): ReturnType<typeof testSubject> =>
  testSubject({ userId: MEMBER, roles: ['bloomMember'] });
const asModerator = (): ReturnType<typeof testSubject> =>
  testSubject({ userId: MODERATOR, roles: ['moderator'] });

beforeEach(() => {
  h = guardianHarness();
  h.guild.withMember(MEMBER);
  h.guild.withMember(MODERATOR, { roleIds: [TEST_ROLE_IDS.moderator] });
  h.guild.withMember(OTHER);
});

/** Seed an AutoMod audit row exactly as the Task-2 consumer writes one. */
async function seedAutoMod(
  overrides: {
    readonly guildId?: GuildId;
    readonly targetId?: UserId;
    readonly ruleId?: string;
    readonly action?: string;
    readonly trigger?: string;
    readonly channelId?: typeof TEST_CHANNEL_IDS.welcome | null;
    readonly extraDetails?: Record<string, unknown>;
  } = {},
): Promise<void> {
  await h.repositories.audit.append({
    guildId: overrides.guildId ?? TEST_GUILD_ID,
    botName: 'guardian',
    event: 'security.automod_action',
    severity: 'warn',
    actorId: null,
    targetId: overrides.targetId ?? MEMBER,
    channelId:
      overrides.channelId === null
        ? null
        : (overrides.channelId ?? TEST_CHANNEL_IDS.welcome),
    source: 'discord.automod',
    correlationId: null,
    details: {
      rule_id: overrides.ruleId ?? '200000000000000002',
      trigger: overrides.trigger ?? 'keyword',
      action: overrides.action ?? 'block_message',
      content_ingested: false,
      ...(overrides.extraDetails ?? {}),
    },
  });
}

/** Open a case against MEMBER and return its number. */
async function openCaseOn(subjectId: UserId | null = MEMBER): Promise<number> {
  const { case: row } = await h.repositories.cases.open({
    guildId: TEST_GUILD_ID,
    origin: 'moderator',
    openedBy: MODERATOR,
    summary: 'Pattern of behaviour worth reviewing.',
    subjectId,
    category: null,
    status: 'OPEN',
    correlationId: newCorrelationId(),
  });
  return row.caseNumber;
}

async function viewCase(
  number: number,
  actor = asModerator(),
): Promise<RecordingResponder> {
  const { responder } = await h.dispatch({
    commandName: 'guardian',
    subcommandGroup: 'case',
    subcommand: 'view',
    actor,
    options: { integers: { number } },
  });
  return responder;
}

describe('AutoMod history in the case view', () => {
  describe('normal operation', () => {
    it('shows no security section for a member with no AutoMod history', async () => {
      const number = await openCaseOn();
      const responder = await viewCase(number);

      expect(responder.visibleText).not.toContain('AUTOMOD');
      expect(responder.visibleText).toContain('Pattern of behaviour');
    });

    it('shows a single AutoMod event', async () => {
      await seedAutoMod({ trigger: 'spam', action: 'timeout' });
      const number = await openCaseOn();
      const responder = await viewCase(number);

      expect(responder.visibleText).toContain('AUTOMOD');
      expect(responder.visibleText).toContain('spam filter');
      expect(responder.visibleText).toContain('timed out');
    });

    /*
     * Three hits on one rule and three hits on three rules are very
     * different situations, and without the rule reference the lines are
     * indistinguishable.
     */
    it('identifies which rule fired, so repeats can be told apart', async () => {
      await seedAutoMod({ ruleId: '200000000000111111' });
      await seedAutoMod({ ruleId: '200000000000222222' });
      const number = await openCaseOn();
      const text = (await viewCase(number)).visibleText;

      expect(text).toContain('111111');
      expect(text).toContain('222222');
    });

    it('shows several and counts them', async () => {
      await seedAutoMod({ trigger: 'spam', action: 'timeout' });
      await seedAutoMod({ trigger: 'mention_spam', action: 'block_message' });
      await seedAutoMod({ trigger: 'keyword', action: 'send_alert_message' });
      const number = await openCaseOn();
      const responder = await viewCase(number);

      expect(responder.visibleText.match(/AUTOMOD/g) ?? []).toHaveLength(3);
      expect(responder.visibleText).toContain('mention limit');
      expect(responder.visibleText).toContain('alerted');
    });

    /*
     * Most recent first. A moderator scanning this wants "what just
     * happened", not a history lesson.
     */
    it('orders newest first', async () => {
      await seedAutoMod({ trigger: 'keyword', action: 'block_message' });
      await seedAutoMod({ trigger: 'spam', action: 'timeout' });
      const number = await openCaseOn();
      const text = (await viewCase(number)).visibleText;

      expect(text.indexOf('spam filter')).toBeLessThan(text.indexOf('keyword rule'));
    });

    /*
     * The case view is a working surface, not an audit export. Forty rows
     * would make it unreadable, which is a usability bug with security
     * consequences — people stop reading.
     */
    it('bounds the list however much history exists', async () => {
      for (let index = 0; index < 25; index += 1) {
        await seedAutoMod({ ruleId: `20000000000000${String(index).padStart(4, '0')}` });
      }
      const number = await openCaseOn();
      const responder = await viewCase(number);

      // Bounded by the unified timeline limit, and the overflow is stated
      // rather than left to look like a complete history.
      expect(responder.visibleText.match(/AUTOMOD/g) ?? []).toHaveLength(20);
      expect(responder.visibleText).toContain('most recent of');
      expect(responder.visibleText).toContain('Older history exists');
    });

    it('shows the channel when there is one, and omits it cleanly when not', async () => {
      await seedAutoMod({ channelId: null });
      const number = await openCaseOn();
      const responder = await viewCase(number);

      expect(responder.visibleText).toContain('AUTOMOD');
      expect(responder.visibleText).not.toContain('undefined');
      expect(responder.visibleText).not.toContain('null');
    });
  });

  describe('authorization', () => {
    it('lets an authorized moderator see the history', async () => {
      await seedAutoMod();
      const number = await openCaseOn();
      const responder = await viewCase(number, asModerator());

      expect(responder.visibleText).not.toContain(REFUSAL);
      expect(responder.visibleText).toContain('AUTOMOD');
    });

    /*
     * The enrichment inherits the case view's gate rather than carrying its
     * own. A member refused the case is refused everything inside it — there
     * is no second authorization path to get wrong.
     */
    it('refuses a non-staff member, revealing nothing', async () => {
      await seedAutoMod();
      const number = await openCaseOn();
      const responder = await viewCase(number, asMember());

      expect(responder.visibleText).toContain(REFUSAL);
      expect(responder.visibleText).not.toContain('AUTOMOD');
      expect(responder.visibleText).not.toContain('spam');
      expect(responder.visibleText).not.toContain('200000000000000002');
    });

    it('refuses a staff actor from another guild', async () => {
      await seedAutoMod();
      const number = await openCaseOn();
      const foreign = {
        ...asModerator(),
        guildId: unsafeSnowflake<GuildId>('999900000000000009'),
      };
      const responder = await viewCase(number, foreign);

      expect(responder.visibleText).not.toContain('AUTOMOD');
      expect(responder.visibleText).not.toContain('200000000000000002');
    });
  });

  describe('scoping', () => {
    it('never shows another guild AutoMod history', async () => {
      await seedAutoMod({
        guildId: unsafeSnowflake<GuildId>('999900000000000009'),
        ruleId: 'FOREIGN-RULE-ID',
      });
      const number = await openCaseOn();
      const responder = await viewCase(number);

      expect(responder.visibleText).not.toContain('FOREIGN-RULE-ID');
      expect(responder.visibleText).not.toContain('AUTOMOD');
    });

    it('never shows another member AutoMod history', async () => {
      await seedAutoMod({ targetId: OTHER, ruleId: 'OTHER-MEMBER-RULE' });
      const number = await openCaseOn(MEMBER);
      const responder = await viewCase(number);

      expect(responder.visibleText).not.toContain('OTHER-MEMBER-RULE');
      expect(responder.visibleText).not.toContain('AUTOMOD');
    });

    /*
     * The subject comes from the stored case, never from a command option,
     * so there is no parameter a caller could bend towards someone else.
     */
    /*
     * A case with no subject has no member history to show, and must not
     * spend a query discovering that.
     */
    it('runs no audit query when the case has no subject', async () => {
      let calls = 0;
      const real = h.repositories.audit.listForTargetByEvent.bind(h.repositories.audit);
      h.repositories.audit.listForTargetByEvent = (...args) => {
        calls += 1;
        return real(...args);
      };

      await viewCase(await openCaseOn(null));
      expect(calls).toBe(0);

      await viewCase(await openCaseOn(MEMBER));
      expect(calls).toBe(1);
    });

    it('shows nothing for a case with no subject', async () => {
      await seedAutoMod();
      const responder = await viewCase(await openCaseOn(null));

      expect(responder.visibleText).not.toContain('AUTOMOD');
    });
  });

  describe('privacy', () => {
    /*
     * The architectural property. Bloom never ingests content, so there is
     * none to show — but a `details` blob is schemaless, and this proves the
     * view projects named fields rather than dumping what it was given.
     */
    it('never renders content, matched content or matched keyword', async () => {
      const forbidden = 'FORBIDDEN-MESSAGE-TEXT';
      await seedAutoMod({
        extraDetails: {
          content: forbidden,
          matched_content: forbidden,
          matched_keyword: forbidden,
        },
      });
      const number = await openCaseOn();
      const responder = await viewCase(number);

      expect(responder.visibleText).toContain('AUTOMOD');
      expect(responder.visibleText).not.toContain(forbidden);
      expect(responder.visibleText).not.toContain('matched_keyword');
    });

    it('never dumps the raw audit details blob', async () => {
      await seedAutoMod({ extraDetails: { secret_field: 'SHOULD-NOT-APPEAR' } });
      const number = await openCaseOn();
      const responder = await viewCase(number);

      expect(responder.visibleText).not.toContain('SHOULD-NOT-APPEAR');
      expect(responder.visibleText).not.toContain('content_ingested');
    });

    it('says plainly that content is not available', async () => {
      await seedAutoMod();
      const number = await openCaseOn();
      expect((await viewCase(number)).visibleText).toContain(
        'does not receive message content',
      );
    });
  });

  describe('data selection', () => {
    it('surfaces only security.automod_action events', async () => {
      await h.repositories.audit.append({
        guildId: TEST_GUILD_ID,
        botName: 'guardian',
        event: 'moderation.warn_issued',
        severity: 'info',
        actorId: MODERATOR,
        targetId: MEMBER,
        source: 'command:/guardian warn',
        details: { note: 'UNRELATED-AUDIT-EVENT' },
      });
      await h.repositories.audit.append({
        guildId: TEST_GUILD_ID,
        botName: 'guardian',
        event: 'security.raid_suspected',
        severity: 'warn',
        actorId: null,
        targetId: MEMBER,
        source: 'security.join_surveillance',
        details: { joins_in_window: 40 },
      });

      const number = await openCaseOn();
      const responder = await viewCase(number);

      expect(responder.visibleText).not.toContain('UNRELATED-AUDIT-EVENT');
      expect(responder.visibleText).not.toContain('AUTOMOD');
    });

    /*
     * A row written by a newer consumer, or by a Discord action type added
     * since. Showing the unfamiliar value beats guessing which familiar one
     * it resembles.
     */
    it('renders an unknown action and trigger safely', async () => {
      await seedAutoMod({ action: 'some_future_action', trigger: 'some_future_trigger' });
      const number = await openCaseOn();
      const responder = await viewCase(number);

      expect(responder.visibleText).toContain('some_future_action');
      expect(responder.visibleText).not.toContain('undefined');
    });

    it('renders a row with missing detail fields safely', async () => {
      await h.repositories.audit.append({
        guildId: TEST_GUILD_ID,
        botName: 'guardian',
        event: 'security.automod_action',
        severity: 'warn',
        actorId: null,
        targetId: MEMBER,
        source: 'discord.automod',
        // An older consumer version, or a partially written row.
        details: {},
      });
      const number = await openCaseOn();
      const responder = await viewCase(number);

      expect(responder.visibleText).toContain('AUTOMOD');
      // Missing fields become 'unknown' in the projection, which the view
      // then labels honestly rather than printing a bare placeholder.
      expect(responder.visibleText).toContain('unrecognised rule type');
      expect(responder.visibleText).toContain('unrecognised action');
      expect(responder.visibleText).not.toContain('undefined');
    });
  });

  describe('failure handling', () => {
    /*
     * The case view is how moderators work during an incident. Losing it
     * because an enrichment query failed would be a bad trade.
     */
    it('still shows the case when the audit lookup fails', async () => {
      h.repositories.audit.listForTargetByEvent = () =>
        Promise.reject(bloomError('DATABASE_UNAVAILABLE', { operatorHint: 'down' }));

      const number = await openCaseOn();
      const responder = await viewCase(number);

      expect(responder.visibleText).toContain('Pattern of behaviour');
      expect(responder.visibleText).not.toContain('AUTOMOD');
      expect(h.logs.has('moderation.automod_history_unavailable')).toBe(true);
    });

    it('leaks no operator detail to the moderator when the lookup fails', async () => {
      h.repositories.audit.listForTargetByEvent = () =>
        Promise.reject(
          bloomError('DATABASE_UNAVAILABLE', { operatorHint: 'SECRET-DSN' }),
        );

      const number = await openCaseOn();
      expect((await viewCase(number)).visibleText).not.toContain('SECRET-DSN');
    });

    it('reports a missing case rather than an empty one', async () => {
      await seedAutoMod();
      const responder = await viewCase(9999);

      expect(responder.visibleText).not.toContain('AUTOMOD');
      expect(responder.visibleText.toLowerCase()).toContain('case');
    });
  });

  describe('audit semantics', () => {
    /*
     * Viewing is not an event. Writing an audit row every time someone opens
     * a case would bury the rows that record decisions under rows that
     * record curiosity.
     */
    it('writes no audit row merely for viewing', async () => {
      await seedAutoMod();
      const number = await openCaseOn();
      const before = h.repositories.audit.events.length;

      await viewCase(number);
      await viewCase(number);

      expect(h.repositories.audit.events).toHaveLength(before);
    });

    it('does not modify the AutoMod events it displays', async () => {
      await seedAutoMod();
      const number = await openCaseOn();
      const snapshot = JSON.stringify(
        h.repositories.audit.events.filter((e) => e.event === 'security.automod_action'),
      );

      await viewCase(number);

      expect(
        JSON.stringify(
          h.repositories.audit.events.filter(
            (e) => e.event === 'security.automod_action',
          ),
        ),
      ).toBe(snapshot);
    });
  });
});
