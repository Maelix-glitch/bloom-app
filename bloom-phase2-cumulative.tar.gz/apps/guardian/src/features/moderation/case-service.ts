import {
  bloomError,
  initialStatusForReport,
  REPORT_CATEGORY_LABELS,
  type CaseEventType,
  type CaseEvidenceType,
  type CaseStatus,
  type ModerationAction,
  type ChannelId,
  type CorrelationId,
  type GuildId,
  type MessageId,
  type ReportCategory,
  type UserId,
} from '@bloom/shared-types';
import type { Logger } from '@bloom/logging';
import type { PlatformConfig } from '@bloom/config';
import type {
  CaseAssignmentFilter,
  CaseEventRow,
  CaseRow,
  ModerationActionRow,
  ReportRow,
  Repositories,
} from '@bloom/database';
import type { MessagingService } from '@bloom/discord';
import type { AuthorizationSubject } from '@bloom/permissions';
import { sanitiseUserText } from '@bloom/utils';
import * as copy from './messages.js';

/**
 * Cases and reports.
 *
 * A report is not a message in a channel. It is a case with an owner, a status
 * and a history — which is the difference between "somebody mentioned a problem
 * once" and a moderation process that can be audited.
 *
 * ## Privacy
 *
 * `reports.description` is the most sensitive column in the schema: it is one
 * member's account of another member's behaviour. It is written to the staff
 * report channel and to nowhere else. In particular it never appears in an
 * audit row, a log line, an error, or anything the reported member can see.
 */

export interface CaseServiceOptions {
  readonly config: PlatformConfig;
  readonly repositories: Repositories;
  readonly messaging: MessagingService;
  readonly logger: Logger;
}

export interface SubmitReportRequest {
  readonly guildId: GuildId;
  readonly reporter: AuthorizationSubject;
  readonly category: ReportCategory;
  readonly description: string;
  readonly targetUserId?: UserId | null;
  readonly targetChannelId?: ChannelId | null;
  readonly targetMessageId?: MessageId | null;
  readonly correlationId: CorrelationId;
}

export interface SubmitReportResult {
  readonly caseNumber: number;
  readonly status: CaseStatus;
  /** Whether staff were reachable. False means the report is stored but unannounced. */
  readonly staffNotified: boolean;
}

/**
 * One prior AutoMod hit against the case subject, projected for display.
 *
 * A deliberate projection rather than the `AuditEventRow` itself. The audit
 * row carries a `details` jsonb blob, and handing that to the view would
 * make the privacy boundary depend on the view remembering not to print
 * fields — which is the kind of guarantee that holds until someone adds a
 * debug dump. Naming the four fields here means anything else that ever
 * lands in `details` is structurally unable to reach a moderator's screen.
 */
export interface AutoModHistoryEntry {
  readonly ruleId: string;
  readonly action: string;
  readonly trigger: string;
  readonly channelId: ChannelId | null;
  readonly at: Date;
}

/**
 * One moment in a case's life, from whichever system recorded it.
 *
 * A discriminated union rather than a flattened row with optional fields
 * everywhere, because the three sources genuinely differ: a case event has a
 * status transition, a moderation action has a reason and a duration, an
 * AutoMod hit has a rule and no human actor at all. Collapsing them into one
 * shape would mean a dozen nullable fields and a presentation layer guessing
 * which are meaningful for which kind.
 *
 * Every variant is a **projection**. `ModerationActionRow.metadata` and the
 * audit `details` blob are both deliberately absent — the same reasoning as
 * Task 3, applied to the second schemaless column in this feature. Combining
 * sources is exactly the moment a privacy boundary gets quietly widened for
 * convenience, so the allowed fields are named per variant.
 */
export type CaseTimelineEntry =
  | {
      readonly category: 'case';
      readonly at: Date;
      readonly orderKey: string;
      readonly eventType: CaseEventType;
      readonly actorId: UserId | null;
      readonly fromStatus: CaseStatus | null;
      readonly toStatus: CaseStatus | null;
      readonly body: string | null;
      /** Set only on an `evidence_attached` row. */
      readonly evidenceType: CaseEvidenceType | null;
      readonly evidenceSourceId: string | null;
    }
  | {
      readonly category: 'moderation';
      readonly at: Date;
      readonly orderKey: string;
      readonly action: ModerationAction;
      readonly actorId: UserId;
      readonly subjectId: UserId | null;
      readonly channelId: ChannelId | null;
      readonly reason: string;
      readonly durationSeconds: number | null;
    }
  | {
      readonly category: 'automod';
      readonly at: Date;
      readonly orderKey: string;
      readonly ruleId: string;
      readonly action: string;
      readonly trigger: string;
      readonly channelId: ChannelId | null;
    };

/**
 * The result of an attachment attempt.
 *
 * Every rejection is a named outcome rather than a thrown error, because
 * each one maps to a different sentence a moderator needs to read, and
 * none of them is an incident.
 */
export type AttachEvidenceResult =
  | {
      readonly kind: 'attached';
      readonly caseNumber: number;
      readonly evidenceType: CaseEvidenceType;
      readonly sourceId: string;
    }
  | { readonly kind: 'duplicate'; readonly caseNumber: number }
  | { readonly kind: 'case_not_found' }
  | { readonly kind: 'source_not_found' }
  | { readonly kind: 'subject_mismatch' }
  | { readonly kind: 'already_linked_elsewhere' }
  | { readonly kind: 'invalid_source' };

export interface CaseTimeline {
  readonly entries: readonly CaseTimelineEntry[];
  /** How many entries were composed before the display limit was applied. */
  readonly total: number;
  /** True when `entries` is a truncated view of `total`. */
  readonly truncated: boolean;
}

export interface CaseDetail {
  readonly case: CaseRow;
  readonly events: readonly CaseEventRow[];
  readonly report: ReportRow | null;
  readonly actions: readonly ModerationActionRow[];
  /**
   * The three histories merged into one chronology, newest first.
   *
   * The raw arrays above are retained rather than replaced: they are what
   * the service's own callers and tests reason about, and the timeline is a
   * *view* over them rather than a new source of truth.
   */
  readonly timeline: CaseTimeline;
  /**
   * Prior Discord AutoMod activity for the case subject.
   *
   * Empty when the case has no subject, when the member has no AutoMod
   * history, or when the lookup failed — all three are the same thing from
   * the moderator's point of view, and none is worth failing the case view
   * over.
   */
  readonly autoModHistory: readonly AutoModHistoryEntry[];
}

/**
 * How many prior AutoMod hits the case view shows.
 *
 * Small on purpose. This is a "has this happened before, and roughly what"
 * signal, not an audit export — a case view that unrolls forty rows stops
 * being read. The audit trail remains complete underneath; this is only the
 * window onto it.
 */
/**
 * How many timeline entries the case view shows.
 *
 * A working surface, not an export. Twenty is roughly what fits in an embed
 * without the reader scrolling past the point of caring; anything beyond it
 * is reported as a count rather than silently dropped, which is the failure
 * mode this limit replaces.
 */
const TIMELINE_LIMIT = 20;

/**
 * How much each source contributes before merging.
 *
 * 200 is the platform's existing per-query cap, already enforced inside
 * `listEvents` and `listForCase`. Fetching the cap and merging is correct
 * rather than wasteful: each source is ordered independently, so taking the
 * newest twenty of the *merged* set requires more than twenty from each —
 * otherwise a burst in one source would hide newer entries in another.
 */
const SOURCE_FETCH_LIMIT = 200;

const AUTOMOD_HISTORY_LIMIT = SOURCE_FETCH_LIMIT;

/**
 * Merge three histories into one chronology.
 *
 * Pure, and exported so it can be driven directly: ordering and limit
 * enforcement are the kind of logic that is tedious to provoke through a
 * command pipeline and trivial to get subtly wrong.
 *
 * ## Ordering
 *
 * Newest first. The three sources disagreed before this existed — case
 * events rendered oldest-first, AutoMod history newest-first — so there was
 * no existing convention to preserve, only an inconsistency to resolve. A
 * moderator opening a case is asking "what just happened", and the entries
 * most likely to be cut by the limit should be the least recent.
 *
 * Ties are broken by `orderKey`, which embeds the source and the row id.
 * Timestamp collisions are routine here rather than exotic: recording a
 * moderation action writes the action row and a case event in the same
 * transaction, frequently within the same millisecond. Without a total
 * order those two rows could swap places between renders of the same case.
 */
export function buildCaseTimeline(
  sources: {
    readonly events: readonly CaseEventRow[];
    readonly actions: readonly ModerationActionRow[];
    readonly autoMod: readonly AutoModHistoryEntry[];
  },
  limit: number = TIMELINE_LIMIT,
): CaseTimeline {
  const entries: CaseTimelineEntry[] = [
    ...sources.events.map((event): CaseTimelineEntry => ({
      category: 'case',
      at: event.createdAt,
      orderKey: `case:${event.id}`,
      eventType: event.eventType,
      actorId: event.actorId,
      fromStatus: event.fromStatus,
      toStatus: event.toStatus,
      body: event.body,
      evidenceType: event.evidenceType,
      evidenceSourceId: event.evidenceSourceId,
    })),
    ...sources.actions.map((action): CaseTimelineEntry => ({
      category: 'moderation',
      at: action.createdAt,
      orderKey: `moderation:${action.id}`,
      action: action.action,
      actorId: action.actorId,
      subjectId: action.subjectId,
      channelId: action.channelId,
      reason: action.reason,
      durationSeconds: action.durationSeconds,
      // `metadata` is deliberately not carried. See the union's comment.
    })),
    ...sources.autoMod.map((hit, index): CaseTimelineEntry => ({
      category: 'automod',
      at: hit.at,
      /*
       * Audit rows reach this projection without their id, so position in
       * the already-deterministic repository ordering stands in for one.
       *
       * Inverted, and that inversion is load-bearing. The repository
       * returns newest first, so index 0 is the *newest* hit — while the
       * tie-break below sorts keys descending. Encoding the index
       * directly would therefore reverse AutoMod entries relative to each
       * other whenever their timestamps collide, which with a shared
       * millisecond is routine rather than rare. Subtracting from the
       * bound makes a higher key mean newer, so the two agree.
       *
       * Padded so string comparison matches numeric order: '10' must not
       * sort before '9'.
       */
      orderKey: `automod:${String(9999 - index).padStart(4, '0')}`,
      ruleId: hit.ruleId,
      action: hit.action,
      trigger: hit.trigger,
      channelId: hit.channelId,
    })),
  ];

  entries.sort((a, b) => {
    const byTime = b.at.getTime() - a.at.getTime();
    if (byTime !== 0) return byTime;
    // Descending, so the comparison is a total order rather than a partial
    // one. Equal keys cannot occur: each embeds its source and a unique id.
    return a.orderKey < b.orderKey ? 1 : a.orderKey > b.orderKey ? -1 : 0;
  });

  const bounded = Math.max(Math.trunc(limit), 0);
  return {
    entries: entries.slice(0, bounded),
    total: entries.length,
    truncated: entries.length > bounded,
  };
}

/** The event name written by the AutoMod consumer. One source of truth. */
const AUTOMOD_EVENT = 'security.automod_action';

/**
 * Read one string field out of an audit `details` blob.
 *
 * `details` is `jsonb`, so its shape is a convention rather than a
 * guarantee, and rows written by an older version of the consumer may be
 * missing fields entirely. Anything absent or non-string renders as
 * 'unknown' rather than as `undefined` on a moderator's screen.
 */
function detailString(details: Record<string, unknown>, key: string): string {
  const value = details[key];
  return typeof value === 'string' && value.length > 0 ? value : 'unknown';
}

export class CaseService {
  public constructor(private readonly options: CaseServiceOptions) {}

  // ---------------------------------------------------------------------------
  // Reports
  // ---------------------------------------------------------------------------

  public async submitReport(request: SubmitReportRequest): Promise<SubmitReportResult> {
    const description = sanitiseUserText(request.description, 1800);
    if (description.length < 10) {
      throw bloomError('INVALID_INPUT', {
        userMessage:
          'Please describe what happened in a little more detail — at least a sentence.',
      });
    }

    if (!request.targetUserId && !request.targetMessageId) {
      throw bloomError('INVALID_INPUT', {
        userMessage: 'A report needs to name a member or point at a message.',
      });
    }

    // Reporting yourself is almost always a mis-click on a user picker. It also
    // makes the staff queue confusing, so it is refused rather than filed.
    if (request.targetUserId === request.reporter.userId) {
      throw bloomError('INVALID_INPUT', {
        userMessage: 'You cannot file a report against yourself.',
      });
    }

    /*
     * Safety reports skip the queue.
     *
     * A report about someone's safety opened as OPEN sits behind whatever else
     * is in the list. `initialStatusForReport` puts it straight into ESCALATED,
     * and the list ordering surfaces escalated cases first.
     */
    const status = initialStatusForReport(request.category);

    const { case: caseRow } = await this.options.repositories.cases.open(
      {
        guildId: request.guildId,
        origin: 'report',
        openedBy: request.reporter.userId,
        // The summary is derived, never the member's own words: it is shown in
        // list views that are wider than the report channel.
        summary: copy.reportSummary(request.category, request.targetUserId ?? null),
        subjectId: request.targetUserId ?? null,
        category: request.category,
        status,
        correlationId: request.correlationId,
      },
      {
        reporterId: request.reporter.userId,
        category: request.category,
        description,
        targetUserId: request.targetUserId ?? null,
        targetChannelId: request.targetChannelId ?? null,
        targetMessageId: request.targetMessageId ?? null,
      },
    );

    await this.options.repositories.audit.append({
      guildId: request.guildId,
      botName: 'guardian',
      event: 'moderation.report_filed',
      severity: status === 'ESCALATED' ? 'error' : 'warn',
      actorId: request.reporter.userId,
      ...(request.targetUserId ? { targetId: request.targetUserId } : {}),
      source: 'command:/report',
      correlationId: request.correlationId,
      // Category and case number only. The description is deliberately absent:
      // audit rows are read far more widely than the report channel.
      details: { case_number: caseRow.caseNumber, category: request.category },
    });

    const staffNotified = await this.announceToStaff(
      request.guildId,
      caseRow,
      description,
      request,
    );

    return { caseNumber: caseRow.caseNumber, status, staffNotified };
  }

  /**
   * Post the report into the staff channel.
   *
   * Returns `false` when there is nowhere to post — an unconfigured
   * `CHANNEL_REPORTS`, or a send failure. The reporter is then told plainly
   * that their report was recorded but staff were not alerted, because the
   * alternative is thanking them for a report nobody will read.
   */
  private async announceToStaff(
    guildId: GuildId,
    caseRow: CaseRow,
    description: string,
    request: SubmitReportRequest,
  ): Promise<boolean> {
    const channelId = this.options.config.channels.reports;
    if (!channelId) {
      this.options.logger.error(
        'moderation.reports_channel_missing',
        'A report was filed but CHANNEL_REPORTS is not configured, so nobody was alerted.',
        { context: { case_number: caseRow.caseNumber } },
      );
      return false;
    }

    try {
      await this.options.messaging.sendToChannel(
        guildId,
        channelId,
        copy.staffReportMessage(caseRow, description, {
          reporterId: request.reporter.userId,
          targetUserId: request.targetUserId ?? null,
          targetChannelId: request.targetChannelId ?? null,
          targetMessageId: request.targetMessageId ?? null,
        }),
      );
      return true;
    } catch (error) {
      this.options.logger.error(
        'moderation.report_announce_failed',
        'A report was stored but could not be posted to the reports channel.',
        {
          context: { case_number: caseRow.caseNumber, channel_id: channelId },
          ...(error instanceof Error ? { error } : {}),
        },
      );
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Cases
  // ---------------------------------------------------------------------------

  public async openCase(request: {
    readonly guildId: GuildId;
    readonly actor: AuthorizationSubject;
    readonly summary: string;
    readonly subjectId?: UserId | null;
    readonly correlationId: CorrelationId;
  }): Promise<CaseRow> {
    const summary = sanitiseUserText(request.summary, 280);
    if (summary.length < 3) {
      throw bloomError('INVALID_INPUT', {
        userMessage: 'A case needs a short summary.',
      });
    }

    const { case: caseRow } = await this.options.repositories.cases.open({
      guildId: request.guildId,
      origin: 'moderator',
      openedBy: request.actor.userId,
      summary,
      subjectId: request.subjectId ?? null,
      correlationId: request.correlationId,
    });

    await this.options.repositories.audit.append({
      guildId: request.guildId,
      botName: 'guardian',
      event: 'moderation.case_opened',
      severity: 'info',
      actorId: request.actor.userId,
      ...(request.subjectId ? { targetId: request.subjectId } : {}),
      source: 'command:/guardian case open',
      correlationId: request.correlationId,
      details: { case_number: caseRow.caseNumber },
    });

    return caseRow;
  }

  public async detail(guildId: GuildId, caseNumber: number): Promise<CaseDetail | null> {
    const caseRow = await this.options.repositories.cases.findByNumber(
      guildId,
      caseNumber,
    );
    if (!caseRow) return null;

    /*
     * Four reads, one round trip's worth of latency.
     *
     * `listForCase` used to run in the command handler *after* this method
     * returned, which made the case view two sequential round trips for no
     * reason. Folding it in here is what lets the timeline be composed in
     * one place, and costs a query less than the arrangement it replaces.
     */
    const [events, report, autoModHistory, actions] = await Promise.all([
      this.options.repositories.cases.listEvents(caseRow.id, SOURCE_FETCH_LIMIT),
      this.options.repositories.cases.findReport(caseRow.id),
      this.autoModHistory(guildId, caseRow.subjectId),
      this.options.repositories.moderation.listForCase(caseRow.id),
    ]);

    return {
      case: caseRow,
      events,
      report,
      actions,
      autoModHistory,
      timeline: buildCaseTimeline({ events, actions, autoMod: autoModHistory }),
    };
  }

  /**
   * Prior AutoMod activity for the case subject.
   *
   * Three properties worth stating:
   *
   *   • **Guild-scoped twice.** The `guildId` passed in is the one the case
   *     was found under, and the query filters on it again. A case from one
   *     guild cannot surface another guild's audit rows even if a subject id
   *     were somehow shared.
   *   • **Subject-scoped.** Keyed on the case's own `subjectId`, never on
   *     anything a caller supplied, so there is no parameter to tamper with
   *     to read a different member's history.
   *   • **Never fatal.** A failure here degrades to an empty section. The
   *     case view is how moderators do their job during an incident, and
   *     losing it because an enrichment query timed out would be a poor
   *     trade for a convenience feature.
   */
  private async autoModHistory(
    guildId: GuildId,
    subjectId: UserId | null,
  ): Promise<readonly AutoModHistoryEntry[]> {
    // No subject, no member history to show, and no reason to spend a query.
    if (!subjectId) return [];

    try {
      const rows = await this.options.repositories.audit.listForTargetByEvent(
        guildId,
        subjectId,
        AUTOMOD_EVENT,
        AUTOMOD_HISTORY_LIMIT,
      );

      return rows.map((row) => ({
        ruleId: detailString(row.details, 'rule_id'),
        action: detailString(row.details, 'action'),
        trigger: detailString(row.details, 'trigger'),
        channelId: row.channelId,
        at: row.createdAt,
      }));
    } catch (error) {
      this.options.logger.warn(
        'moderation.automod_history_unavailable',
        'Could not load AutoMod history for a case; showing the case without it.',
        { guild_id: guildId, target_id: subjectId, error },
      );
      return [];
    }
  }

  /**
   * Record that an existing source row is evidence for a case.
   *
   * The ordering of checks below is the security design, not incidental.
   * Every one of them runs *before* anything is written, and each failure
   * returns the same shape so the caller cannot distinguish "this source
   * does not exist" from "this source belongs to another guild" by timing
   * or by message — a moderator in guild A must not be able to probe guild
   * B's moderation history by feeding ids to this command.
   *
   * The caller supplies `evidenceType` as a *claim*. It is never trusted:
   * the source is resolved through the repository that owns that kind, and
   * an AutoMod reference additionally has to prove it is an AutoMod event
   * rather than any other audit row that happens to share a uuid.
   */
  public async attachEvidence(request: {
    readonly guildId: GuildId;
    readonly actor: AuthorizationSubject;
    readonly caseNumber: number;
    readonly evidenceType: CaseEvidenceType;
    readonly sourceId: string;
    readonly correlationId: CorrelationId;
  }): Promise<AttachEvidenceResult> {
    const sourceId = request.sourceId.trim();
    if (sourceId.length === 0 || sourceId.length > 64) {
      return { kind: 'invalid_source' };
    }

    const caseRow = await this.options.repositories.cases.findByNumber(
      request.guildId,
      request.caseNumber,
    );
    if (!caseRow) return { kind: 'case_not_found' };

    const resolved =
      request.evidenceType === 'moderation_action'
        ? await this.resolveModerationSource(request.guildId, sourceId)
        : await this.resolveAutoModSource(request.guildId, sourceId);

    if (!resolved) return { kind: 'source_not_found' };

    /*
     * The subject gate.
     *
     * Evidence has to be about the person the case is about, or the case
     * record becomes a place to file unrelated history against someone.
     * A case with no subject accepts no member-scoped evidence at all —
     * there is nothing to match against, and "matches nothing" must not
     * degrade into "matches everything".
     */
    if (caseRow.subjectId === null) return { kind: 'subject_mismatch' };
    if (resolved.subjectId !== caseRow.subjectId) return { kind: 'subject_mismatch' };

    /*
     * For a moderation action, point the action at the case as well.
     *
     * This keeps the pre-existing `moderation_actions.case_id` relationship
     * and the new evidence event in agreement rather than inventing a
     * second, competing notion of "belongs to this case". The update is
     * guarded: an action already filed against a *different* case is
     * refused rather than quietly re-filed.
     */
    if (request.evidenceType === 'moderation_action') {
      const linked = await this.options.repositories.moderation.attachToCase({
        guildId: request.guildId,
        id: sourceId,
        caseId: caseRow.id,
      });
      if (!linked) return { kind: 'already_linked_elsewhere' };
    }

    const outcome = await this.options.repositories.cases.attachEvidence({
      caseId: caseRow.id,
      evidenceType: request.evidenceType,
      evidenceSourceId: sourceId,
      actorId: request.actor.userId,
      correlationId: request.correlationId,
    });

    if (outcome.kind === 'duplicate') {
      return { kind: 'duplicate', caseNumber: caseRow.caseNumber };
    }

    await this.options.repositories.audit.append({
      guildId: request.guildId,
      botName: 'guardian',
      event: 'moderation.case_evidence_attached',
      severity: 'info',
      actorId: request.actor.userId,
      targetId: caseRow.subjectId,
      source: 'command:/guardian case evidence-attach',
      correlationId: request.correlationId,
      /*
       * Identifiers only. The audit row says which source was cited, never
       * what the source contained — copying an AutoMod `details` blob or a
       * moderation `metadata` blob in here would route around the privacy
       * boundary by way of the audit trail.
       */
      details: {
        case_number: caseRow.caseNumber,
        evidence_type: request.evidenceType,
        evidence_source_id: sourceId,
      },
    });

    return {
      kind: 'attached',
      caseNumber: caseRow.caseNumber,
      evidenceType: request.evidenceType,
      sourceId,
    };
  }

  /** Resolve a moderation action, guild-scoped inside the query. */
  private async resolveModerationSource(
    guildId: GuildId,
    sourceId: string,
  ): Promise<{ readonly subjectId: UserId | null } | null> {
    const row = await this.options.repositories.moderation.findById(guildId, sourceId);
    return row ? { subjectId: row.subjectId } : null;
  }

  /**
   * Resolve an AutoMod audit event.
   *
   * Two things have to be true, and the second is the one that matters: the
   * row must exist in this guild, *and* it must actually be a
   * `security.automod_action` event. Without that check any audit row — a
   * role change, a rewards grant, another member's report — could be cited
   * as AutoMod evidence simply by knowing its id.
   */
  private async resolveAutoModSource(
    guildId: GuildId,
    sourceId: string,
  ): Promise<{ readonly subjectId: UserId | null } | null> {
    const row = await this.options.repositories.audit.findById(guildId, sourceId);
    if (!row) return null;
    if (row.event !== AUTOMOD_EVENT) return null;
    return { subjectId: row.targetId };
  }

  public async changeStatus(request: {
    readonly guildId: GuildId;
    readonly actor: AuthorizationSubject;
    readonly caseNumber: number;
    readonly to: CaseStatus;
    readonly note?: string | null;
    readonly correlationId: CorrelationId;
  }): Promise<Awaited<ReturnType<Repositories['cases']['transitionStatus']>>> {
    const note = request.note ? sanitiseUserText(request.note, 1000) : null;

    /*
     * RESOLVED carries its outcome. The database enforces this with a CHECK
     * constraint; passing the note through as the resolution is what makes the
     * command usable — a moderator types the outcome once.
     */
    const outcome = await this.options.repositories.cases.transitionStatus({
      guildId: request.guildId,
      caseNumber: request.caseNumber,
      to: request.to,
      actorId: request.actor.userId,
      note,
      resolution: request.to === 'RESOLVED' ? note : null,
      correlationId: request.correlationId,
    });

    if (outcome.kind === 'applied') {
      await this.options.repositories.audit.append({
        guildId: request.guildId,
        botName: 'guardian',
        event: 'moderation.case_status_changed',
        severity: 'info',
        actorId: request.actor.userId,
        source: 'command:/guardian case status',
        correlationId: request.correlationId,
        details: {
          case_number: request.caseNumber,
          from: outcome.from,
          to: outcome.to,
        },
      });
    }

    return outcome;
  }

  public async assign(request: {
    readonly guildId: GuildId;
    readonly actor: AuthorizationSubject;
    readonly caseNumber: number;
    readonly assignee: UserId | null;
    readonly correlationId: CorrelationId;
  }): Promise<CaseRow | null> {
    const updated = await this.options.repositories.cases.assign({
      guildId: request.guildId,
      caseNumber: request.caseNumber,
      assignee: request.assignee,
      actorId: request.actor.userId,
      correlationId: request.correlationId,
    });

    if (updated) {
      await this.options.repositories.audit.append({
        guildId: request.guildId,
        botName: 'guardian',
        event: 'moderation.case_assigned',
        severity: 'info',
        actorId: request.actor.userId,
        ...(request.assignee ? { targetId: request.assignee } : {}),
        source: 'command:/guardian case assign',
        correlationId: request.correlationId,
        details: { case_number: request.caseNumber },
      });
    }

    return updated;
  }

  public async addNote(request: {
    readonly guildId: GuildId;
    readonly actor: AuthorizationSubject;
    readonly caseNumber: number;
    readonly body: string;
    readonly correlationId: CorrelationId;
  }): Promise<boolean> {
    const body = sanitiseUserText(request.body, 1900);
    if (body.length === 0) {
      throw bloomError('INVALID_INPUT', { userMessage: 'The note is empty.' });
    }

    const caseRow = await this.options.repositories.cases.findByNumber(
      request.guildId,
      request.caseNumber,
    );
    if (!caseRow) return false;

    await this.options.repositories.cases.appendEvent({
      caseId: caseRow.id,
      eventType: 'note',
      actorId: request.actor.userId,
      body,
      correlationId: request.correlationId,
    });

    return true;
  }

  public list(
    guildId: GuildId,
    filter?: {
      readonly status?: CaseStatus | null;
      readonly assignedTo?: UserId | null;
      readonly assignment?: CaseAssignmentFilter | null;
      readonly limit?: number;
    },
  ): Promise<readonly CaseRow[]> {
    return this.options.repositories.cases.list(guildId, {
      status: filter?.status ?? null,
      assignedTo: filter?.assignedTo ?? null,
      assignment: filter?.assignment ?? null,
      limit: filter?.limit ?? 15,
    });
  }

  public counts(guildId: GuildId): Promise<Readonly<Record<CaseStatus, number>>> {
    return this.options.repositories.cases.countByStatus(guildId);
  }
}

export { REPORT_CATEGORY_LABELS };
