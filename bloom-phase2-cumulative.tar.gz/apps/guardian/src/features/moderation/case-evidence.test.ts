import { beforeEach, describe, expect, it } from 'vitest';
import { unsafeSnowflake, type GuildId, type UserId } from '@bloom/shared-types';
import { newCorrelationId } from '@bloom/utils';
import {
  TEST_CHANNEL_IDS,
  TEST_GUILD_ID,
  TEST_ROLE_IDS,
  TEST_USER_IDS,
  testSubject,
  type RecordingResponder,
} from '@bloom/testing';
import { guardianHarness, type GuardianHarness } from '../../guardian.harness.js';
import { moderationSubcommands } from './commands.js';

/**
 * Case evidence attachment.
 *
 * Driven through the real dispatcher, because the properties worth proving
 * are pipeline properties: the capability gate, guild scoping, and the
 * refusal messages a moderator actually sees. The thing under test is not
 * "does a row get written" but "can this command be used to learn or change
 * something it should not".
 */

const REFUSAL = 'Not available to you';

let h: GuardianHarness;

const MEMBER = TEST_USER_IDS.member;
const OTHER_MEMBER = TEST_USER_IDS.betaTester;
const MODERATOR = TEST_USER_IDS.moderator;

const asMember = (): ReturnType<typeof testSubject> =>
  testSubject({ userId: MEMBER, roles: ['bloomMember'] });
const asModerator = (): ReturnType<typeof testSubject> =>
  testSubject({ userId: MODERATOR, roles: ['moderator'] });

beforeEach(() => {
  h = guardianHarness();
  h.guild.withMember(MEMBER);
  h.guild.withMember(OTHER_MEMBER);
  h.guild.withMember(MODERATOR, { roleIds: [TEST_ROLE_IDS.moderator] });
});

async function openCaseOn(subjectId: UserId | null = MEMBER): Promise<number> {
  const { case: row } = await h.repositories.cases.open({
    guildId: TEST_GUILD_ID,
    origin: 'moderator',
    openedBy: MODERATOR,
    summary: 'A case under review.',
    subjectId,
    category: null,
    status: 'OPEN',
    correlationId: newCorrelationId(),
  });
  return row.caseNumber;
}

/** An existing moderation action, not yet filed against any case. */
async function seedAction(
  options: { readonly guildId?: GuildId; readonly subjectId?: UserId } = {},
): Promise<string> {
  const row = await h.repositories.moderation.record({
    guildId: options.guildId ?? TEST_GUILD_ID,
    action: 'warn',
    subjectId: options.subjectId ?? MEMBER,
    actorId: MODERATOR,
    reason: 'Repeated disruption.',
    correlationId: newCorrelationId(),
  });
  return row.id;
}

/** An existing AutoMod audit event, as the Task-2 consumer writes one. */
async function seedAutoMod(
  options: {
    readonly guildId?: GuildId;
    readonly targetId?: UserId;
    readonly event?: string;
    readonly extraDetails?: Record<string, unknown>;
  } = {},
): Promise<string> {
  return await h.repositories.audit.append({
    guildId: options.guildId ?? TEST_GUILD_ID,
    botName: 'guardian',
    event: options.event ?? 'security.automod_action',
    severity: 'warn',
    actorId: null,
    targetId: options.targetId ?? MEMBER,
    channelId: TEST_CHANNEL_IDS.welcome,
    source: 'discord.automod',
    details: {
      rule_id: '200000000000111111',
      trigger: 'spam',
      action: 'timeout',
      ...(options.extraDetails ?? {}),
    },
  });
}

async function attach(
  caseNumber: number,
  type: string,
  source: string,
  actor = asModerator(),
): Promise<RecordingResponder> {
  const { responder } = await h.dispatch({
    commandName: 'guardian',
    subcommandGroup: 'case',
    subcommand: 'evidence-attach',
    actor,
    options: { integers: { number: caseNumber }, strings: { type, source } },
  });
  return responder;
}

const evidenceRows = () =>
  h.repositories.cases.events.filter((e) => e.eventType === 'evidence_attached');

describe('case evidence attachment', () => {
  describe('moderation actions', () => {
    it('attaches a valid moderation action', async () => {
      const number = await openCaseOn();
      const actionId = await seedAction();

      const responder = await attach(number, 'moderation_action', actionId);

      expect(responder.visibleText).toContain('evidence');
      expect(evidenceRows()).toHaveLength(1);
      expect(evidenceRows()[0]).toMatchObject({
        evidenceType: 'moderation_action',
        evidenceSourceId: actionId,
        actorId: MODERATOR,
      });
    });

    /*
     * The pre-existing `moderation_actions.case_id` relationship and the new
     * evidence event have to agree, or the case has two competing notions of
     * what belongs to it.
     */
    it('files the action against the case as well', async () => {
      const number = await openCaseOn();
      const actionId = await seedAction();
      await attach(number, 'moderation_action', actionId);

      const action = await h.repositories.moderation.findById(TEST_GUILD_ID, actionId);
      expect(action?.caseId).not.toBeNull();
    });

    it('rejects an action that does not exist', async () => {
      const number = await openCaseOn();
      const responder = await attach(number, 'moderation_action', '999999');

      expect(responder.visibleText).toContain('No such evidence');
      expect(evidenceRows()).toHaveLength(0);
    });

    /*
     * Re-filing evidence out of one case and into another is a history
     * rewrite. Refused rather than silently performed.
     */
    it('refuses an action already filed against a different case', async () => {
      const first = await openCaseOn();
      const second = await openCaseOn();
      const actionId = await seedAction();

      await attach(first, 'moderation_action', actionId);
      const responder = await attach(second, 'moderation_action', actionId);

      expect(responder.visibleText).toContain('already filed against another case');
      expect(evidenceRows()).toHaveLength(1);
    });
  });

  describe('AutoMod events', () => {
    it('attaches a valid AutoMod event', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();

      const responder = await attach(number, 'automod_event', auditId);

      expect(responder.visibleText).toContain('evidence');
      expect(evidenceRows()[0]).toMatchObject({
        evidenceType: 'automod_event',
        evidenceSourceId: auditId,
      });
    });

    it('rejects an audit event that does not exist', async () => {
      const number = await openCaseOn();
      const responder = await attach(number, 'automod_event', 'no-such-audit-id');

      expect(responder.visibleText).toContain('No such evidence');
      expect(evidenceRows()).toHaveLength(0);
    });

    /*
     * The check that matters. Without it, any audit row — a role change, a
     * rewards grant, another member's report — could be cited as AutoMod
     * evidence by anyone who knows its id.
     */
    it('refuses an audit event that is not an AutoMod event', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod({ event: 'moderation.warn_issued' });

      const responder = await attach(number, 'automod_event', auditId);

      expect(responder.visibleText).toContain('No such evidence');
      expect(evidenceRows()).toHaveLength(0);
    });

    it('refuses an AutoMod event from another guild', async () => {
      const number = await openCaseOn();
      const foreign = await seedAutoMod({
        guildId: unsafeSnowflake<GuildId>('999900000000000009'),
      });

      const responder = await attach(number, 'automod_event', foreign);

      expect(responder.visibleText).toContain('No such evidence');
      expect(evidenceRows()).toHaveLength(0);
    });

    it('refuses an AutoMod event about a different member', async () => {
      const number = await openCaseOn(MEMBER);
      const auditId = await seedAutoMod({ targetId: OTHER_MEMBER });

      const responder = await attach(number, 'automod_event', auditId);

      expect(responder.visibleText).toContain('different member');
      expect(evidenceRows()).toHaveLength(0);
    });
  });

  describe('validation', () => {
    it('rejects a case that does not exist', async () => {
      const auditId = await seedAutoMod();
      const responder = await attach(4242, 'automod_event', auditId);

      expect(responder.visibleText).toContain('no case');
      expect(evidenceRows()).toHaveLength(0);
    });

    it('rejects an unsupported evidence type', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();
      const responder = await attach(number, 'something_else', auditId);

      expect(responder.visibleText).toContain('No such evidence');
      expect(evidenceRows()).toHaveLength(0);
    });

    it('rejects a malformed source identifier', async () => {
      const number = await openCaseOn();

      for (const bad of ['', '   ', 'x'.repeat(65)]) {
        const responder = await attach(number, 'automod_event', bad);
        expect(responder.visibleText).toContain('No such evidence');
      }
      expect(evidenceRows()).toHaveLength(0);
    });

    /*
     * A source that cannot possibly resolve should not cost a round trip.
     * Rejected on shape before anything is looked up.
     */
    it('looks nothing up for an unusable source identifier', async () => {
      const number = await openCaseOn();
      let lookups = 0;
      const real = h.repositories.audit.findById.bind(h.repositories.audit);
      h.repositories.audit.findById = (...args) => {
        lookups += 1;
        return real(...args);
      };

      await attach(number, 'automod_event', '   ');
      expect(lookups).toBe(0);

      await attach(number, 'automod_event', 'plausible-id');
      expect(lookups).toBe(1);
    });

    /*
     * A case with no subject has nothing for evidence to be *about*.
     * "Matches nothing" must not degrade into "matches anything".
     */
    /*
     * Both sides null is the case the guard exists for. A purge or a
     * slowmode carries no subject, and a case opened without one carries no
     * subject either — without the explicit null check, `null !== null` is
     * false and evidence about nobody would attach to a case about nobody.
     */
    it('refuses a subjectless source on a subjectless case', async () => {
      const number = await openCaseOn(null);
      const purge = await h.repositories.moderation.record({
        guildId: TEST_GUILD_ID,
        action: 'purge',
        subjectId: null,
        actorId: MODERATOR,
        reason: 'Cleared spam.',
        correlationId: newCorrelationId(),
      });

      const responder = await attach(number, 'moderation_action', purge.id);

      expect(responder.visibleText).toContain('different member');
      expect(evidenceRows()).toHaveLength(0);
    });

    it('refuses evidence on a case with no subject', async () => {
      const number = await openCaseOn(null);
      const auditId = await seedAutoMod();

      const responder = await attach(number, 'automod_event', auditId);

      expect(responder.visibleText).toContain('different member');
      expect(evidenceRows()).toHaveLength(0);
    });

    /*
     * Every source rejection reads the same, so the command cannot be used
     * to probe another guild's data one id at a time.
     */
    it('does not distinguish missing from cross-guild in the reply', async () => {
      const number = await openCaseOn();
      const foreign = await seedAutoMod({
        guildId: unsafeSnowflake<GuildId>('999900000000000009'),
      });

      const missing = (await attach(number, 'automod_event', 'no-such-id')).visibleText;
      const crossGuild = (await attach(number, 'automod_event', foreign)).visibleText;

      expect(crossGuild).toBe(missing);
    });
  });

  describe('authorization', () => {
    it('allows a moderator holding cases.manage', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();

      expect((await attach(number, 'automod_event', auditId)).visibleText).not.toContain(
        REFUSAL,
      );
    });

    it('refuses a non-staff member', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();

      const responder = await attach(number, 'automod_event', auditId, asMember());

      expect(responder.visibleText).toContain(REFUSAL);
      expect(evidenceRows()).toHaveLength(0);
    });

    /*
     * Pinned structurally, because no role in this platform holds
     * `staff.cases.read` *without* `staff.cases.manage` — so a role-driven
     * test cannot tell the two apart, and silently downgrading the gate to
     * the read capability would go unnoticed. The denial carries the
     * capability it demanded, which is the thing worth asserting.
     */
    it('is gated on the case *manage* capability, not merely read', () => {
      const contribution = moderationSubcommands.find(
        (entry) => entry.group === 'case' && entry.spec.name === 'evidence-attach',
      );
      expect(contribution).toBeDefined();

      const decision = contribution?.policy?.call(null, {
        subject: testSubject({ userId: MEMBER, roles: ['bloomMember'] }),
        config: h.deps.config,
      } as never);

      expect(decision?.ok).toBe(false);
      const details = (decision as { error?: { details?: Record<string, unknown> } })
        .error?.details;
      expect(details?.['required_staff_capabilities']).toEqual(['staff.cases.manage']);
    });

    it('refuses a staff actor from another guild', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();
      const foreign = {
        ...asModerator(),
        guildId: unsafeSnowflake<GuildId>('999900000000000009'),
      };

      await attach(number, 'automod_event', auditId, foreign);
      expect(evidenceRows()).toHaveLength(0);
    });
  });

  describe('idempotency', () => {
    it('reports a duplicate without writing a second row', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();

      await attach(number, 'automod_event', auditId);
      const responder = await attach(number, 'automod_event', auditId);

      expect(responder.visibleText).toContain('already attached');
      expect(evidenceRows()).toHaveLength(1);
    });

    it('handles concurrent duplicate attempts', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();

      await Promise.all([
        attach(number, 'automod_event', auditId),
        attach(number, 'automod_event', auditId),
        attach(number, 'automod_event', auditId),
      ]);

      expect(evidenceRows()).toHaveLength(1);
    });

    /*
     * One event can legitimately be evidence in two investigations. The
     * uniqueness is per case, which is what the partial index enforces.
     */
    it('allows the same AutoMod event as evidence for two cases', async () => {
      const first = await openCaseOn();
      const second = await openCaseOn();
      const auditId = await seedAutoMod();

      await attach(first, 'automod_event', auditId);
      const responder = await attach(second, 'automod_event', auditId);

      expect(responder.visibleText).not.toContain('already attached');
      expect(evidenceRows()).toHaveLength(2);
    });
  });

  describe('audit', () => {
    it('records who attached what, without the payload', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();
      await attach(number, 'automod_event', auditId);

      const entry = h.repositories.audit.events.find(
        (e) => e.event === 'moderation.case_evidence_attached',
      );
      expect(entry).toBeDefined();
      expect(entry?.actorId).toBe(MODERATOR);
      expect(entry?.targetId).toBe(MEMBER);
      expect(entry?.correlationId).toBeTruthy();
      expect(entry?.details).toStrictEqual({
        case_number: number,
        evidence_type: 'automod_event',
        evidence_source_id: auditId,
      });
      // Exactly these three keys. The audit trail must not become a second
      // route around the projection by accumulating 'helpful' extras.
      expect(Object.keys(entry?.details ?? {}).sort()).toEqual([
        'case_number',
        'evidence_source_id',
        'evidence_type',
      ]);
    });

    it('writes no audit row for a rejected attachment', async () => {
      const number = await openCaseOn();
      const before = h.repositories.audit.events.length;

      await attach(number, 'automod_event', 'no-such-id');

      expect(h.repositories.audit.events).toHaveLength(before);
    });

    it('leaves the original source event untouched', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();
      const before = JSON.stringify(
        h.repositories.audit.events.find((e) => e.event === 'security.automod_action'),
      );

      await attach(number, 'automod_event', auditId);

      expect(
        JSON.stringify(
          h.repositories.audit.events.find((e) => e.event === 'security.automod_action'),
        ),
      ).toBe(before);
    });
  });

  describe('privacy', () => {
    /*
     * The reference is an id. Even when the source row carries forbidden
     * fields, nothing but that id crosses into the case record or the audit
     * trail.
     */
    it('stores only a reference, never the source payload', async () => {
      const forbidden = 'FORBIDDEN-MESSAGE-TEXT';
      const number = await openCaseOn();
      const auditId = await seedAutoMod({
        extraDetails: {
          content: forbidden,
          matched_content: forbidden,
          matched_keyword: forbidden,
        },
      });

      await attach(number, 'automod_event', auditId);

      expect(JSON.stringify(evidenceRows())).not.toContain(forbidden);
      const attachAudit = h.repositories.audit.events.find(
        (e) => e.event === 'moderation.case_evidence_attached',
      );
      expect(JSON.stringify(attachAudit)).not.toContain(forbidden);
      expect(JSON.stringify(attachAudit)).not.toContain('matched_keyword');
    });

    it('never leaks moderation metadata into the case record', async () => {
      const number = await openCaseOn();
      const action = await h.repositories.moderation.record({
        guildId: TEST_GUILD_ID,
        action: 'warn',
        subjectId: MEMBER,
        actorId: MODERATOR,
        reason: 'Disruption.',
        metadata: { secret: 'SHOULD-NOT-SURVIVE' },
        correlationId: newCorrelationId(),
      });

      await attach(number, 'moderation_action', action.id);

      expect(JSON.stringify(evidenceRows())).not.toContain('SHOULD-NOT-SURVIVE');
      expect(JSON.stringify(h.repositories.audit.events)).not.toContain(
        'SHOULD-NOT-SURVIVE',
      );
    });
  });

  describe('timeline', () => {
    async function viewCase(number: number): Promise<RecordingResponder> {
      const { responder } = await h.dispatch({
        commandName: 'guardian',
        subcommandGroup: 'case',
        subcommand: 'view',
        actor: asModerator(),
        options: { integers: { number } },
      });
      return responder;
    }

    it('shows the attachment in the timeline', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();
      await attach(number, 'automod_event', auditId);

      const text = (await viewCase(number)).visibleText;

      expect(text).toContain('Timeline');
      expect(text).toContain('as evidence');
      expect(text).toContain('AutoMod');
    });

    /*
     * The attachment is a separate moment from the event it cites. Merging
     * them would make the AutoMod hit appear to have happened when the
     * paperwork was filed.
     */
    it('keeps the original event at its own timestamp', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();
      await attach(number, 'automod_event', auditId);

      const detail = await h.deps.cases.detail(TEST_GUILD_ID, number);
      const attachment = detail?.timeline.entries.find(
        (entry) => entry.category === 'case' && entry.eventType === 'evidence_attached',
      );
      const original = detail?.timeline.entries.find(
        (entry) => entry.category === 'automod',
      );

      expect(attachment).toBeDefined();
      expect(original).toBeDefined();
      // Two distinct entries, not one merged row.
      expect(attachment?.orderKey).not.toBe(original?.orderKey);
    });

    it('never renders source content in the timeline', async () => {
      const forbidden = 'FORBIDDEN-MESSAGE-TEXT';
      const number = await openCaseOn();
      const auditId = await seedAutoMod({ extraDetails: { content: forbidden } });
      await attach(number, 'automod_event', auditId);

      expect((await viewCase(number)).visibleText).not.toContain(forbidden);
    });

    it('stays deterministic across repeated renders', async () => {
      const number = await openCaseOn();
      const auditId = await seedAutoMod();
      const actionId = await seedAction();
      await attach(number, 'automod_event', auditId);
      await attach(number, 'moderation_action', actionId);

      const first = (await viewCase(number)).visibleText;
      for (let run = 0; run < 3; run += 1) {
        expect((await viewCase(number)).visibleText).toBe(first);
      }
    });
  });
});
