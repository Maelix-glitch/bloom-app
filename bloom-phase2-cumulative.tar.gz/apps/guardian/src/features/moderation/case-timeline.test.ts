import { beforeEach, describe, expect, it } from 'vitest';
import {
  unsafeSnowflake,
  bloomError,
  type GuildId,
  type UserId,
} from '@bloom/shared-types';
import { newCorrelationId } from '@bloom/utils';
import {
  TEST_CHANNEL_IDS,
  TEST_GUILD_ID,
  TEST_ROLE_IDS,
  TEST_USER_IDS,
  testSubject,
  type RecordingResponder,
} from '@bloom/testing';
import { guardianHarness, type GuardianHarness } from '../../guardian.harness.js';
import { buildCaseTimeline } from './case-service.js';
import type { CaseEventRow, ModerationActionRow } from '@bloom/database';

/**
 * The unified case timeline.
 *
 * Split deliberately. The merge itself — ordering, tie-breaking, bounding —
 * is a pure function and is driven directly, because provoking a
 * millisecond-level timestamp collision through a command pipeline is
 * tedious and the resulting test would not say what it means. Everything
 * that is a property of the *pipeline* — authorization, scoping, privacy —
 * goes through a real dispatch, because that is where those live.
 */

const REFUSAL = 'Not available to you';
const AT = new Date('2026-03-01T10:00:00.000Z');

function caseEvent(overrides: Partial<CaseEventRow> = {}): CaseEventRow {
  return {
    id: 'ce-1',
    caseId: 'case-1',
    eventType: 'opened',
    fromStatus: null,
    toStatus: 'OPEN',
    actorId: TEST_USER_IDS.moderator,
    body: null,
    evidenceType: null,
    evidenceSourceId: null,
    createdAt: AT,
    ...overrides,
  };
}

function action(overrides: Partial<ModerationActionRow> = {}): ModerationActionRow {
  return {
    id: 'ma-1',
    guildId: TEST_GUILD_ID,
    caseId: 'case-1',
    action: 'warn',
    subjectId: TEST_USER_IDS.member,
    channelId: null,
    actorId: TEST_USER_IDS.moderator,
    reason: 'Repeated disruption.',
    durationSeconds: null,
    expiresAt: null,
    revokedAt: null,
    revokedBy: null,
    revokedReason: null,
    metadata: {},
    createdAt: AT,
    ...overrides,
  };
}

const autoMod = (overrides: Record<string, unknown> = {}) => ({
  ruleId: '200000000000111111',
  action: 'block_message',
  trigger: 'keyword',
  channelId: null,
  at: AT,
  ...overrides,
});

describe('buildCaseTimeline', () => {
  it('is empty when every source is', () => {
    const timeline = buildCaseTimeline({ events: [], actions: [], autoMod: [] });
    expect(timeline.entries).toEqual([]);
    expect(timeline.total).toBe(0);
    expect(timeline.truncated).toBe(false);
  });

  it('carries case events alone', () => {
    const timeline = buildCaseTimeline({
      events: [caseEvent()],
      actions: [],
      autoMod: [],
    });
    expect(timeline.entries).toHaveLength(1);
    expect(timeline.entries[0]?.category).toBe('case');
  });

  it('carries moderation actions alone', () => {
    const timeline = buildCaseTimeline({ events: [], actions: [action()], autoMod: [] });
    expect(timeline.entries[0]?.category).toBe('moderation');
  });

  it('carries AutoMod events alone', () => {
    const timeline = buildCaseTimeline({ events: [], actions: [], autoMod: [autoMod()] });
    expect(timeline.entries[0]?.category).toBe('automod');
  });

  it('interleaves all three by time, newest first', () => {
    const timeline = buildCaseTimeline({
      events: [caseEvent({ createdAt: new Date('2026-03-01T10:00:00.000Z') })],
      actions: [action({ createdAt: new Date('2026-03-01T12:00:00.000Z') })],
      autoMod: [autoMod({ at: new Date('2026-03-01T11:00:00.000Z') })],
    });

    expect(timeline.entries.map((entry) => entry.category)).toEqual([
      'moderation',
      'automod',
      'case',
    ]);
  });

  describe('ordering determinism', () => {
    /*
     * Not an exotic case. Recording a moderation action writes the action
     * row and a case event in one transaction, routinely inside the same
     * millisecond.
     */
    it('breaks timestamp ties with a stable total order', () => {
      const build = () =>
        buildCaseTimeline({
          events: [caseEvent({ id: 'ce-a' }), caseEvent({ id: 'ce-b' })],
          actions: [action({ id: 'ma-a' }), action({ id: 'ma-b' })],
          autoMod: [autoMod({ ruleId: 'r1' }), autoMod({ ruleId: 'r2' })],
        });

      const first = build().entries.map((entry) => entry.orderKey);
      for (let run = 0; run < 5; run += 1) {
        expect(build().entries.map((entry) => entry.orderKey)).toEqual(first);
      }
      // A total order: no two entries share a key.
      expect(new Set(first).size).toBe(first.length);
    });

    it('does not depend on the order sources are supplied in', () => {
      const a = caseEvent({ id: 'ce-a' });
      const b = caseEvent({ id: 'ce-b' });

      expect(
        buildCaseTimeline({ events: [a, b], actions: [], autoMod: [] }).entries.map(
          (entry) => entry.orderKey,
        ),
      ).toEqual(
        buildCaseTimeline({ events: [b, a], actions: [], autoMod: [] }).entries.map(
          (entry) => entry.orderKey,
        ),
      );
    });

    /*
     * The repository returns AutoMod hits newest first. When their
     * timestamps collide, that order must survive the merge rather than be
     * inverted by the tie-break.
     */
    it('preserves AutoMod repository order under a timestamp tie', () => {
      const timeline = buildCaseTimeline({
        events: [],
        actions: [],
        autoMod: [autoMod({ ruleId: 'newest' }), autoMod({ ruleId: 'oldest' })],
      });

      const rules = timeline.entries.map((entry) =>
        entry.category === 'automod' ? entry.ruleId : '',
      );
      expect(rules).toEqual(['newest', 'oldest']);
    });
  });

  describe('bounding', () => {
    it('caps the entries and reports the true total', () => {
      const events = Array.from({ length: 50 }, (_, index) =>
        caseEvent({
          id: `ce-${String(index)}`,
          createdAt: new Date(AT.getTime() + index),
        }),
      );
      const timeline = buildCaseTimeline({ events, actions: [], autoMod: [] }, 20);

      expect(timeline.entries).toHaveLength(20);
      expect(timeline.total).toBe(50);
      expect(timeline.truncated).toBe(true);
    });

    it('keeps the newest when it truncates', () => {
      const events = Array.from({ length: 30 }, (_, index) =>
        caseEvent({
          id: `ce-${String(index)}`,
          createdAt: new Date(AT.getTime() + index),
        }),
      );
      const timeline = buildCaseTimeline({ events, actions: [], autoMod: [] }, 5);

      expect(timeline.entries[0]?.orderKey).toBe('case:ce-29');
      expect(timeline.entries.at(-1)?.orderKey).toBe('case:ce-25');
    });

    it('is not truncated when everything fits', () => {
      const timeline = buildCaseTimeline(
        { events: [caseEvent()], actions: [action()], autoMod: [] },
        20,
      );
      expect(timeline.truncated).toBe(false);
      expect(timeline.total).toBe(2);
    });
  });

  describe('privacy projection', () => {
    /*
     * `ModerationActionRow.metadata` is the second schemaless column in this
     * feature, and combining sources is exactly when one gets waved through.
     */
    it('drops moderation metadata', () => {
      const timeline = buildCaseTimeline({
        events: [],
        actions: [action({ metadata: { secret: 'SHOULD-NOT-SURVIVE' } })],
        autoMod: [],
      });

      expect(JSON.stringify(timeline)).not.toContain('SHOULD-NOT-SURVIVE');
    });

    it('carries only the approved AutoMod fields', () => {
      const timeline = buildCaseTimeline({
        events: [],
        actions: [],
        autoMod: [autoMod()],
      });
      const entry = timeline.entries[0];

      expect(entry && Object.keys(entry).sort()).toEqual([
        'action',
        'at',
        'category',
        'channelId',
        'orderKey',
        'ruleId',
        'trigger',
      ]);
    });
  });
});

// -----------------------------------------------------------------------------
// Through the real command pipeline
// -----------------------------------------------------------------------------

let h: GuardianHarness;

const MEMBER = TEST_USER_IDS.member;
const MODERATOR = TEST_USER_IDS.moderator;

const asMember = (): ReturnType<typeof testSubject> =>
  testSubject({ userId: MEMBER, roles: ['bloomMember'] });
const asModerator = (): ReturnType<typeof testSubject> =>
  testSubject({ userId: MODERATOR, roles: ['moderator'] });

beforeEach(() => {
  h = guardianHarness();
  h.guild.withMember(MEMBER);
  h.guild.withMember(MODERATOR, { roleIds: [TEST_ROLE_IDS.moderator] });
});

async function openCaseOn(subjectId: UserId | null = MEMBER): Promise<number> {
  const { case: row } = await h.repositories.cases.open({
    guildId: TEST_GUILD_ID,
    origin: 'moderator',
    openedBy: MODERATOR,
    summary: 'A case under review.',
    subjectId,
    category: null,
    status: 'OPEN',
    correlationId: newCorrelationId(),
  });
  return row.caseNumber;
}

async function view(number: number, actor = asModerator()): Promise<RecordingResponder> {
  const { responder } = await h.dispatch({
    commandName: 'guardian',
    subcommandGroup: 'case',
    subcommand: 'view',
    actor,
    options: { integers: { number } },
  });
  return responder;
}

describe('case timeline in the case view', () => {
  it('distinguishes who did what', async () => {
    const number = await openCaseOn();
    await h.repositories.audit.append({
      guildId: TEST_GUILD_ID,
      botName: 'guardian',
      event: 'security.automod_action',
      severity: 'warn',
      actorId: null,
      targetId: MEMBER,
      channelId: TEST_CHANNEL_IDS.welcome,
      source: 'discord.automod',
      details: { rule_id: '200000000000111111', trigger: 'spam', action: 'timeout' },
    });

    const text = (await view(number)).visibleText;

    expect(text).toContain('Timeline');
    expect(text).toContain('CASE');
    expect(text).toContain('AUTOMOD');
    // The AutoMod line must read as Discord's doing, never Bloom's.
    expect(text).toContain('Discord AutoMod');
  });

  it('shows a case with no history at all without a timeline section', async () => {
    const { case: row } = await h.repositories.cases.open({
      guildId: TEST_GUILD_ID,
      origin: 'moderator',
      openedBy: MODERATOR,
      summary: 'Nothing has happened yet.',
      subjectId: null,
      category: null,
      status: 'OPEN',
      correlationId: newCorrelationId(),
    });
    // A freshly opened case has exactly its own 'opened' event.
    const text = (await view(row.caseNumber)).visibleText;
    expect(text).toContain('Nothing has happened yet.');
  });

  describe('authorization', () => {
    it('shows the timeline to authorized staff', async () => {
      const number = await openCaseOn();
      expect((await view(number)).visibleText).toContain('Timeline');
    });

    it('refuses a non-staff member and reveals nothing', async () => {
      const number = await openCaseOn();
      const text = (await view(number, asMember())).visibleText;

      expect(text).toContain(REFUSAL);
      expect(text).not.toContain('Timeline');
      expect(text).not.toContain('CASE');
    });

    it('refuses staff from another guild', async () => {
      const number = await openCaseOn();
      const foreign = {
        ...asModerator(),
        guildId: unsafeSnowflake<GuildId>('999900000000000009'),
      };
      expect((await view(number, foreign)).visibleText).not.toContain('Timeline');
    });

    /*
     * The subject is read from the stored case, so there is no option a
     * caller can bend toward another member's history.
     */
    it('takes the member from the case, not from the invocation', async () => {
      await h.repositories.audit.append({
        guildId: TEST_GUILD_ID,
        botName: 'guardian',
        event: 'security.automod_action',
        severity: 'warn',
        actorId: null,
        targetId: TEST_USER_IDS.betaTester,
        source: 'discord.automod',
        details: { rule_id: 'OTHER-MEMBER-RULE', trigger: 'spam', action: 'timeout' },
      });

      const number = await openCaseOn(MEMBER);
      expect((await view(number)).visibleText).not.toContain('OTHER-MEMBER');
    });
  });

  describe('privacy', () => {
    it('never renders content, matched content or matched keyword', async () => {
      const forbidden = 'FORBIDDEN-MESSAGE-TEXT';
      await h.repositories.audit.append({
        guildId: TEST_GUILD_ID,
        botName: 'guardian',
        event: 'security.automod_action',
        severity: 'warn',
        actorId: null,
        targetId: MEMBER,
        source: 'discord.automod',
        details: {
          rule_id: '200000000000111111',
          trigger: 'keyword',
          action: 'block_message',
          content: forbidden,
          matched_content: forbidden,
          matched_keyword: forbidden,
        },
      });

      const number = await openCaseOn();
      const text = (await view(number)).visibleText;

      expect(text).toContain('AUTOMOD');
      expect(text).not.toContain(forbidden);
      expect(text).not.toContain('matched_keyword');
    });
  });

  describe('failure handling', () => {
    it('still renders the case when the AutoMod lookup fails', async () => {
      h.repositories.audit.listForTargetByEvent = () =>
        Promise.reject(bloomError('DATABASE_UNAVAILABLE', { operatorHint: 'SECRET' }));

      const number = await openCaseOn();
      const text = (await view(number)).visibleText;

      expect(text).toContain('A case under review.');
      expect(text).toContain('Timeline');
      expect(text).not.toContain('SECRET');
    });

    /*
     * A failure in one source should cost that source, not the view. The
     * case's own events are still worth showing.
     */
    it('degrades to the sources that did load', async () => {
      h.repositories.audit.listForTargetByEvent = () =>
        Promise.reject(new Error('audit down'));

      const number = await openCaseOn();
      expect((await view(number)).visibleText).toContain('CASE');
    });

    it('reports a missing case rather than an empty timeline', async () => {
      const text = (await view(4242)).visibleText;
      expect(text).not.toContain('Timeline');
      expect(text.toLowerCase()).toContain('case');
    });
  });

  describe('audit semantics', () => {
    it('writes no audit row merely for viewing the timeline', async () => {
      const number = await openCaseOn();
      const before = h.repositories.audit.events.length;

      await view(number);
      await view(number);

      expect(h.repositories.audit.events).toHaveLength(before);
    });
  });
});
