import { describe, expect, it } from 'vitest';
import {
  AutoModerationActionType,
  AutoModerationRuleTriggerType,
  type AutoModerationActionExecution,
} from 'discord.js';
import { EVENT_OWNERSHIP, assertCanHandle } from '@bloom/events';
import { BOT_INTENTS } from '../intents.js';
import { toAutoModActionPayload } from './automod.js';

/**
 * Translating AutoMod executions out of discord.js.
 *
 * Two things are under test. The ordinary one is the mapping: enums to
 * names, optional ids to nulls, unknown values to something survivable.
 *
 * The important one is what the mapping refuses to carry. The execution
 * object exposes `content`, `matchedContent` and `matchedKeyword`, and the
 * whole architectural claim of this feature is that none of them reach
 * Bloom. That claim is only worth anything if a test fails when someone
 * adds them — so the fixtures below deliberately populate all three with
 * recognisable strings, and the payload is checked for their absence.
 */

const NOW = new Date('2026-02-01T10:00:00.000Z');

/** Values that must never show up downstream. */
const SECRET_CONTENT = 'ABSOLUTELY-FORBIDDEN-MESSAGE-TEXT';
const SECRET_KEYWORD = 'ABSOLUTELY-FORBIDDEN-KEYWORD';

const execution = (
  overrides: Record<string, unknown> = {},
): AutoModerationActionExecution =>
  ({
    guild: { id: '100000000000000001' },
    action: {
      type: AutoModerationActionType.BlockMessage,
      metadata: { channelId: null, durationSeconds: null, customMessage: null },
    },
    ruleId: '200000000000000002',
    ruleTriggerType: AutoModerationRuleTriggerType.Keyword,
    userId: '300000000000000003',
    channelId: '400000000000000004',
    messageId: '500000000000000005',
    alertSystemMessageId: null,
    // Present on the real object; must not survive the translation.
    content: SECRET_CONTENT,
    matchedKeyword: SECRET_KEYWORD,
    matchedContent: SECRET_CONTENT,
    ...overrides,
  }) as unknown as AutoModerationActionExecution;

describe('toAutoModActionPayload', () => {
  it('maps a complete execution', () => {
    expect(toAutoModActionPayload(execution(), NOW)).toEqual({
      guildId: '100000000000000001',
      ruleId: '200000000000000002',
      trigger: 'keyword',
      action: 'block_message',
      rawActionType: AutoModerationActionType.BlockMessage,
      rawTriggerType: AutoModerationRuleTriggerType.Keyword,
      userId: '300000000000000003',
      channelId: '400000000000000004',
      messageId: '500000000000000005',
      alertMessageId: null,
      timeoutSeconds: null,
      detectedAt: NOW,
    });
  });

  /*
   * The property the whole feature rests on. If this fails, Bloom has become
   * a message-content collection system.
   */
  it('carries no message content, matched content or matched keyword', () => {
    const payload = toAutoModActionPayload(
      execution({ alertSystemMessageId: '600000000000000006' }),
      NOW,
    );

    const serialised = JSON.stringify(payload);
    expect(serialised).not.toContain(SECRET_CONTENT);
    expect(serialised).not.toContain(SECRET_KEYWORD);
    // Nor under any renamed key.
    expect(Object.keys(payload ?? {})).not.toContain('content');
    expect(Object.keys(payload ?? {})).not.toContain('matchedContent');
    expect(Object.keys(payload ?? {})).not.toContain('matchedKeyword');
  });

  it('keeps no reference to the raw discord.js object', () => {
    const payload = toAutoModActionPayload(execution(), NOW);

    for (const value of Object.values(payload ?? {})) {
      expect(
        typeof value === 'object' && value !== null && !(value instanceof Date),
      ).toBe(false);
    }
  });

  describe('optional fields', () => {
    it('nulls the channel when the content was not posted in one', () => {
      const payload = toAutoModActionPayload(execution({ channelId: null }), NOW);
      expect(payload?.channelId).toBeNull();
    });

    /*
     * The common case, not an edge case: a blocked message was never
     * created, so Discord sends no message id.
     */
    it('nulls the message id when AutoMod blocked the message', () => {
      const payload = toAutoModActionPayload(execution({ messageId: null }), NOW);
      expect(payload?.messageId).toBeNull();
    });

    it('carries the AutoMod alert id when the rule logged one', () => {
      const payload = toAutoModActionPayload(
        execution({
          action: { type: AutoModerationActionType.SendAlertMessage, metadata: {} },
          alertSystemMessageId: '600000000000000006',
        }),
        NOW,
      );
      expect(payload?.alertMessageId).toBe('600000000000000006');
      expect(payload?.action).toBe('send_alert_message');
    });
  });

  describe('action mapping', () => {
    it.each([
      [AutoModerationActionType.BlockMessage, 'block_message'],
      [AutoModerationActionType.SendAlertMessage, 'send_alert_message'],
      [AutoModerationActionType.Timeout, 'timeout'],
      [AutoModerationActionType.BlockMemberInteraction, 'block_member_interaction'],
    ])('maps action type %i to %s', (type, expected) => {
      const payload = toAutoModActionPayload(
        execution({ action: { type, metadata: {} } }),
        NOW,
      );
      expect(payload?.action).toBe(expected);
    });

    /*
     * Discord adds action types. A security consumer that throws on an
     * unfamiliar enum goes dark exactly when the platform ships something
     * new, so the unknown is named and the raw number preserved.
     */
    it('survives an action type newer than this code', () => {
      const payload = toAutoModActionPayload(
        execution({ action: { type: 99, metadata: {} } }),
        NOW,
      );
      expect(payload?.action).toBe('unknown');
      expect(payload?.rawActionType).toBe(99);
    });

    it('reports a timeout duration only for a timeout', () => {
      const timedOut = toAutoModActionPayload(
        execution({
          action: {
            type: AutoModerationActionType.Timeout,
            metadata: { durationSeconds: 600 },
          },
        }),
        NOW,
      );
      expect(timedOut?.timeoutSeconds).toBe(600);

      // A blocked message has no duration, whatever the metadata says.
      const blocked = toAutoModActionPayload(
        execution({
          action: {
            type: AutoModerationActionType.BlockMessage,
            metadata: { durationSeconds: 600 },
          },
        }),
        NOW,
      );
      expect(blocked?.timeoutSeconds).toBeNull();
    });
  });

  describe('trigger mapping', () => {
    it.each([
      [AutoModerationRuleTriggerType.Keyword, 'keyword'],
      [AutoModerationRuleTriggerType.Spam, 'spam'],
      [AutoModerationRuleTriggerType.KeywordPreset, 'keyword_preset'],
      [AutoModerationRuleTriggerType.MentionSpam, 'mention_spam'],
      [AutoModerationRuleTriggerType.MemberProfile, 'member_profile'],
    ])('maps trigger type %i to %s', (type, expected) => {
      const payload = toAutoModActionPayload(execution({ ruleTriggerType: type }), NOW);
      expect(payload?.trigger).toBe(expected);
    });

    it('survives a trigger type newer than this code', () => {
      const payload = toAutoModActionPayload(execution({ ruleTriggerType: 42 }), NOW);
      expect(payload?.trigger).toBe('unknown');
      expect(payload?.rawTriggerType).toBe(42);
    });
  });

  describe('malformed events', () => {
    it('drops an execution with no guild', () => {
      expect(toAutoModActionPayload(execution({ guild: null }), NOW)).toBeNull();
      expect(toAutoModActionPayload(execution({ guild: undefined }), NOW)).toBeNull();
    });

    it('drops an execution with no user', () => {
      expect(toAutoModActionPayload(execution({ userId: null }), NOW)).toBeNull();
    });

    it('does not throw when the action object is missing entirely', () => {
      const payload = toAutoModActionPayload(execution({ action: null }), NOW);
      expect(payload?.action).toBe('unknown');
      expect(payload?.rawActionType).toBe(-1);
    });
  });
});

describe('AutoMod gateway capability', () => {
  it('is owned by Guardian alone', () => {
    expect(EVENT_OWNERSHIP.autoModerationActionExecution.owner).toBe('guardian');
    expect(EVENT_OWNERSHIP.autoModerationActionExecution.observers).toEqual([]);
    expect(() => {
      assertCanHandle('guardian', 'autoModerationActionExecution');
    }).not.toThrow();
    for (const bot of ['companion', 'labs'] as const) {
      expect(() => {
        assertCanHandle(bot, 'autoModerationActionExecution');
      }).toThrow();
    }
  });

  it('requests the AutoModerationExecution intent for Guardian only', () => {
    const intentsOf = (bot: 'guardian' | 'companion' | 'labs'): readonly string[] =>
      BOT_INTENTS[bot].map((declaration) => declaration.intent);

    expect(intentsOf('guardian')).toContain('AutoModerationExecution');
    expect(intentsOf('companion')).not.toContain('AutoModerationExecution');
    expect(intentsOf('labs')).not.toContain('AutoModerationExecution');
  });

  /*
   * The intent is not privileged, which is the reason this design is
   * possible at all: Bloom gets a content-moderation signal without a
   * privileged intent review and without ambient access to messages.
   */
  it('does not add a privileged intent to get it', () => {
    const declaration = BOT_INTENTS.guardian.find(
      (entry) => entry.intent === 'AutoModerationExecution',
    );
    expect(declaration?.privileged).toBe(false);
  });

  it('still requests MESSAGE_CONTENT nowhere', () => {
    for (const bot of ['guardian', 'companion', 'labs'] as const) {
      expect(BOT_INTENTS[bot].map((entry) => entry.intent)).not.toContain(
        'MessageContent',
      );
    }
  });
});
