import {
  AutoModerationActionType,
  AutoModerationRuleTriggerType,
  type AutoModerationActionExecution,
} from 'discord.js';
import {
  unsafeSnowflake,
  type ChannelId,
  type GuildId,
  type MessageId,
  type UserId,
} from '@bloom/shared-types';
import type {
  AutoModActionKind,
  AutoModActionPayload,
  AutoModTriggerKind,
} from '@bloom/events';

/**
 * Discord AutoMod executions, translated out of discord.js.
 *
 * This adapter is the privacy boundary, and it is a boundary precisely
 * because it is the only place that ever holds the full execution object.
 * `AutoModerationActionExecution` exposes `content`, `matchedContent` and
 * `matchedKeyword`; nothing below reads them, so no amount of carelessness
 * further downstream can leak them — the domain payload simply has nowhere
 * to put them.
 *
 * Keeping this translation in one function is also what stops a discord.js
 * upgrade from rippling through Guardian. The handler and service are
 * written against plain data and can be tested with object literals.
 */

const ACTION_KINDS: Readonly<Record<number, AutoModActionKind>> = {
  [AutoModerationActionType.BlockMessage]: 'block_message',
  [AutoModerationActionType.SendAlertMessage]: 'send_alert_message',
  [AutoModerationActionType.Timeout]: 'timeout',
  [AutoModerationActionType.BlockMemberInteraction]: 'block_member_interaction',
};

const TRIGGER_KINDS: Readonly<Record<number, AutoModTriggerKind>> = {
  [AutoModerationRuleTriggerType.Keyword]: 'keyword',
  [AutoModerationRuleTriggerType.Spam]: 'spam',
  [AutoModerationRuleTriggerType.KeywordPreset]: 'keyword_preset',
  [AutoModerationRuleTriggerType.MentionSpam]: 'mention_spam',
  [AutoModerationRuleTriggerType.MemberProfile]: 'member_profile',
};

/**
 * Map Discord's numeric action type to a name.
 *
 * Keyed off the numbers that actually arrive rather than switched over the
 * enum, because the wire value is a number and an unrecognised one is an
 * expected input, not a type error.
 *
 * Unrecognised values become `'unknown'` rather than throwing. Discord adds
 * action types — `BlockMemberInteraction` is itself a recent one — and a
 * security consumer that crashes on an unfamiliar enum is a security
 * consumer that goes dark exactly when the platform ships something new.
 * The raw number travels alongside, so nothing is lost.
 */
function actionKind(type: number): AutoModActionKind {
  return ACTION_KINDS[type] ?? 'unknown';
}

/** Same forward-compatibility rule as the action type. */
function triggerKind(type: number): AutoModTriggerKind {
  return TRIGGER_KINDS[type] ?? 'unknown';
}

/**
 * What this adapter actually reads, modelled as it arrives rather than as it
 * is declared.
 *
 * discord.js types most of these as non-nullable, and for a well-formed
 * dispatch they are. But this object is built from JSON that came off a
 * websocket: the type is a claim about Discord's documentation, not a
 * guarantee about the bytes this process just received. An adapter is
 * exactly the place to stop trusting that distinction — a missing field
 * should produce a dropped event, not a `TypeError` inside a gateway
 * listener, and not an audit row with `undefined` in it.
 *
 * Declaring the looser shape here, once, is what lets the checks below be
 * honest defences instead of lint suppressions.
 */
interface AutoModExecutionWire {
  readonly guild?: { readonly id?: string | null } | null;
  readonly action?: {
    readonly type?: number | null;
    readonly metadata?: { readonly durationSeconds?: number | null } | null;
  } | null;
  readonly ruleId?: string | null;
  readonly ruleTriggerType?: number | null;
  readonly userId?: string | null;
  readonly channelId?: string | null;
  readonly messageId?: string | null;
  readonly alertSystemMessageId?: string | null;
}

/**
 * Build the domain payload.
 *
 * Returns `null` for an execution Bloom cannot place — no guild, or no user.
 * A null is dropped quietly by the caller rather than becoming a malformed
 * audit row.
 */
export function toAutoModActionPayload(
  execution: AutoModerationActionExecution,
  now: Date,
): AutoModActionPayload | null {
  const wire = execution as unknown as AutoModExecutionWire;

  const guildId = wire.guild?.id;
  if (!guildId) return null;

  const userId = wire.userId;
  if (!userId) return null;

  const action = wire.action;
  const actionType = action?.type ?? -1;
  const triggerType = wire.ruleTriggerType ?? -1;

  return {
    guildId: unsafeSnowflake<GuildId>(guildId),
    ruleId: wire.ruleId ?? 'unknown',
    trigger: triggerKind(triggerType),
    action: actionKind(actionType),
    rawActionType: actionType,
    rawTriggerType: triggerType,
    userId: unsafeSnowflake<UserId>(userId),
    channelId: wire.channelId ? unsafeSnowflake<ChannelId>(wire.channelId) : null,
    messageId: wire.messageId ? unsafeSnowflake<MessageId>(wire.messageId) : null,
    alertMessageId: wire.alertSystemMessageId
      ? unsafeSnowflake<MessageId>(wire.alertSystemMessageId)
      : null,
    /*
     * Only meaningful for a timeout. Discord populates `durationSeconds` on
     * the action metadata; for every other action type it is null, and
     * reporting a duration for a blocked message would be a fiction.
     */
    // Compared through the mapped name so the check reads against the same
    // vocabulary the rest of the payload uses, and so an unrecognised action
    // can never be mistaken for a timeout.
    timeoutSeconds:
      actionKind(actionType) === 'timeout'
        ? (action?.metadata?.durationSeconds ?? null)
        : null,
    detectedAt: now,
  };
}
