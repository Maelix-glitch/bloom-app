import type {
  BotName,
  ChannelId,
  ChannelKey,
  GuildId,
  LogSeverity,
  RoleId,
  RoleKey,
} from '@bloom/shared-types';

export type BloomEnvironment = 'development' | 'staging' | 'production';

export type CommandRegistrationScope = 'guild' | 'global';

export interface RuntimeConfig {
  readonly nodeEnv: 'development' | 'test' | 'production';
  readonly environment: BloomEnvironment;
  /** Reported by /health and stamped on every log line. */
  readonly version: string;
  /**
   * IANA zone every schedule is evaluated in.
   *
   * A single community-wide zone rather than per-member: "the check-in prompt
   * appears at 09:00" has to mean one time, or it is not a shared moment. It
   * must be a named zone, not an offset, so that 09:00 stays 09:00 across
   * daylight saving rather than drifting by an hour twice a year.
   */
  readonly timezone: string;
}

export interface LoggingConfig {
  readonly level: LogSeverity;
  readonly pretty: boolean;
}

export interface DatabaseConfig {
  /** Contains credentials. Never log this field — the redactor catches it, but do not rely on that. */
  readonly url: string;
  readonly schema: string;
  readonly maxConnections: number;
  readonly idleTimeoutSeconds: number;
  readonly connectTimeoutSeconds: number;
}

export interface DiscordConfig {
  readonly guildId: GuildId;
  readonly registrationScope: CommandRegistrationScope;
}

export interface BotCredentials {
  readonly token: string;
  readonly clientId: string;
}

/** Role key → id. `null` means "not configured", which is fatal only if a bot requires it. */
export type RoleIdMap = Readonly<Record<RoleKey, RoleId | null>>;

export type ChannelIdMap = Readonly<Record<ChannelKey, ChannelId | null>>;

export interface FeatureFlags {
  readonly scheduledMessages: boolean;
  readonly rewards: boolean;
  readonly githubIntegration: boolean;
  readonly aiIntegration: boolean;
  /**
   * Anti-raid join surveillance.
   *
   * Detection and alerting only — it takes no action against any member.
   * Defaults off, like every other flag here, so that upgrading does not
   * silently start posting to a moderation channel.
   */
  readonly raidDetection: boolean;
  /**
   * Consume Discord AutoMod execution events.
   *
   * Record and alert only — Bloom never adds an enforcement action on top of
   * the one AutoMod already applied. Defaults off so that upgrading does not
   * silently start posting into a moderation channel.
   */
  readonly autoModSignals: boolean;
}

/**
 * Anti-raid thresholds.
 *
 * Platform-wide rather than per guild. Bloom runs one server, and a
 * per-guild override would need a settings surface this task deliberately
 * does not add. The limitation is real and recorded: changing a threshold
 * needs a restart.
 *
 * **These defaults are a starting point, not validated production values.**
 * Nobody has run them against a real raid. The right numbers depend on how
 * busy the server is, and the honest instruction to an operator is to watch
 * what the alerts say for a fortnight and tighten from there. Every
 * assessment reports the observed value next to the threshold precisely so
 * that tuning is possible without reading the source.
 */
export interface RaidDetectionConfig {
  readonly windowSeconds: number;
  readonly joinThreshold: number;
  readonly youngAccountDays: number;
  /** 0..1. */
  readonly youngAccountRatio: number;
  /** Minimum gap between alerts for one guild. */
  readonly alertCooldownSeconds: number;
}

/**
 * AutoMod consumer settings.
 *
 * Only a throttle. There are no detection thresholds here because Bloom
 * performs no detection: Discord decided, Bloom is reporting.
 */
export interface AutoModSignalConfig {
  /**
   * Minimum gap between moderator alerts **for one rule**.
   *
   * Per rule rather than per guild so a single noisy rule cannot silence
   * alerts for every other rule while it is firing.
   */
  readonly alertCooldownSeconds: number;
}

export interface SecurityConfig {
  readonly raid: RaidDetectionConfig;
  readonly autoMod: AutoModSignalConfig;
}

/**
 * Everything the platform knows, validated.
 *
 * Bot credentials are `null` when that bot's token is absent. That is not an
 * error at platform level — running only Guardian locally is a legitimate thing
 * to do — it becomes an error when that specific bot tries to boot.
 */
export interface PlatformConfig {
  readonly runtime: RuntimeConfig;
  readonly logging: LoggingConfig;
  readonly database: DatabaseConfig;
  readonly discord: DiscordConfig;
  readonly roles: RoleIdMap;
  readonly channels: ChannelIdMap;
  readonly features: FeatureFlags;
  readonly security: SecurityConfig;
  readonly bots: Readonly<Record<BotName, BotCredentials | null>>;
}

/** Platform config narrowed to one bot, with that bot's credentials guaranteed present. */
export interface BotConfig {
  readonly botName: BotName;
  readonly credentials: BotCredentials;
  readonly platform: PlatformConfig;
}
