import type { ChannelId, GuildId, MessageId, RoleId, UserId } from '@bloom/shared-types';

/**
 * Gateway event payloads, as plain data.
 *
 * Handlers receive these, never discord.js objects. Same seam as the command
 * invocation DTO and for the same reasons: a handler can be tested by building
 * a literal, and a discord.js upgrade lands in one adapter rather than in every
 * feature.
 *
 * Note what is deliberately absent: message content. No Bloom bot requests the
 * Message Content intent, so no payload here carries any.
 */

export interface MemberJoinPayload {
  readonly guildId: GuildId;
  readonly userId: UserId;
  readonly username: string;
  readonly isBot: boolean;
  /** When Discord says they joined. `null` if the gateway did not supply it. */
  readonly joinedAt: Date | null;
  /** Roles at the moment of joining — non-empty only for bots and rejoins. */
  readonly roleIds: readonly RoleId[];
  /**
   * When the Discord account itself was created, decoded from the snowflake.
   *
   * Not used in Phase 1. It is here because account age is the single most
   * useful raid signal and it costs nothing to carry — the value is embedded in
   * the user id we already have.
   */
  readonly accountCreatedAt: Date;
}

/**
 * What Discord AutoMod did, as Bloom sees it.
 *
 * Deliberately narrower than the gateway payload. The dispatch data carries
 * `content`, `matched_content` and `matched_keyword`; none of the three
 * appear here, and that omission is the feature rather than an oversight.
 *
 * The first two are empty without the `MESSAGE_CONTENT` intent, which Bloom
 * does not hold. `matched_keyword` is the interesting one: Discord populates
 * it *without* that intent, because it is the rule's own configured word
 * rather than the user's text. It is still excluded. Knowing that a named
 * member tripped the rule containing a specific slur reconstructs what they
 * almost certainly typed, and storing that turns an audit trail into a record
 * of what people said. The rule id identifies the rule precisely enough for a
 * moderator to go and read it.
 *
 * This is the whole architectural trade: AutoMod sees the content, Bloom sees
 * only that AutoMod acted.
 */
export type AutoModActionKind =
  | 'block_message'
  | 'send_alert_message'
  | 'timeout'
  | 'block_member_interaction'
  | 'unknown';

export type AutoModTriggerKind =
  'keyword' | 'spam' | 'keyword_preset' | 'mention_spam' | 'member_profile' | 'unknown';

export interface AutoModActionPayload {
  readonly guildId: GuildId;
  /** The rule that fired. The pointer a moderator follows, instead of the text. */
  readonly ruleId: string;
  readonly trigger: AutoModTriggerKind;
  readonly action: AutoModActionKind;
  /**
   * The numeric action type exactly as Discord sent it.
   *
   * Kept beside the mapped name so an action type added to the API after this
   * code was written is still auditable as a number rather than silently
   * recorded as 'unknown' and lost.
   */
  readonly rawActionType: number;
  readonly rawTriggerType: number;
  /** Discord always supplies the user whose content tripped the rule. */
  readonly userId: UserId;
  /** Absent when the content was not posted in a channel — a profile, say. */
  readonly channelId: ChannelId | null;
  /**
   * The offending message.
   *
   * Absent whenever AutoMod *blocked* the message, because then no message
   * was ever created — which is the most common case by a wide margin. An id
   * here is a bonus, never something to depend on.
   */
  readonly messageId: MessageId | null;
  /** The alert AutoMod itself posted, present only for a SendAlertMessage action. */
  readonly alertMessageId: MessageId | null;
  /** Timeout length, when the action was a timeout. Discord's doing, not Bloom's. */
  readonly timeoutSeconds: number | null;
  /**
   * When Bloom received this.
   *
   * Receipt time, not event time: the dispatch data carries no timestamp.
   * A redelivered event therefore gets a *different* value, which is exactly
   * why this field must never form part of a deduplication key.
   */
  readonly detectedAt: Date;
}

export interface MemberLeavePayload {
  readonly guildId: GuildId;
  readonly userId: UserId;
  readonly username: string;
  readonly leftAt: Date;
}

/**
 * An invite was created.
 *
 * Carries `uses` even though a freshly created invite is always zero: the
 * value comes from the gateway payload rather than from an assumption, and if
 * Discord ever delivers this for an invite that already has uses, the cache
 * records what was actually reported.
 */
export interface InviteCreatePayload {
  readonly guildId: GuildId;
  readonly code: string;
  readonly uses: number;
  /** Null for widget and system invites, which have no creator to pay. */
  readonly inviterId: UserId | null;
  readonly inviterIsBot: boolean;
}

export interface InviteDeletePayload {
  readonly guildId: GuildId;
  readonly code: string;
}

export interface MemberUpdatePayload {
  readonly guildId: GuildId;
  readonly userId: UserId;
  readonly username: string;
  readonly roleIds: readonly RoleId[];
  readonly previousRoleIds: readonly RoleId[];
}

export interface RoleChangePayload {
  readonly guildId: GuildId;
  readonly roleId: RoleId;
  readonly name: string;
  readonly position: number;
  readonly managed: boolean;
  /** Absent on delete. */
  readonly previousPosition?: number;
}

/**
 * Discord's epoch, for decoding a snowflake's embedded timestamp.
 *
 * 2015-01-01T00:00:00.000Z. The first 42 bits of a snowflake are milliseconds
 * since this instant.
 */
const DISCORD_EPOCH_MS = 1_420_070_400_000n;

export function snowflakeCreatedAt(id: string): Date {
  // BigInt because a snowflake exceeds Number.MAX_SAFE_INTEGER — parsing one as
  // a float silently loses the low bits and shifts the timestamp.
  return new Date(Number((BigInt(id) >> 22n) + DISCORD_EPOCH_MS));
}
