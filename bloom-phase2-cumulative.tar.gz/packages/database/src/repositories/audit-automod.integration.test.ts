import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { unsafeSnowflake, type GuildId, type UserId } from '@bloom/shared-types';
import { createLogger, JsonLogSink } from '@bloom/logging';
import { createDatabase, type Database } from '../client.js';
import { PostgresAuditEventRepository } from './audit.js';

/**
 * The event-filtered audit lookup, against a real PostgreSQL.
 *
 * The unit tests drive the fake, which proves the case view behaves — but
 * the fake is a hand-written mirror of this SQL, and a mirror that drifts is
 * a test suite that passes while the feature is wrong. The properties below
 * are the ones the case view's security guarantees actually rest on: the
 * event filter, guild scoping, member scoping and the bound.
 *
 * The last test is the reason no migration was added. It asserts the
 * existing `audit_events_target_idx` serves this query shape, which is a
 * claim worth checking rather than asserting in a comment.
 *
 * Opt-in: `BLOOM_INTEGRATION_TESTS=1 pnpm test`.
 */

const GUILD = unsafeSnowflake<GuildId>('100000000000099001');
const OTHER_GUILD = unsafeSnowflake<GuildId>('100000000000099002');
const MEMBER = unsafeSnowflake<UserId>('100000000000099101');
const OTHER_MEMBER = unsafeSnowflake<UserId>('100000000000099102');
const AUTOMOD = 'security.automod_action';

describe('audit listForTargetByEvent (integration)', () => {
  let database: Database;
  let audit: PostgresAuditEventRepository;

  beforeAll(async () => {
    const url = process.env['DATABASE_URL'];
    if (!url) throw new Error('DATABASE_URL must be set for integration tests.');

    database = createDatabase({
      url,
      schema: process.env['DATABASE_SCHEMA'] ?? 'bloom_discord',
      maxConnections: 4,
      idleTimeoutSeconds: 5,
      connectTimeoutSeconds: 10,
      applicationName: 'bloom-integration-test',
      logger: createLogger({
        botName: 'platform',
        environment: 'development',
        version: '0.0.0-test',
        level: 'error',
        sink: new JsonLogSink(),
      }),
    });

    audit = new PostgresAuditEventRepository(database);

    const ping = await database.ping();
    if (!ping.ok) throw ping.error ?? new Error('Database unreachable.');
  });

  afterAll(async () => {
    await database.close();
  });

  beforeEach(async () => {
    await database.sql`DELETE FROM bloom_discord.audit_events WHERE guild_id IN (${GUILD}, ${OTHER_GUILD})`;
  });

  async function seed(options: {
    readonly guildId?: GuildId;
    readonly targetId?: UserId;
    readonly event?: string;
    readonly ruleId?: string;
  }): Promise<void> {
    await audit.append({
      guildId: options.guildId ?? GUILD,
      botName: 'guardian',
      event: options.event ?? AUTOMOD,
      severity: 'warn',
      actorId: null,
      targetId: options.targetId ?? MEMBER,
      source: 'discord.automod',
      details: { rule_id: options.ruleId ?? 'rule-a', action: 'block_message' },
    });
  }

  it('returns only the requested event type', async () => {
    await seed({});
    await seed({ event: 'moderation.warn_issued' });
    await seed({ event: 'security.raid_suspected' });

    const rows = await audit.listForTargetByEvent(GUILD, MEMBER, AUTOMOD, 10);
    expect(rows).toHaveLength(1);
    expect(rows[0]?.event).toBe(AUTOMOD);
  });

  /*
   * The reason this is a SQL predicate rather than an in-memory filter.
   * With the filter applied after a `LIMIT`, a member whose AutoMod hits sit
   * behind newer events of other kinds would appear to have none.
   */
  it('finds AutoMod events hidden behind newer unrelated events', async () => {
    await seed({});
    for (let index = 0; index < 60; index += 1) {
      await seed({ event: 'moderation.warn_issued' });
    }

    const rows = await audit.listForTargetByEvent(GUILD, MEMBER, AUTOMOD, 5);
    expect(rows).toHaveLength(1);
  });

  it('never crosses a guild boundary', async () => {
    await seed({ guildId: OTHER_GUILD, ruleId: 'foreign-rule' });
    await seed({ ruleId: 'local-rule' });

    const rows = await audit.listForTargetByEvent(GUILD, MEMBER, AUTOMOD, 10);
    expect(rows).toHaveLength(1);
    expect(rows[0]?.details['rule_id']).toBe('local-rule');
  });

  it('never crosses a member boundary', async () => {
    await seed({ targetId: OTHER_MEMBER, ruleId: 'other-member-rule' });
    await seed({ ruleId: 'this-member-rule' });

    const rows = await audit.listForTargetByEvent(GUILD, MEMBER, AUTOMOD, 10);
    expect(rows).toHaveLength(1);
    expect(rows[0]?.details['rule_id']).toBe('this-member-rule');
  });

  it('orders newest first and bounds the result', async () => {
    for (let index = 0; index < 12; index += 1) {
      await seed({ ruleId: `rule-${String(index)}` });
    }

    const rows = await audit.listForTargetByEvent(GUILD, MEMBER, AUTOMOD, 5);
    expect(rows).toHaveLength(5);
    expect(rows[0]?.details['rule_id']).toBe('rule-11');
    for (let index = 1; index < rows.length; index += 1) {
      const previous = rows[index - 1]?.createdAt.getTime() ?? 0;
      expect(rows[index]?.createdAt.getTime()).toBeLessThanOrEqual(previous);
    }
  });

  it('clamps an absurd limit rather than honouring it', async () => {
    for (let index = 0; index < 5; index += 1) await seed({});
    expect(await audit.listForTargetByEvent(GUILD, MEMBER, AUTOMOD, 10_000)).toHaveLength(
      5,
    );
  });

  it('returns an empty list for a member with no history', async () => {
    expect(await audit.listForTargetByEvent(GUILD, OTHER_MEMBER, AUTOMOD, 5)).toEqual([]);
  });

  /*
   * No migration was added for this feature, and this is the evidence.
   *
   * `audit_events_target_idx` is `(guild_id, target_id, created_at DESC)`.
   * The planner walks it for the member and drops non-matching events, so
   * the event predicate rides along without an index of its own.
   *
   * Seeded as a realistic guild — many members, one of them under test —
   * rather than as one member owning the whole table. That distinction is
   * not cosmetic: with a single member holding every row, a sequential scan
   * genuinely *is* the cheaper plan and Postgres rightly picks it, which
   * would make this test assert a falsehood about production.
   */
  it('is served by the existing target index at realistic scale', async () => {
    await database.sql`
      INSERT INTO bloom_discord.audit_events (guild_id, bot_name, event, severity, target_id, source, details)
      SELECT ${GUILD}, 'guardian', 'moderation.warn_issued', 'info',
             (100000000000099200::bigint + (g % 200))::text, 'seed', '{}'::jsonb
      FROM generate_series(1, 20000) g
    `;
    await database.sql`
      INSERT INTO bloom_discord.audit_events (guild_id, bot_name, event, severity, target_id, source, details)
      SELECT ${GUILD}, 'guardian', 'moderation.warn_issued', 'info', ${MEMBER}, 'seed', '{}'::jsonb
      FROM generate_series(1, 250)
    `;
    await seed({});
    await database.sql`ANALYZE bloom_discord.audit_events`;

    const plan = await database.sql<{ 'QUERY PLAN': string }[]>`
      EXPLAIN SELECT * FROM bloom_discord.audit_events
      WHERE guild_id = ${GUILD} AND target_id = ${MEMBER} AND event = ${AUTOMOD}
      ORDER BY created_at DESC, id DESC
      LIMIT 5
    `;
    const text = plan.map((row) => row['QUERY PLAN']).join('\n');

    expect(text).toContain('audit_events_target_idx');
    expect(text).not.toContain('Seq Scan');
  });
});
