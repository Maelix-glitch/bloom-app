import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { unsafeSnowflake, type GuildId, type UserId } from '@bloom/shared-types';
import { createLogger, JsonLogSink } from '@bloom/logging';
import { createDatabase, type Database } from '../client.js';
import { PostgresIdentityRepository } from './identity.js';

/**
 * The join-surveillance reads, against a real PostgreSQL.
 *
 * The anti-raid unit tests drive the fake repository, which proves the
 * detector's arithmetic and the service's wiring but says nothing about the
 * SQL those tests stand in for. Window boundaries, guild scoping and the
 * ordering the sample depends on are all database behaviour, and a fake that
 * disagrees with the query is a test suite that passes while the feature is
 * blind. These assertions exist to keep the two honest with each other.
 *
 * Opt-in: `BLOOM_INTEGRATION_TESTS=1 pnpm test`.
 */

const GUILD = unsafeSnowflake<GuildId>('100000000000098001');
const OTHER_GUILD = unsafeSnowflake<GuildId>('100000000000098002');
const NOW = new Date('2026-01-01T12:00:00.000Z');

function userId(suffix: number): UserId {
  return unsafeSnowflake<UserId>(`10000000000009${String(suffix).padStart(4, '0')}`);
}

describe('join surveillance reads (integration)', () => {
  let database: Database;
  let identity: PostgresIdentityRepository;

  beforeAll(async () => {
    const url = process.env['DATABASE_URL'];
    if (!url) throw new Error('DATABASE_URL must be set for integration tests.');

    database = createDatabase({
      url,
      schema: process.env['DATABASE_SCHEMA'] ?? 'bloom_discord',
      maxConnections: 4,
      idleTimeoutSeconds: 5,
      connectTimeoutSeconds: 10,
      applicationName: 'bloom-integration-test',
      logger: createLogger({
        botName: 'platform',
        environment: 'development',
        version: '0.0.0-test',
        level: 'error',
        sink: new JsonLogSink(),
      }),
    });

    identity = new PostgresIdentityRepository(database);

    const ping = await database.ping();
    if (!ping.ok) throw ping.error ?? new Error('Database unreachable.');

    await identity.upsertGuild({ guildId: GUILD, name: 'Raid target (integration)' });
    await identity.upsertGuild({ guildId: OTHER_GUILD, name: 'Bystander (integration)' });
  });

  afterAll(async () => {
    await database.close();
  });

  beforeEach(async () => {
    await database.sql`DELETE FROM bloom_discord.guild_members WHERE guild_id IN (${GUILD}, ${OTHER_GUILD})`;
  });

  /** Seed a member with an exact join instant. */
  async function join(
    guildId: GuildId,
    suffix: number,
    joinedAt: Date | null,
  ): Promise<UserId> {
    const id = userId(suffix);
    await identity.ensureMember({
      guildId,
      userId: id,
      username: `joiner-${String(suffix)}`,
      joinedAt,
    });
    return id;
  }

  it('counts only joins inside the window', async () => {
    const since = new Date(NOW.getTime() - 60_000);
    await join(GUILD, 1, new Date(NOW.getTime() - 10_000));
    await join(GUILD, 2, new Date(NOW.getTime() - 59_000));
    await join(GUILD, 3, new Date(NOW.getTime() - 120_000));

    expect(await identity.countJoinsSince(GUILD, since)).toBe(2);
  });

  /*
   * The window is inclusive at its lower edge. `>=` versus `>` here is a
   * silent off-by-one that only ever matters during the event being detected.
   */
  it('includes a join exactly on the window boundary', async () => {
    const since = new Date(NOW.getTime() - 60_000);
    await join(GUILD, 4, since);

    expect(await identity.countJoinsSince(GUILD, since)).toBe(1);
  });

  it('never counts another guild towards this one', async () => {
    const since = new Date(NOW.getTime() - 60_000);
    await join(OTHER_GUILD, 5, new Date(NOW.getTime() - 5_000));
    await join(OTHER_GUILD, 6, new Date(NOW.getTime() - 5_000));
    await join(GUILD, 7, new Date(NOW.getTime() - 5_000));

    expect(await identity.countJoinsSince(GUILD, since)).toBe(1);
    expect(await identity.recentJoinerIds(GUILD, since, 50)).toStrictEqual([userId(7)]);
  });

  /*
   * A member with no recorded join instant cannot be placed in the window.
   * Backfilled rows and pre-install members land here, and counting them
   * would make the detector fire on history rather than on an event.
   */
  it('ignores members with no join timestamp', async () => {
    const since = new Date(NOW.getTime() - 60_000);
    await join(GUILD, 8, null);

    expect(await identity.countJoinsSince(GUILD, since)).toBe(0);
    expect(await identity.recentJoinerIds(GUILD, since, 50)).toStrictEqual([]);
  });

  it('returns the sample newest first, with a stable tie-break', async () => {
    const since = new Date(NOW.getTime() - 60_000);
    const shared = new Date(NOW.getTime() - 30_000);
    await join(GUILD, 11, new Date(NOW.getTime() - 50_000));
    await join(GUILD, 13, shared);
    await join(GUILD, 12, shared);
    await join(GUILD, 14, new Date(NOW.getTime() - 5_000));

    // Newest first; the two sharing an instant ordered by descending id.
    expect(await identity.recentJoinerIds(GUILD, since, 50)).toStrictEqual([
      userId(14),
      userId(13),
      userId(12),
      userId(11),
    ]);
  });

  /*
   * Determinism under a tie is what makes the age ratio reproducible. Without
   * the id tie-break, two runs over the same data could sample different
   * members and reach different verdicts.
   */
  it('samples deterministically across repeated reads', async () => {
    const since = new Date(NOW.getTime() - 60_000);
    const shared = new Date(NOW.getTime() - 20_000);
    for (const suffix of [21, 22, 23, 24, 25]) {
      await join(GUILD, suffix, shared);
    }

    const first = await identity.recentJoinerIds(GUILD, since, 3);
    const second = await identity.recentJoinerIds(GUILD, since, 3);
    expect(second).toStrictEqual(first);
    expect(first).toHaveLength(3);
  });

  it('bounds the sample, however much is asked for', async () => {
    const since = new Date(NOW.getTime() - 60_000);
    for (let index = 0; index < 12; index += 1) {
      await join(GUILD, 100 + index, new Date(NOW.getTime() - 10_000));
    }

    expect(await identity.recentJoinerIds(GUILD, since, 5)).toHaveLength(5);
    // Past the repository's own ceiling: clamped, not honoured.
    expect(await identity.recentJoinerIds(GUILD, since, 10_000)).toHaveLength(12);
  });

  /*
   * The index from migration 0013 is the difference between an O(log n) probe
   * and a sequential scan of every member — during a raid, on the hot path of
   * every join.
   *
   * Seeded to a realistic size first, and analysed, because a plan assertion
   * against a near-empty table proves nothing: a sequential scan over three
   * rows is the *correct* choice and the planner will rightly make it. The
   * question worth asking is whether the index holds up at the size of a
   * server actually worth raiding.
   */
  it('answers the velocity count from the join index at scale', async () => {
    const since = new Date(NOW.getTime() - 60_000);

    // 5000 historical members, all far outside the window, plus a handful
    // inside it — the shape the detector meets in production.
    await database.sql`
      INSERT INTO bloom_discord.users (user_id, username)
      SELECT (900000000000000000 + generate_series)::text, 'bulk'
      FROM generate_series(1, 5000)
      ON CONFLICT DO NOTHING
    `;
    await database.sql`
      INSERT INTO bloom_discord.guild_members (guild_id, user_id, joined_at)
      SELECT ${GUILD}, (900000000000000000 + generate_series)::text,
             ${NOW}::timestamptz - interval '30 days'
      FROM generate_series(1, 5000)
      ON CONFLICT DO NOTHING
    `;
    await join(GUILD, 200, new Date(NOW.getTime() - 10_000));
    await database.sql`ANALYZE bloom_discord.guild_members`;

    const plan = await database.sql<{ 'QUERY PLAN': string }[]>`
      EXPLAIN SELECT count(*)
      FROM bloom_discord.guild_members
      WHERE guild_id = ${GUILD} AND joined_at IS NOT NULL AND joined_at >= ${since}
    `;
    const text = plan.map((row) => row['QUERY PLAN']).join('\n');

    expect(text).toContain('guild_members_joined_recent_idx');
    expect(text).not.toContain('Seq Scan');

    await database.sql`
      DELETE FROM bloom_discord.users WHERE user_id LIKE '9000000000000%'
    `;
  });
});
