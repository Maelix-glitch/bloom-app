import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { unsafeSnowflake, type GuildId, type UserId } from '@bloom/shared-types';
import { createLogger, JsonLogSink } from '@bloom/logging';
import { newCorrelationId } from '@bloom/utils';
import { createDatabase, type Database } from '../client.js';
import { PostgresCaseRepository } from './cases.js';
import { PostgresIdentityRepository } from './identity.js';
import { PostgresModerationRepository } from './moderation.js';

/**
 * Case evidence, against a real PostgreSQL.
 *
 * The unit tests drive fakes, and the fakes are hand-written mirrors of the
 * constraints added in migrations 0014 and 0015. A mirror that drifts is a
 * suite that passes while the schema permits something it should not — and
 * here the schema *is* the security control: the completeness CHECK is what
 * makes a forged evidence row inexpressible, and the partial unique index is
 * the authoritative duplicate guard rather than a backstop for application
 * logic.
 *
 * Opt-in: `BLOOM_INTEGRATION_TESTS=1 pnpm test`.
 */

const GUILD = unsafeSnowflake<GuildId>('100000000000098501');
const MODERATOR = unsafeSnowflake<UserId>('100000000000098601');
const SUBJECT = unsafeSnowflake<UserId>('100000000000098602');

describe('case evidence persistence (integration)', () => {
  let database: Database;
  let cases: PostgresCaseRepository;
  let identity: PostgresIdentityRepository;
  let moderation: PostgresModerationRepository;

  beforeAll(async () => {
    const url = process.env['DATABASE_URL'];
    if (!url) throw new Error('DATABASE_URL must be set for integration tests.');

    database = createDatabase({
      url,
      schema: process.env['DATABASE_SCHEMA'] ?? 'bloom_discord',
      maxConnections: 4,
      idleTimeoutSeconds: 5,
      connectTimeoutSeconds: 10,
      applicationName: 'bloom-integration-test',
      logger: createLogger({
        botName: 'platform',
        environment: 'development',
        version: '0.0.0-test',
        level: 'error',
        sink: new JsonLogSink(),
      }),
    });

    cases = new PostgresCaseRepository(database);
    identity = new PostgresIdentityRepository(database);
    moderation = new PostgresModerationRepository(database);

    const ping = await database.ping();
    if (!ping.ok) throw ping.error ?? new Error('Database unreachable.');

    await identity.upsertGuild({ guildId: GUILD, name: 'Evidence (integration)' });
  });

  afterAll(async () => {
    await database.close();
  });

  beforeEach(async () => {
    await database.sql`DELETE FROM bloom_discord.moderation_actions WHERE guild_id = ${GUILD}`;
    await database.sql`DELETE FROM bloom_discord.moderation_cases WHERE guild_id = ${GUILD}`;
  });

  async function openCase(): Promise<string> {
    const { case: row } = await cases.open({
      guildId: GUILD,
      origin: 'moderator',
      openedBy: MODERATOR,
      summary: 'Integration case.',
      subjectId: SUBJECT,
      category: null,
      status: 'OPEN',
      correlationId: newCorrelationId(),
    });
    return row.id;
  }

  it('migration 0014 added the enum value', async () => {
    const rows = await database.sql<{ v: string }[]>`
      SELECT unnest(enum_range(NULL::bloom_discord.case_event_type))::text AS v
    `;
    expect(rows.map((row) => row.v)).toContain('evidence_attached');
  });

  it('stores an attachment as a first-class case event', async () => {
    const caseId = await openCase();
    const outcome = await cases.attachEvidence({
      caseId,
      evidenceType: 'automod_event',
      evidenceSourceId: 'audit-1',
      actorId: MODERATOR,
      correlationId: newCorrelationId(),
    });

    expect(outcome.kind).toBe('attached');
    const events = await cases.listEvents(caseId);
    const evidence = events.filter((event) => event.eventType === 'evidence_attached');
    expect(evidence).toHaveLength(1);
    expect(evidence[0]?.evidenceType).toBe('automod_event');
    expect(evidence[0]?.evidenceSourceId).toBe('audit-1');
  });

  describe('the completeness constraint', () => {
    /*
     * This is the control that makes a forged attachment inexpressible.
     * `/guardian case note` writes arbitrary text under the same capability
     * as attaching evidence; if a note could carry evidence columns, every
     * server-side validation would be bypassable by typing.
     */
    it('refuses evidence columns on a non-evidence row', async () => {
      const caseId = await openCase();
      await expect(
        database.sql`
          INSERT INTO bloom_discord.case_events
            (case_id, event_type, actor_id, evidence_type, evidence_source_id)
          VALUES (${caseId}, 'note', ${MODERATOR}, 'automod_event', 'forged')
        `,
      ).rejects.toThrow(/case_events_evidence_complete/);
    });

    it('refuses an evidence row missing either field', async () => {
      const caseId = await openCase();
      await expect(
        database.sql`
          INSERT INTO bloom_discord.case_events (case_id, event_type, evidence_type)
          VALUES (${caseId}, 'evidence_attached', 'automod_event')
        `,
      ).rejects.toThrow(/case_events_evidence_complete/);

      await expect(
        database.sql`
          INSERT INTO bloom_discord.case_events (case_id, event_type, evidence_source_id)
          VALUES (${caseId}, 'evidence_attached', 'audit-1')
        `,
      ).rejects.toThrow(/case_events_evidence_complete/);
    });

    it('refuses an unrecognised evidence type', async () => {
      const caseId = await openCase();
      await expect(
        database.sql`
          INSERT INTO bloom_discord.case_events
            (case_id, event_type, evidence_type, evidence_source_id)
          VALUES (${caseId}, 'evidence_attached', 'something_else', 'x')
        `,
      ).rejects.toThrow(/evidence_type_check/);
    });

    it('bounds the source identifier', async () => {
      const caseId = await openCase();
      await expect(
        database.sql`
          INSERT INTO bloom_discord.case_events
            (case_id, event_type, evidence_type, evidence_source_id)
          VALUES (${caseId}, 'evidence_attached', 'automod_event', ${'x'.repeat(65)})
        `,
      ).rejects.toThrow(/evidence_source_id_check/);
    });
  });

  describe('the partial unique index', () => {
    it('reports a duplicate instead of writing twice', async () => {
      const caseId = await openCase();
      const input = {
        caseId,
        evidenceType: 'automod_event' as const,
        evidenceSourceId: 'audit-1',
        actorId: MODERATOR,
        correlationId: newCorrelationId(),
      };

      expect((await cases.attachEvidence(input)).kind).toBe('attached');
      expect((await cases.attachEvidence(input)).kind).toBe('duplicate');

      const events = await cases.listEvents(caseId);
      expect(events.filter((e) => e.eventType === 'evidence_attached')).toHaveLength(1);
    });

    /*
     * The guard has to hold under genuine concurrency, because that is the
     * realistic shape: two moderators reacting to the same incident. A
     * read-then-write check would pass the sequential test above and fail
     * this one.
     */
    it('holds under concurrent identical attempts', async () => {
      const caseId = await openCase();
      const input = {
        caseId,
        evidenceType: 'automod_event' as const,
        evidenceSourceId: 'race',
        actorId: MODERATOR,
        correlationId: newCorrelationId(),
      };

      const outcomes = await Promise.all([
        cases.attachEvidence(input),
        cases.attachEvidence(input),
        cases.attachEvidence(input),
        cases.attachEvidence(input),
      ]);

      expect(outcomes.filter((o) => o.kind === 'attached')).toHaveLength(1);
      expect(outcomes.filter((o) => o.kind === 'duplicate')).toHaveLength(3);

      const events = await cases.listEvents(caseId);
      expect(events.filter((e) => e.eventType === 'evidence_attached')).toHaveLength(1);
    });

    it('scopes uniqueness per case, not globally', async () => {
      const first = await openCase();
      const second = await openCase();
      const shared = {
        evidenceType: 'automod_event' as const,
        evidenceSourceId: 'audit-shared',
        actorId: MODERATOR,
        correlationId: newCorrelationId(),
      };

      expect((await cases.attachEvidence({ ...shared, caseId: first })).kind).toBe(
        'attached',
      );
      expect((await cases.attachEvidence({ ...shared, caseId: second })).kind).toBe(
        'attached',
      );
    });

    it('treats the two evidence types as distinct references', async () => {
      const caseId = await openCase();
      const base = {
        caseId,
        evidenceSourceId: '1',
        actorId: MODERATOR,
        correlationId: newCorrelationId(),
      };

      expect(
        (await cases.attachEvidence({ ...base, evidenceType: 'automod_event' })).kind,
      ).toBe('attached');
      expect(
        (await cases.attachEvidence({ ...base, evidenceType: 'moderation_action' })).kind,
      ).toBe('attached');
    });

    /*
     * Partial: it indexes evidence rows only. Ordinary case events carry
     * NULLs in both columns and must not collide with each other.
     */
    it('does not constrain ordinary case events', async () => {
      const caseId = await openCase();
      for (let index = 0; index < 3; index += 1) {
        await database.sql`
          INSERT INTO bloom_discord.case_events (case_id, event_type, actor_id, body)
          VALUES (${caseId}, 'note', ${MODERATOR}, 'a note')
        `;
      }
      const events = await cases.listEvents(caseId);
      expect(events.filter((e) => e.eventType === 'note')).toHaveLength(3);
    });
  });

  describe('moderation action linking', () => {
    async function seedAction(): Promise<string> {
      const row = await moderation.record({
        guildId: GUILD,
        action: 'warn',
        subjectId: SUBJECT,
        actorId: MODERATOR,
        reason: 'Integration reason.',
        correlationId: newCorrelationId(),
      });
      return row.id;
    }

    it('resolves an action by id within the guild', async () => {
      const id = await seedAction();
      expect((await moderation.findById(GUILD, id))?.id).toBe(id);
    });

    it('does not resolve an action from another guild', async () => {
      const id = await seedAction();
      const foreign = unsafeSnowflake<GuildId>('999900000000000009');
      expect(await moderation.findById(foreign, id)).toBeNull();
    });

    /*
     * The id column is bigint and the caller supplies arbitrary text, so a
     * malformed id has to be a clean miss rather than SQLSTATE 22P02.
     */
    it('treats a non-numeric id as not found rather than erroring', async () => {
      await expect(moderation.findById(GUILD, 'not-a-number')).resolves.toBeNull();
      await expect(moderation.findById(GUILD, '1; DROP TABLE x')).resolves.toBeNull();
    });

    it('links an unfiled action to a case, idempotently', async () => {
      const caseId = await openCase();
      const id = await seedAction();

      expect(await moderation.attachToCase({ guildId: GUILD, id, caseId })).toBe(true);
      // Re-running is a no-op that still reports success.
      expect(await moderation.attachToCase({ guildId: GUILD, id, caseId })).toBe(true);
      expect((await moderation.findById(GUILD, id))?.caseId).toBe(caseId);
    });

    it('refuses to steal an action already filed against another case', async () => {
      const first = await openCase();
      const second = await openCase();
      const id = await seedAction();

      expect(await moderation.attachToCase({ guildId: GUILD, id, caseId: first })).toBe(
        true,
      );
      expect(await moderation.attachToCase({ guildId: GUILD, id, caseId: second })).toBe(
        false,
      );
      expect((await moderation.findById(GUILD, id))?.caseId).toBe(first);
    });

    it('refuses a cross-guild link', async () => {
      const caseId = await openCase();
      const id = await seedAction();
      const foreign = unsafeSnowflake<GuildId>('999900000000000009');

      expect(await moderation.attachToCase({ guildId: foreign, id, caseId })).toBe(false);
      expect((await moderation.findById(GUILD, id))?.caseId).toBeNull();
    });
  });
});
