import type { GuildId, OnboardingState, RoleId, UserId } from '@bloom/shared-types';
import { BaseRepository } from '../repository.js';
import { toDatabaseError, type Database, type TransactionSql } from '../client.js';

/** Hard ceiling on a role-membership read. There is no pagination. */
const MAX_ROLE_MEMBERS = 1000;

/**
 * Hard ceiling on the join sample the raid detector inspects.
 *
 * The velocity count is an aggregate and sees every join. This is only the
 * sample whose account ages get decoded, and the detector reports the ratio
 * as "of the most recent N". A raid large enough to exceed this has already
 * tripped the velocity signal many times over.
 */
const MAX_JOIN_SAMPLE = 200;

export interface GuildRecord {
  readonly guildId: GuildId;
  readonly name: string;
  readonly timezone: string;
  readonly automationEnabled: boolean;
}

export interface MemberRecord {
  readonly guildId: GuildId;
  readonly userId: UserId;
  readonly onboardingState: OnboardingState;
  readonly joinedAt: Date | null;
  readonly leftAt: Date | null;
  readonly verifiedAt: Date | null;
  readonly onboardingCompletedAt: Date | null;
}

export interface IdentityRepository {
  upsertGuild(
    input: { guildId: GuildId; name: string; timezone?: string },
    tx?: TransactionSql,
  ): Promise<void>;
  findGuild(guildId: GuildId): Promise<GuildRecord | null>;

  upsertUser(
    input: { userId: UserId; username: string; isBot?: boolean },
    tx?: TransactionSql,
  ): Promise<void>;

  /** Create the membership row if absent. Never downgrades existing state. */
  ensureMember(
    input: { guildId: GuildId; userId: UserId; username: string; joinedAt?: Date | null },
    tx?: TransactionSql,
  ): Promise<MemberRecord>;

  findMember(guildId: GuildId, userId: UserId): Promise<MemberRecord | null>;

  markLeft(
    guildId: GuildId,
    userId: UserId,
    at: Date,
    tx?: TransactionSql,
  ): Promise<void>;

  /** Replace the observed role cache for one member. */
  replaceObservedRoles(
    guildId: GuildId,
    userId: UserId,
    roleIds: readonly RoleId[],
    tx?: TransactionSql,
  ): Promise<void>;

  /** Members observed to hold a given role. Cohort queries only — never authorization. */
  /**
   * How many members joined this guild since `since`.
   *
   * An aggregate, so it is bounded by construction however large the burst
   * is — the one question that must stay cheap during the event it detects.
   */
  countJoinsSince(guildId: GuildId, since: Date): Promise<number>;

  /**
   * The most recent joiners since `since`, newest first, bounded.
   *
   * Ids only. Account age is decoded from the snowflake by the caller rather
   * than stored, so detecting a raid of fresh accounts needs no column
   * recording how old anyone's account is.
   */
  recentJoinerIds(
    guildId: GuildId,
    since: Date,
    limit: number,
  ): Promise<readonly UserId[]>;

  findMembersWithRole(guildId: GuildId, roleId: RoleId): Promise<readonly UserId[]>;
}

/**
 * Guilds, users, members and the observed role cache.
 *
 * Note what this repository does NOT expose: no method changes
 * `onboarding_state`. That transition is Guardian's alone and arrives in Phase 1
 * as a dedicated, audited operation with its own authorization. Putting a
 * general-purpose `setOnboardingState` here would make it reachable from
 * Companion, which is exactly the boundary the brief draws.
 */
export class PostgresIdentityRepository
  extends BaseRepository
  implements IdentityRepository
{
  public constructor(database: Database) {
    super(database);
  }

  public async upsertGuild(
    input: { guildId: GuildId; name: string; timezone?: string },
    tx?: TransactionSql,
  ): Promise<void> {
    const sql = this.conn(tx);
    try {
      await sql`
        INSERT INTO ${sql(this.schema)}.guilds (guild_id, name, timezone)
        VALUES (${input.guildId}, ${input.name}, ${input.timezone ?? 'UTC'})
        ON CONFLICT (guild_id) DO UPDATE SET name = EXCLUDED.name
      `;
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  public async findGuild(guildId: GuildId): Promise<GuildRecord | null> {
    const sql = this.conn();
    try {
      const rows = await sql<
        {
          guild_id: string;
          name: string;
          timezone: string;
          automation_enabled: boolean;
        }[]
      >`
        SELECT guild_id, name, timezone, automation_enabled
        FROM ${sql(this.schema)}.guilds WHERE guild_id = ${guildId}
      `;
      const row = rows[0];
      if (!row) return null;
      return {
        guildId: row.guild_id as GuildId,
        name: row.name,
        timezone: row.timezone,
        automationEnabled: row.automation_enabled,
      };
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  public async upsertUser(
    input: { userId: UserId; username: string; isBot?: boolean },
    tx?: TransactionSql,
  ): Promise<void> {
    const sql = this.conn(tx);
    try {
      await sql`
        INSERT INTO ${sql(this.schema)}.users (user_id, username, is_bot)
        VALUES (${input.userId}, ${input.username}, ${input.isBot ?? false})
        ON CONFLICT (user_id) DO UPDATE SET username = EXCLUDED.username
      `;
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  public async ensureMember(
    input: { guildId: GuildId; userId: UserId; username: string; joinedAt?: Date | null },
    tx?: TransactionSql,
  ): Promise<MemberRecord> {
    const sql = this.conn(tx);
    try {
      await this.upsertUser({ userId: input.userId, username: input.username }, tx);

      /*
       * A rejoin clears `left_at` but deliberately preserves `onboarding_state`.
       * Someone who completed onboarding, left and came back should not be
       * pushed through verification again — and someone whose access was revoked
       * should not be able to launder that by leaving and rejoining.
       */
      const rows = await sql<RawMemberRow[]>`
        INSERT INTO ${sql(this.schema)}.guild_members (guild_id, user_id, joined_at)
        VALUES (${input.guildId}, ${input.userId}, ${input.joinedAt ?? null})
        ON CONFLICT (guild_id, user_id) DO UPDATE
          SET left_at = NULL,
              joined_at = COALESCE(${sql(this.schema)}.guild_members.joined_at, EXCLUDED.joined_at)
        RETURNING *
      `;
      return mapMember(rows[0]!);
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  public async findMember(
    guildId: GuildId,
    userId: UserId,
  ): Promise<MemberRecord | null> {
    const sql = this.conn();
    try {
      const rows = await sql<RawMemberRow[]>`
        SELECT * FROM ${sql(this.schema)}.guild_members
        WHERE guild_id = ${guildId} AND user_id = ${userId}
      `;
      const row = rows[0];
      return row ? mapMember(row) : null;
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  public async markLeft(
    guildId: GuildId,
    userId: UserId,
    at: Date,
    tx?: TransactionSql,
  ): Promise<void> {
    const sql = this.conn(tx);
    try {
      await sql`
        UPDATE ${sql(this.schema)}.guild_members
        SET left_at = ${at}
        WHERE guild_id = ${guildId} AND user_id = ${userId}
      `;
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  public async replaceObservedRoles(
    guildId: GuildId,
    userId: UserId,
    roleIds: readonly RoleId[],
    tx?: TransactionSql,
  ): Promise<void> {
    const apply = async (conn: TransactionSql): Promise<void> => {
      await conn`
        DELETE FROM ${conn(this.schema)}.member_roles
        WHERE guild_id = ${guildId} AND user_id = ${userId}
      `;
      if (roleIds.length === 0) return;

      const values = roleIds.map((roleId) => ({
        guild_id: guildId,
        user_id: userId,
        role_id: roleId,
      }));
      await conn`
        INSERT INTO ${conn(this.schema)}.member_roles ${conn(values, 'guild_id', 'user_id', 'role_id')}
        ON CONFLICT DO NOTHING
      `;
    };

    try {
      // Delete-then-insert must be atomic, or a concurrent read sees no roles.
      if (tx) await apply(tx);
      else await this.db.transaction(apply);
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  public async countJoinsSince(guildId: GuildId, since: Date): Promise<number> {
    const sql = this.conn();
    try {
      const rows = await sql<{ count: string }[]>`
        SELECT count(*)::text AS count
        FROM ${sql(this.schema)}.guild_members
        WHERE guild_id = ${guildId}
          AND joined_at IS NOT NULL
          AND joined_at >= ${since}
          -- left_at is deliberately not filtered: a member who joined and
          -- left inside the window still joined, and a raid whose accounts
          -- leave again is still a raid.
      `;
      return Number(rows[0]?.count ?? '0');
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  public async recentJoinerIds(
    guildId: GuildId,
    since: Date,
    limit: number,
  ): Promise<readonly UserId[]> {
    const bounded = Math.min(Math.max(Math.trunc(limit), 1), MAX_JOIN_SAMPLE);
    const sql = this.conn();
    try {
      const rows = await sql<{ user_id: string }[]>`
        SELECT user_id
        FROM ${sql(this.schema)}.guild_members
        WHERE guild_id = ${guildId}
          AND joined_at IS NOT NULL
          AND joined_at >= ${since}
        -- Newest first, then user_id to make the order total. Two members can
        -- share a join timestamp to the millisecond during a scripted raid —
        -- which is precisely when this runs — and a sample that varied
        -- between two reads of identical data would make the decision
        -- non-deterministic.
        ORDER BY joined_at DESC, user_id DESC
        LIMIT ${bounded}
      `;
      return rows.map((row) => row.user_id as UserId);
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  /**
   * Members currently holding a role.
   *
   * Bounded and ordered, which it was not. ❋ Bloom Member is held by every
   * member of the server, so an unbounded version of this pulls the entire
   * membership into process memory the first time anyone calls it.
   *
   * Nothing calls it today. That is exactly why it is worth bounding now:
   * the first caller will be written by someone who assumes the repository
   * would not hand back something unbounded, and they will be right because
   * of this line rather than by luck. A caller that needs more than the cap
   * needs pagination, which this platform does not have — see the known
   * limitations in the production checklist.
   */
  public async findMembersWithRole(
    guildId: GuildId,
    roleId: RoleId,
  ): Promise<readonly UserId[]> {
    const sql = this.conn();
    try {
      const rows = await sql<{ user_id: string }[]>`
        SELECT mr.user_id
        FROM ${sql(this.schema)}.member_roles mr
        JOIN ${sql(this.schema)}.guild_members gm
          ON gm.guild_id = mr.guild_id AND gm.user_id = mr.user_id
        WHERE mr.guild_id = ${guildId} AND mr.role_id = ${roleId} AND gm.left_at IS NULL
        ORDER BY mr.user_id ASC
        LIMIT ${MAX_ROLE_MEMBERS}
      `;
      return rows.map((row) => row.user_id as UserId);
    } catch (error) {
      throw toDatabaseError(error);
    }
  }
}

interface RawMemberRow {
  guild_id: string;
  user_id: string;
  onboarding_state: OnboardingState;
  joined_at: Date | null;
  left_at: Date | null;
  verified_at: Date | null;
  onboarding_completed_at: Date | null;
}

function mapMember(row: RawMemberRow): MemberRecord {
  return {
    guildId: row.guild_id as GuildId,
    userId: row.user_id as UserId,
    onboardingState: row.onboarding_state,
    joinedAt: row.joined_at,
    leftAt: row.left_at,
    verifiedAt: row.verified_at,
    onboardingCompletedAt: row.onboarding_completed_at,
  };
}
