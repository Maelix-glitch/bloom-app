import type {
  BotName,
  ChannelId,
  CorrelationId,
  GuildId,
  JsonObject,
  LogSeverity,
  UserId,
} from '@bloom/shared-types';
import { redactObject } from '@bloom/utils';
import { BaseRepository } from '../repository.js';
import { toDatabaseError, type Database, type TransactionSql } from '../client.js';

export interface AuditEventInput {
  readonly guildId: GuildId;
  readonly botName: BotName;
  /** Dotted, lowercase, e.g. `onboarding.completed`. Constrained by the schema. */
  readonly event: string;
  readonly severity?: LogSeverity;
  readonly actorId?: UserId | null;
  readonly targetId?: UserId | null;
  readonly channelId?: ChannelId | null;
  /** The command or gateway event that caused this. */
  readonly source?: string | null;
  readonly correlationId?: CorrelationId | null;
  readonly details?: JsonObject;
}

export interface AuditEventRow {
  readonly id: string;
  readonly guildId: GuildId;
  readonly botName: BotName;
  readonly event: string;
  readonly severity: LogSeverity;
  readonly actorId: UserId | null;
  readonly targetId: UserId | null;
  readonly channelId: ChannelId | null;
  readonly source: string | null;
  readonly correlationId: CorrelationId | null;
  readonly details: JsonObject;
  readonly createdAt: Date;
}

export interface AuditEventRepository {
  append(input: AuditEventInput, tx?: TransactionSql): Promise<string>;
  listForTarget(
    guildId: GuildId,
    targetId: UserId,
    limit?: number,
  ): Promise<readonly AuditEventRow[]>;
  listForTargetByEvent(
    guildId: GuildId,
    targetId: UserId,
    event: string,
    limit?: number,
  ): Promise<readonly AuditEventRow[]>;
  findById(guildId: GuildId, id: string): Promise<AuditEventRow | null>;
  listRecent(guildId: GuildId, limit?: number): Promise<readonly AuditEventRow[]>;
}

/**
 * Append-only audit trail.
 *
 * There is no update and no delete, and there will not be one. "Do not delete
 * evidence automatically" is a requirement, and the cheapest way to honour it is
 * to not write the code that could.
 *
 * `details` is redacted on the way in. The audit table is read by staff tooling
 * and exported during reviews, so a token that leaked into a details object
 * would be a token in a document someone emails.
 */
export class PostgresAuditEventRepository
  extends BaseRepository
  implements AuditEventRepository
{
  public constructor(database: Database) {
    super(database);
  }

  public async append(input: AuditEventInput, tx?: TransactionSql): Promise<string> {
    const sql = this.conn(tx);
    try {
      const [row] = await sql<{ id: string }[]>`
        INSERT INTO ${sql(this.schema)}.audit_events (
          guild_id, bot_name, event, severity,
          actor_id, target_id, channel_id,
          source, correlation_id, details
        ) VALUES (
          ${input.guildId}, ${input.botName}, ${input.event}, ${input.severity ?? 'info'},
          ${input.actorId ?? null}, ${input.targetId ?? null}, ${input.channelId ?? null},
          ${input.source ?? null}, ${input.correlationId ?? null},
          ${sql.json(redactObject(input.details ?? {}))}
        )
        RETURNING id
      `;
      return row!.id;
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  public async listForTarget(
    guildId: GuildId,
    targetId: UserId,
    limit = 50,
  ): Promise<readonly AuditEventRow[]> {
    const sql = this.conn();
    try {
      const rows = await sql<RawAuditRow[]>`
        SELECT * FROM ${sql(this.schema)}.audit_events
        WHERE guild_id = ${guildId} AND target_id = ${targetId}
        ORDER BY created_at DESC, id DESC
        LIMIT ${clampLimit(limit)}
      `;
      return rows.map(mapAuditRow);
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  /**
   * One member's history of a single kind of audit event.
   *
   * Separate from `listForTarget` rather than filtered after it, and the
   * difference matters. `listForTarget` returns the most recent N events of
   * *any* kind; filtering those in memory would quietly report "no AutoMod
   * history" for a member whose AutoMod hits happen to sit behind fifty
   * newer warnings. Pushing the predicate into SQL means the limit bounds
   * the answer rather than the search.
   *
   * Served by `audit_events_target_idx` — `(guild_id, target_id, created_at
   * DESC)`. Postgres walks that index in order and drops rows whose event
   * does not match, stopping once the limit is filled, so no additional
   * index is needed for this query shape.
   */
  public async listForTargetByEvent(
    guildId: GuildId,
    targetId: UserId,
    event: string,
    limit = 50,
  ): Promise<readonly AuditEventRow[]> {
    const sql = this.conn();
    try {
      const rows = await sql<RawAuditRow[]>`
        SELECT * FROM ${sql(this.schema)}.audit_events
        WHERE guild_id = ${guildId}
          AND target_id = ${targetId}
          AND event = ${event}
        ORDER BY created_at DESC, id DESC
        LIMIT ${clampLimit(limit)}
      `;
      return rows.map(mapAuditRow);
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  /**
   * Resolve one audit event, scoped to the guild.
   *
   * Guild-scoped in the query rather than checked after the fact, so a
   * cross-guild id is indistinguishable from a nonexistent one. The id
   * column is `uuid` and the caller supplies arbitrary text, so the
   * *column* is cast to text rather than the parameter to uuid — a
   * malformed id must be a clean miss, not SQLSTATE 22P02.
   */
  public async findById(guildId: GuildId, id: string): Promise<AuditEventRow | null> {
    const sql = this.conn();
    try {
      const [row] = await sql<RawAuditRow[]>`
        SELECT * FROM ${sql(this.schema)}.audit_events
        WHERE guild_id = ${guildId} AND id::text = ${id}
      `;
      return row ? mapAuditRow(row) : null;
    } catch (error) {
      throw toDatabaseError(error);
    }
  }

  public async listRecent(
    guildId: GuildId,
    limit = 50,
  ): Promise<readonly AuditEventRow[]> {
    const sql = this.conn();
    try {
      const rows = await sql<RawAuditRow[]>`
        SELECT * FROM ${sql(this.schema)}.audit_events
        WHERE guild_id = ${guildId}
        ORDER BY created_at DESC, id DESC
        LIMIT ${clampLimit(limit)}
      `;
      return rows.map(mapAuditRow);
    } catch (error) {
      throw toDatabaseError(error);
    }
  }
}

interface RawAuditRow {
  id: string;
  guild_id: string;
  bot_name: BotName;
  event: string;
  severity: LogSeverity;
  actor_id: string | null;
  target_id: string | null;
  channel_id: string | null;
  source: string | null;
  correlation_id: string | null;
  details: JsonObject;
  created_at: Date;
}

function mapAuditRow(row: RawAuditRow): AuditEventRow {
  return {
    id: row.id,
    guildId: row.guild_id as GuildId,
    botName: row.bot_name,
    event: row.event,
    severity: row.severity,
    actorId: row.actor_id as UserId | null,
    targetId: row.target_id as UserId | null,
    channelId: row.channel_id as ChannelId | null,
    source: row.source,
    correlationId: row.correlation_id as CorrelationId | null,
    details: row.details,
    createdAt: row.created_at,
  };
}

/** Bound page sizes so a caller cannot ask for the whole table. */
function clampLimit(limit: number): number {
  return Math.min(Math.max(Math.trunc(limit), 1), 200);
}
