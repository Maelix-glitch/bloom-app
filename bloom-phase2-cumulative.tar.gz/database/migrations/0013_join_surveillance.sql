-- =============================================================================
-- 0013 — join surveillance
-- =============================================================================
--
-- One index. No new table, no new column, no new data collected.
--
-- Anti-raid detection asks one question on every join: how many members have
-- joined this guild in the last N seconds. That is a range scan over
-- `guild_members` by `(guild_id, joined_at)`, and until now the only index on
-- the table was `(guild_id, onboarding_state)` — so the question would have
-- been answered by a sequential scan of every member the server has ever had,
-- on every single join.
--
-- During the exact event this feature exists to detect, that is hundreds of
-- sequential scans a minute against a table under concurrent write load. The
-- detector would have become part of the outage.
--
-- Partial on `joined_at IS NOT NULL`: the column is nullable because the
-- gateway does not always supply a join timestamp, and rows without one can
-- never satisfy a window predicate. Excluding them keeps the index to the
-- rows that can actually be returned.
--
-- DESC because every read is "the most recent window", and the bounded
-- sample the detector takes is ordered newest-first.
--
-- Reversible: DROP INDEX. Nothing depends on it for correctness, only for
-- not being slow.
-- =============================================================================

CREATE INDEX IF NOT EXISTS guild_members_joined_recent_idx
  ON bloom_discord.guild_members (guild_id, joined_at DESC)
  WHERE joined_at IS NOT NULL;

COMMENT ON INDEX bloom_discord.guild_members_joined_recent_idx IS
  'Join-velocity windows for anti-raid detection. See 0013_join_surveillance.sql.';
