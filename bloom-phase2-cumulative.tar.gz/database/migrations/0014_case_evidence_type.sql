-- =============================================================================
-- 0014 — case evidence: the enum value
-- =============================================================================
--
-- One ALTER TYPE, alone in its own migration, and the isolation is mandatory
-- rather than tidy.
--
-- PostgreSQL permits `ALTER TYPE ... ADD VALUE` inside a transaction block,
-- and the migration runner wraps every migration in one. What it does *not*
-- permit is using the new value in that same transaction:
--
--     ERROR: unsafe use of new value "evidence_attached" of enum type
--
-- The restriction exists because the new label is not durably visible to
-- other snapshots until the adding transaction commits. Anything that
-- references the literal — including a CHECK constraint, which has to cast
-- it — therefore has to wait for migration 0015.
--
-- Splitting it is the whole reason this file exists. Folded into 0015 the
-- migration would fail on a clean database, which is exactly where it would
-- be noticed last: replays and fresh environments, not the machine it was
-- written on.
--
-- Verified against PostgreSQL 17.4.
-- =============================================================================

ALTER TYPE bloom_discord.case_event_type
  ADD VALUE IF NOT EXISTS 'evidence_attached';
