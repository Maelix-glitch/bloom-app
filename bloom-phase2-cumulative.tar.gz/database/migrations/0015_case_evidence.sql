-- =============================================================================
-- 0015 — case evidence: the reference
-- =============================================================================
--
-- Two nullable columns on `case_events`, a completeness CHECK and a partial
-- unique index. No new table: an attachment is a thing that happened to a
-- case, which is precisely what `case_events` already records.
--
-- ## Why columns rather than text in `body`
--
-- `body` is free text, and `/guardian case note` writes to it under the same
-- `staff.cases.manage` capability that attaching evidence requires. Encoding
-- a reference there would mean a moderator could *type* a record
-- indistinguishable from a validated one — making the guild check, the
-- subject check and the source-existence check decorative. Typed columns
-- make the forged version impossible to express rather than merely
-- discouraged.
--
-- ## What is deliberately not stored
--
-- A reference, never a copy. `evidence_source_id` points at an immutable row
-- that already exists — a `moderation_actions.id` or an `audit_events.id`.
-- No message content, no matched content, no matched keyword, no `details`
-- blob, no `metadata` blob. The AutoMod privacy boundary established in
-- Phase 2 Task 2 survives this feature because there is nowhere here to put
-- the data it excludes.
-- =============================================================================

ALTER TABLE bloom_discord.case_events
  ADD COLUMN IF NOT EXISTS evidence_type text
    CHECK (
      evidence_type IS NULL
      OR evidence_type IN ('moderation_action', 'automod_event')
    ),
  -- Wide enough for a uuid (36) or a bigint id rendered as text, and bounded
  -- so an unvalidated caller-supplied string cannot become unbounded storage.
  ADD COLUMN IF NOT EXISTS evidence_source_id text
    CHECK (
      evidence_source_id IS NULL
      OR length(evidence_source_id) BETWEEN 1 AND 64
    );

-- Mirrors `case_events_status_change_complete` from migration 0005: the row
-- type and its payload columns agree, in both directions. An evidence row
-- without a reference is meaningless, and a note carrying evidence columns is
-- the forgery this design exists to prevent.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'case_events_evidence_complete'
      AND conrelid = 'bloom_discord.case_events'::regclass
  ) THEN
    ALTER TABLE bloom_discord.case_events
      ADD CONSTRAINT case_events_evidence_complete CHECK (
        (
          event_type = 'evidence_attached'
          AND evidence_type IS NOT NULL
          AND evidence_source_id IS NOT NULL
        )
        OR (
          event_type <> 'evidence_attached'
          AND evidence_type IS NULL
          AND evidence_source_id IS NULL
        )
      );
  END IF;
END $$;

-- The authoritative duplicate guard.
--
-- Idempotency is enforced here rather than by reading before writing, because
-- read-then-write races exactly when two moderators act on the same incident
-- at the same time — the realistic case, not the exotic one. The application
-- catches the unique violation and reports "already attached"; the database
-- decides.
--
-- Partial, so it indexes only evidence rows. Every other case event has NULLs
-- in both columns, and in a non-partial index those would be stored and
-- compared for nothing.
CREATE UNIQUE INDEX IF NOT EXISTS case_events_evidence_unique
  ON bloom_discord.case_events (case_id, evidence_type, evidence_source_id)
  WHERE event_type = 'evidence_attached';
