# Start here — Bloom, the whole project (2026-08-30)

Every file in the project, ready to open in VS Code.

```bash
unzip bloom-app-full.zip
cd bloom-app
npm install
npm run dev
```

Then:

| Route | What it is |
| --- | --- |
| `/` | mood |
| `/cycle` | the redesigned cycle page (Supabase-backed, eight themes) |
| `/cycle-styles` | the same page in all eight themes |
| `/cycle-classic` | the previous cycle design |
| `/trackers` | sleep, water, study, movement, energy, screen |
| `/coach` | the grounded coach — reads your own logs and answers from them |
| `/profile`, `/rewards`, `/admin` | account, rewards, admin |

## What changed most recently

* **Cycle page is wired to Supabase again** — `cycle_entries`, upsert on
  `(profile_id, date)`, exactly like the old page. Device-first, with
  background sync and an honest line in the header about where the day lives.
* **Coach answers from your record** — sleep, water, study, movement, energy,
  screen, cycle and mood. Two fixes: replies that came back as jsonb used to be
  `String()`-ed into `[object Object]`, and the single canned response ("no mood
  history yet") has been replaced with an answer that reads whatever you have
  actually logged — and says plainly, and specifically, when there's nothing to
  read yet.
* **Trackers page** — six trackers, a 24-hour day dial, one-tap quick-adds and
  an advanced read that contrasts your bright days against your low ones.

## Env

`.env.example` lists the two variables. Without them everything still runs
device-local and the pages say so.

```
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
```

## Checks

`npx tsc --noEmit` clean · `npx vitest run` — 160 tests passing.

For just the cycle page there's `bloom-cycle-page.zip` on the branch, next to
this file.
