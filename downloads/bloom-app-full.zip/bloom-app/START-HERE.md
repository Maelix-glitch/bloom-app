# Start here — Bloom, the whole project (2026-08-30)

Unzip, then:

```bash
cd bloom-app
npm install
npm run dev
```

Routes: `/` mood · `/cycle` the redesigned cycle page · `/cycle-styles` eight themes ·
`/trackers` sleep, water, study, movement, energy, screen · `/coach` the grounded coach.

Everything is self-contained: the coach no longer imports the trackers module, so
it opens whether or not you take that page.

Recent fixes: the cycle page is wired back to Supabase `cycle_entries`; the coach no
longer prints `[object Object]` and answers from your own record.
