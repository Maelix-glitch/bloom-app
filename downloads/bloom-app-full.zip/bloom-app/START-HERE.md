# Start here — Bloom (2026-08-30)

```bash
cd bloom-app && npm install && npm run dev
```

Routes: `/` mood · `/cycle` the redesigned cycle page (Supabase-backed) ·
`/cycle-styles` eight themes · `/trackers` the Atlas design ·
`/trackers-styles` switch between Atlas, Ledger, Strip and Console · `/coach`.

/trackers now renders the **Atlas** design: a 24-hour compass rose, six
territories drawn from contour lines, one route with six paths, a study field
and the advanced read. The choice is saved in localStorage.
