# Bloom — the cycle page (ready to drop into VS Code)

Everything here is the **redesigned cycle page** as it runs right now: the three
routes, every component it draws, its stylesheet, the pure intelligence module
and the Supabase sync that keeps `cycle_entries` in step with the device.

Stack already in the repo: React 19 + TanStack Start + Vite + Tailwind v4 (@tailwindcss/vite).

## Where each file goes

The zip mirrors your project tree. Unzip it and copy `src/` over your project's `src/`.
`new` = create it, `replace` = overwrite the file that's already there.

### `src/routes/` — the pages


### `src/components/ci/` — the whole redesign


### `src/components/` — the rest



| `src/components/BloomHeader.tsx` | **replace** (adds the Trackers link) |

### `src/lib/cycle/` — intelligence + sync


### `src/lib/`

| `src/lib/supabase.ts` | **replace** (now lazy — a missing env var no longer blanks the route) |
| `src/lib/utils.ts` | **replace** |

### `src/hooks/`


### `src/styles/`


## Supabase

Same table and conflict key as the old HTML page: table `cycle_entries`, upsert
on `(profile_id, date)`, `profile_id` = the signed-in user's id.

`.env.local` needs:

```
VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
```

(`.env.example` in the repo root has the same two lines.)

How it behaves:

* the page always draws from `localStorage` first, so it never waits on the network
* on load it pulls `cycle_entries` and reconciles — newer `updated_at` wins on a shared date
* saving writes to the device immediately, then upserts ~0.7s later
* if the table can't be reached the day stays on the device and the header says so
* with no env vars, or nobody signed in, it says "saved on this device only" and carries on

## Do NOT paste or edit

| File | Why |
| --- | --- |
| `src/routeTree.gen.ts` | generated — it rewrites itself when the dev server starts |
| `package.json` | nothing new to install |
| `vite.config.ts`, `tsconfig.json` | your `@/` → `src/` alias is already there |

## After pasting

```bash
npm install
npm run dev
```

Then open:

- `http://localhost:3000/cycle` — the redesign
- `http://localhost:3000/cycle-styles` — all eight themes, pick one
- `http://localhost:3000/cycle-classic` — the old page, kept for comparison

If `/cycle` 404s, restart the dev server so `routeTree.gen.ts` regenerates.

## What's guaranteed

* The intelligence is pure. `src/lib/cycle/predict.ts` takes entries and returns
  predictions and flags — no React, no storage, no DOM.
* A prediction never appears without its confidence; estimates are worded as estimates.
* Editing or deleting a day recomputes everything live — nothing cached.
* The disclaimer is always visible: your own logged data, not medical advice,
  and it cannot diagnose anything.

Packed 2026-08-30.
