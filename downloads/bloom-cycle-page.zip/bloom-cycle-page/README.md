# Bloom — the cycle page (ready to drop into VS Code)

Everything here is the **redesigned cycle page** exactly as it runs right now:
the three routes, every component it draws, its stylesheet and the pure
intelligence module behind it.

Stack already in the repo: React 19 + TanStack Start + Vite + Tailwind v4 (@tailwindcss/vite).

## 1. Where each file goes

The zip mirrors your project tree. Unzip it and copy `src/` over your project's `src/`.
Every path below is the final path — do not rename anything.

```
bloom-cycle-page/
  README.md
  src/
    routes/
      cycle.tsx           ->  the redesigned page        (visit /cycle)
      cycle-styles.tsx    ->  the eight-theme gallery    (visit /cycle-styles)
      cycle-classic.tsx   ->  the previous design, kept for comparison
    components/
      ci/                 ->  the whole redesign: CycleIntelligence, PhaseWave,
                              CycleDial, CycleHeatmap, RhythmChart, VitalDials,
                              SymptomBloom, SymptomPhaseGrid, PredictionsCard,
                              AnalyticsCards, InsightsPanel, TipsCard, LogPanel,
                              DayLogInsights, HistoryTable, SignatureStrip,
                              Atmosphere, motion.tsx, primitives.tsx
      BloomHeader.tsx     ->  top nav (Cycle / Mood / Trackers)
      cycle/  mood/  ui/  ->  supporting pieces the routes import
    lib/cycle/            ->  predict.ts (pure), dayLogs.ts, periodStore.ts,
                              intelligence.ts, patterns.ts, presentation.ts,
                              themes.ts, types.ts, palette.ts, storage.ts
    hooks/                ->  usePeriodLog.ts (store hook + useCycleTheme)
    styles/
      cycle2.css          ->  the redesign's stylesheet (8 themes, atmosphere, motion)
      cycle.css           ->  the older stylesheet, used by /cycle-classic
```

## 2. Before it runs

Nothing new to install — already in package.json:

```
lucide-react  sonner  @radix-ui/react-dialog  @radix-ui/react-dialog (sheet)
```

Two settings the imports rely on:

* the `@/` alias pointing at `src/` (already set in tsconfig.json paths and vite.config.ts resolve.alias)
* Tailwind v4 via `@tailwindcss/vite`, with `@import "tailwindcss";` in the global CSS

`src/routeTree.gen.ts` is generated — TanStack Start picks up `src/routes/cycle.tsx`
automatically. Don't hand-edit it; if `/cycle` 404s, restart `npm run dev`.

## 3. Run it

```bash
npm install
npm run dev
# http://localhost:3000/cycle          the redesigned page
# http://localhost:3000/cycle-styles   all eight themes side by side
```

## 4. What's guaranteed about this code

* The intelligence is pure. `src/lib/cycle/predict.ts` takes entries and returns
  predictions and flags — no React, no storage, no DOM. Liftable to a server or
  another frontend untouched.
* A prediction never appears without its confidence; estimates are always worded
  as estimates.
* Editing or deleting a day recomputes everything live — nothing cached.
* The standing disclaimer is always visible: estimates from your own logged data,
  not medical advice, and they cannot diagnose anything.

## 5. The eight themes

`/cycle-styles` renders the same page in all eight so you can pick one.
The theme lives on the page root:

```tsx
<div className="ci ci-root" data-theme="nocturne">
```

Swap `nocturne` for another key — see `src/lib/cycle/themes.ts` for the list.

Packed 2026-08-30.
