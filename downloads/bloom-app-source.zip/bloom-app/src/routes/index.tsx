import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Bell, Droplet, Loader2, Plus, Smile } from "lucide-react";

import { AppNav } from "@/components/home/HomeSidebar";
import { ConnectionMap, ConnectionMapSkeleton } from "@/components/home/ConnectionMap";
import { useEverReady } from "@/hooks/useEverReady";
import { CoachPanel } from "@/components/home/CoachPanel";
import { HabitsSection } from "@/components/home/HabitsSection";
import { HabitUndo } from "@/components/home/HabitUndo";
import {
  ActivityPanel,
  FlowPanel,
  FocusPanel,
  InsightsPanel,
  ProgressPanel,
  TrackersPanel,
} from "@/components/home/panels";
import { MetricsEntryModal } from "@/components/tk/MetricsEntryModal";
import { Composer } from "@/components/mood/Composer";
import { AddHabitModal } from "@/components/tk/AddHabitModal";

import { useTrackers } from "@/hooks/useTrackers";
import { useHabits } from "@/hooks/useHabits";
import { useMoodSystem } from "@/hooks/useMoodSystem";
import { usePeriodLog } from "@/hooks/usePeriodLog";
import { useFlowTimes } from "@/hooks/useFlowTimes";
import { useProfileSpace } from "@/hooks/useProfileSpace";
import {
  activityOf,
  connections,
  flowOf,
  focusOf,
  greetingFor,
  insightsOf,
  longDate,
  moodToday,
  readings,
  scoreOf,
} from "@/lib/home/today";
import { habitToDraft, type HabitDraft } from "@/lib/home/habits";
import type { AddHabitPrefill } from "@/components/tk/AddHabitModal";

import windowDusk from "@/assets/home/window-dusk.jpg";
import { RankChip } from "@/components/progression/RankChip";
import { componentsById } from "@/lib/rewards/catalog";
import { loadRewardsStore, subscribeRewards } from "@/lib/rewards/store";
import { StoryRail } from "@/components/stories/StoryRail";
import { StoryComposer } from "@/components/stories/StoryComposer";
import { StoryViewer } from "@/components/stories/StoryViewer";
import { seenStore } from "@/lib/stories/seen";
import type { CreateStoryInput } from "@/lib/profile/storyService";
import type { Story } from "@/lib/profile/types";
import { toast } from "sonner";

const TITLE = "Bloom — Today";
const DESCRIPTION =
  "Bloom is a calm daily companion: track mood, sleep, habits, study, cycle and energy, and see how they connect in one living map.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TodayPage,
});

function useNow(intervalMs = 60_000): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), intervalMs);
    const tick = () => setNow(new Date());
    window.addEventListener("focus", tick);
    return () => {
      window.clearInterval(id);
      window.removeEventListener("focus", tick);
    };
  }, [intervalMs]);
  return now;
}

/**
 * The hero ambience on Today. When a wallpaper reward is equipped it becomes
 * the hero artwork (the same asset the Rewards page shows) — customization is
 * real, not a preview-only flourish.
 */
function WallpaperFigure() {
  const [art, setArt] = useState<string | null>(null);
  useEffect(() => {
    const sync = () => {
      const equipped = loadRewardsStore().equipped;
      const wallpaperId = equipped.wallpaperId;
      setArt(wallpaperId ? (componentsById.get(wallpaperId)?.art ?? null) : null);
    };
    sync();
    return subscribeRewards(sync);
  }, []);
  const isCustom = art !== null;
  return (
    <img
      src={art ?? windowDusk}
      alt={
        isCustom
          ? "An equipped Bloom wallpaper brightening the day"
          : "A journal open on a desk beside a window at dusk"
      }
      width={928}
      height={720}
      className="h-full w-full object-cover"
    />
  );
}

function TodayPage() {
  const trackers = useTrackers();
  const habits = useHabits();
  const mood = useMoodSystem();
  const cycle = usePeriodLog();
  const space = useProfileSpace();
  const now = useNow();

  const [metricsOpen, setMetricsOpen] = useState(false);
  const [moodOpen, setMoodOpen] = useState(false);
  const [habitOpen, setHabitOpen] = useState(false);
  /** Which habit the dialog is editing; null = creating a new one. */
  const [editingHabitId, setEditingHabitId] = useState<string | null>(null);
  const [habitNotice, setHabitNotice] = useState<string | null>(null);

  /* stories — the day begins with the people in it (starting with you) */
  const [storyComposerOpen, setStoryComposerOpen] = useState(false);
  const [storyViewer, setStoryViewer] = useState<{
    stories: Story[];
    startIndex: number;
  } | null>(null);
  const [, setSeenTick] = useState(0);
  useEffect(() => {
    const onSeen = () => setSeenTick((t) => t + 1);
    window.addEventListener("bloom:story-seen", onSeen);
    return () => window.removeEventListener("bloom:story-seen", onSeen);
  }, []);
  const homeStories = useMemo(() => space.storiesByAge?.active ?? [], [space.storiesByAge]);
  const homeMilestones = useMemo(
    () => (space.journey.status === "ready" ? space.journey.milestones.achieved : []),
    [space.journey],
  );
  const publishHomeStory = async (input: CreateStoryInput) => {
    try {
      await space.actions.publishStory(input);
      toast(input.visibility === "public" ? "Story published." : "Saved privately.");
    } catch (error) {
      throw error instanceof Error && error.message
        ? error
        : new Error("Couldn't publish your story.");
    }
  };
  const deleteHomeStory = (story: Story) => {
    void space.actions
      .removeStory(story)
      .then(({ undo }) => {
        setStoryViewer((v) =>
          v && v.stories.length <= 1
            ? null
            : v
              ? { ...v, stories: v.stories.filter((s) => s.id !== story.id) }
              : null,
        );
        toast("Story deleted.", {
          action: {
            label: "Undo",
            onClick: () => {
              void undo().catch(() => toast.error("Couldn't bring that back."));
            },
          },
        });
      })
      .catch((error: unknown) =>
        toast.error(error instanceof Error ? error.message : "Couldn't delete that just now."),
      );
  };

  const today = trackers.today;
  const identity = space.identity?.identity ?? null;
  const displayName =
    identity && identity.displayName && identity.displayName !== "Bloom User"
      ? identity.displayName
      : null;
  const firstName = displayName ? displayName.split(" ")[0]! : null;

  const moodEntry = useMemo(() => moodToday(mood.entries, today), [mood.entries, today]);
  const moodDays = mood.analytics.days;

  const signalReadings = useMemo(
    () =>
      readings({
        trackers: trackers.analysis,
        habits: { completedToday: habits.completedToday, dueToday: habits.dueToday },
        mood: moodEntry,
        cycle: cycle.analysis,
        cycleMode: cycle.mode,
      }),
    [
      trackers.analysis,
      habits.completedToday,
      habits.dueToday,
      moodEntry,
      cycle.analysis,
      cycle.mode,
    ],
  );

  const score = useMemo(
    () =>
      scoreOf({
        trackers: trackers.analysis,
        habits: { completedToday: habits.completedToday, dueToday: habits.dueToday },
        mood: moodEntry,
      }),
    [trackers.analysis, habits.completedToday, habits.dueToday, moodEntry],
  );

  const map = useMemo(
    () =>
      connections({
        trackers: trackers.analysis,
        habits: {
          habits: habits.habits,
          logs: habits.logs,
          completedToday: habits.completedToday,
          dueToday: habits.dueToday,
        },
        moodEntries: mood.entries,
        moodDays,
        moodCorrelations: mood.analytics.correlations,
        cycle: cycle.analysis,
        cycleMode: cycle.mode,
        today,
      }),
    [
      trackers.analysis,
      habits.habits,
      habits.logs,
      habits.completedToday,
      habits.dueToday,
      mood.entries,
      moodDays,
      mood.analytics.correlations,
      cycle.analysis,
      cycle.mode,
      today,
    ],
  );

  const flowTimes = useFlowTimes();
  const flow = useMemo(
    () =>
      flowOf({
        habits: habits.todayHabits,
        mood: moodEntry,
        trackers: trackers.analysis,
        now,
        times: flowTimes.times,
      }),
    [habits.todayHabits, moodEntry, trackers.analysis, now, flowTimes.times],
  );

  const focus = useMemo(
    () =>
      focusOf({
        habits: habits.todayHabits,
        mood: moodEntry,
        trackers: trackers.analysis,
        cycle: cycle.analysis,
        cycleMode: cycle.mode,
      }),
    [habits.todayHabits, moodEntry, trackers.analysis, cycle.analysis, cycle.mode],
  );

  const insights = useMemo(
    () =>
      insightsOf({
        trackers: trackers.analysis,
        moodInsights: mood.analytics.insights,
        moodCorrelations: mood.analytics.correlations,
        habits: { habits: habits.habits, logs: habits.logs },
        cycle: cycle.analysis,
        today,
      }),
    [
      trackers.analysis,
      mood.analytics.insights,
      mood.analytics.correlations,
      habits.habits,
      habits.logs,
      cycle.analysis,
      today,
    ],
  );

  const activity = useMemo(
    () =>
      activityOf({
        habits: { habits: habits.habits, logs: habits.logs },
        moodEntries: mood.entries,
        trackers: trackers.analysis,
        cycle: cycle.analysis,
      }),
    [habits.habits, habits.logs, mood.entries, trackers.analysis, cycle.analysis],
  );

  /* B9 — the map only draws once its stores have real data (latched: refetches
  never re-flash the skeleton). */
  const mapReady = useEverReady(
    trackers.hydrated && cycle.hydrated && !habits.loading && !mood.loading,
  );

  const openCount = focus.filter((f) => !f.done).length;
  const subline =
    !trackers.hydrated || habits.loading
      ? "Reading today's record…"
      : openCount === 0
        ? "Everything you track is logged. Enjoy the quiet."
        : openCount === 1
          ? "One thing left to shape your day."
          : `${["Two", "Three"][openCount - 2] ?? openCount} things left to shape your day.`;

  const syncLine =
    trackers.sync.state === "off"
      ? "Saved on this device"
      : trackers.sync.state === "signed-out"
        ? "Saved on this device — sign in to sync"
        : trackers.sync.message || null;

  const addHabit = async (draft: HabitDraft) => {
    try {
      if (editingHabitId) await habits.editHabit(editingHabitId, draft);
      else await habits.addHabit(draft);
      setHabitNotice(null);
    } catch (e) {
      console.warn("[bloom:home] save habit:", e);
      setHabitNotice(
        editingHabitId
          ? "That change couldn't reach your account. Try again in a moment."
          : "That habit couldn't be saved to your account. It's kept on this device for now.",
      );
      throw e;
    }
  };

  const openNewHabit = () => {
    setEditingHabitId(null);
    setHabitOpen(true);
  };
  const openEditHabit = (id: string) => {
    setEditingHabitId(id);
    setHabitOpen(true);
  };
  const editingHabit = editingHabitId
    ? (habits.habits.find((h) => h.id === editingHabitId) ?? null)
    : null;
  const habitPrefill: AddHabitPrefill | undefined = editingHabit
    ? (habitToDraft(editingHabit) as AddHabitPrefill)
    : undefined;

  return (
    <div className="home-page app-shell min-h-screen bg-background text-foreground">
      {/* the one shared chrome: rail on desktop, brand bar + tab bar on phones */}
      <AppNav />

      <main className="home-main min-w-0 px-5 pb-28 pt-5 sm:px-8 sm:pt-6 lg:px-10 lg:pb-16 lg:pt-7">
        <div className="home-toolbar">
          <p className="text-xs text-muted-foreground">
            {longDate(now)}
            {syncLine ? (
              <span className="ml-3 hidden text-faint sm:inline">· {syncLine}</span>
            ) : null}
          </p>
          <Link
            to="/rewards"
            aria-label="Rewards"
            title="Rewards"
            className="relative grid size-9 place-items-center rounded-full border border-border bg-surface-2/50 text-muted-foreground transition-colors hover:text-foreground"
          >
            <Bell className="size-4" />
            {habits.points !== null && habits.points > 0 ? (
              <span
                className="absolute right-2 top-2 size-1.5 rounded-full"
                style={{ background: "var(--home-cycle)" }}
              />
            ) : null}
          </Link>
        </div>

        <header className="home-rise mt-5 grid gap-6 lg:mt-6 lg:grid-cols-[minmax(0,1fr)_280px]">
          <div>
            <h1 className="font-display text-3xl leading-tight sm:text-5xl">
              {firstName ? (
                <>
                  {greetingFor(now.getHours())},{" "}
                  <em className="home-text-gradient italic">{firstName}.</em>
                </>
              ) : (
                <em className="home-text-gradient italic">{greetingFor(now.getHours())}.</em>
              )}
            </h1>
            <p className="mt-1.5 font-display text-xl text-muted-foreground sm:text-3xl">
              {subline}
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <button type="button" onClick={() => setMoodOpen(true)} className="home-chip">
                <Smile className="size-4" style={{ color: "var(--home-habits)" }} />
                {moodEntry ? `Mood ${Math.round(moodEntry.mood)}/10 logged` : "Log today's mood"}
              </button>
              <button type="button" onClick={() => setMetricsOpen(true)} className="home-chip">
                <Droplet className="size-4" style={{ color: "var(--home-sleep)" }} />
                {trackers.analysis.goalsMetToday > 0
                  ? `${trackers.analysis.goalsMetToday} of 6 goals met`
                  : "Log today's metrics"}
              </button>
              <Link to="/rewards" className="home-chip">
                <RankChip points={habits.points} />
              </Link>
            </div>
            {space.authState === "signed-out" ? (
              <p className="mt-4 text-[12px] text-muted-foreground">
                You're browsing on this device only.{" "}
                <Link to="/profile" className="underline underline-offset-2 hover:text-foreground">
                  Sign in
                </Link>{" "}
                to sync habits, mood, cycle and trackers to your account.
              </p>
            ) : null}
            {habits.error || habitNotice ? (
              <p className="mt-3 text-[12px] text-rose" role="status">
                {habitNotice ?? habits.error}
              </p>
            ) : null}
          </div>

          <figure className="relative hidden overflow-hidden rounded-2xl border border-border lg:block">
            <WallpaperFigure />
            <figcaption className="absolute inset-0 flex flex-col justify-between bg-gradient-to-t from-background/90 via-background/20 to-background/70 p-4">
              <span className="font-display text-sm italic leading-snug text-muted-foreground">
                Discipline today, freedom tomorrow.
                <span className="mt-2 block h-px w-8 bg-border" />
              </span>
              <span className="font-display text-2xl leading-snug">
                Same person. A more intentional day.
              </span>
            </figcaption>
          </figure>
        </header>

        <div className="home-stack">
          {space.authState !== "signed-out" && space.userId ? (
            <section className="home-band" aria-labelledby="home-moments-title">
              <div className="home-band-head">
                <div>
                  <p className="home-eyebrow">Moments</p>
                  <h2 id="home-moments-title" className="home-band-title">
                    Today's stories
                  </h2>
                </div>
                <p className="home-band-note hidden sm:block">
                  {homeStories.length === 0
                    ? "A quiet ring — add one from the day."
                    : `${homeStories.length} live · fades in 24 hours`}
                </p>
              </div>
              <StoryRail
                name={identity?.displayName ?? "You"}
                avatarPath={identity?.avatarPath ?? null}
                accent={identity?.accent ?? "violet"}
                stories={homeStories}
                seenIds={new Set(homeStories.filter((s) => seenStore.has(s.id)).map((s) => s.id))}
                loading={space.storiesByAge == null}
                onAdd={() => setStoryComposerOpen(true)}
                onOpen={(index) => setStoryViewer({ stories: homeStories, startIndex: index })}
                label="Today's stories"
              />
            </section>
          ) : null}

          <HabitsSection
            habits={habits.todayHabits}
            logs={habits.logs}
            today={habits.today}
            loading={habits.loading}
            points={habits.points}
            onToggle={(id, date) => void habits.toggle(id, date)}
            onAdd={openNewHabit}
            paused={habits.pausedHabits}
            archived={habits.archivedHabits}
            actions={{
              onEdit: openEditHabit,
              onPause: (id, until) => void habits.pauseHabit(id, until),
              onResume: (id) => void habits.resumeHabit(id),
              onArchive: (id) => void habits.archiveHabit(id),
              onRestore: (id) => void habits.restoreHabit(id),
              onDelete: (id) => void habits.deleteHabit(id),
            }}
          />

          <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
            <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] gap-6">
              <div className="grid gap-5 md:grid-cols-[240px_minmax(0,1fr)]">
                <ProgressPanel
                  score={score}
                  onLog={() => setMetricsOpen(true)}
                  logging={!trackers.hydrated}
                />
                {mapReady ? (
                  <ConnectionMap nodes={map.nodes} links={map.links} name={firstName} />
                ) : (
                  <ConnectionMapSkeleton />
                )}
              </div>
              <TrackersPanel readings={signalReadings} />
              <div className="grid gap-5 md:grid-cols-2">
                <FlowPanel
                  items={flow}
                  now={now}
                  onToggleHabit={(id) => void habits.toggle(id)}
                  times={flowTimes.times}
                  onTimeChange={flowTimes.setTime}
                  onResetTimes={flowTimes.reset}
                  timesAreDefault={flowTimes.isDefault}
                />
                <InsightsPanel items={insights} loading={mood.loading || !trackers.hydrated} />
              </div>
            </div>

            <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] gap-6 lg:content-start">
              <FocusPanel
                items={focus}
                onToggleHabit={(id) => void habits.toggle(id)}
                onAddHabit={openNewHabit}
              />
              <CoachPanel entries={mood.entries} habitsStore={habits} />
              <ActivityPanel items={activity} />
            </div>
          </div>

          <footer className="hidden items-center justify-center gap-6 text-[11px] tracking-[0.3em] text-muted-foreground lg:flex">
            <span className="font-display text-base tracking-[0.5em]">BLOOM</span>
            <span className="h-px w-16 bg-border" />
            <span>A MORE INTENTIONAL DAY, EVERYWHERE</span>
          </footer>
        </div>
      </main>

      {/* floating add-habit — always in reach, clears the tab bar on phones */}
      <button
        type="button"
        onClick={openNewHabit}
        aria-label="Add habit"
        title="Add habit"
        data-testid="home-fab-add-habit"
        className="home-fab inline-flex h-12 items-center gap-2 rounded-full bg-primary px-3.5 text-sm font-medium text-primary-foreground lg:hidden sm:h-13 sm:pl-4 sm:pr-5"
      >
        <Plus className="size-5" />
        <span className="hidden sm:inline">Add habit</span>
      </button>

      {/* the same three entry surfaces the rest of Bloom uses — one data path each */}
      <MetricsEntryModal
        store={trackers}
        open={metricsOpen}
        onClose={() => setMetricsOpen(false)}
      />
      <Composer
        open={moodOpen}
        initial={moodEntry}
        onClose={() => setMoodOpen(false)}
        onSave={mood.saveEntry}
        onDelete={(entry) => mood.removeEntry(entry.id)}
      />
      <AddHabitModal
        open={habitOpen}
        onClose={() => {
          setHabitOpen(false);
          setEditingHabitId(null);
        }}
        onSubmit={addHabit}
        prefill={habitPrefill}
      />
      <HabitUndo undoable={habits.undoable} onUndo={habits.undo} onDismiss={habits.dismissUndo} />

      {/* stories: today's rings, the creator, and the session */}
      {space.userId ? (
        <>
          <StoryComposer
            open={storyComposerOpen}
            userId={space.userId}
            defaultAccent={identity?.accent ?? "violet"}
            defaultVisibility={space.identity?.privacy.storyVisibility ?? "private"}
            moodEntries={mood.entries}
            rewards={space.rewardsBlock?.status === "ready" ? space.rewardsBlock.data : []}
            milestones={homeMilestones}
            onPublish={publishHomeStory}
            onClose={() => setStoryComposerOpen(false)}
          />
          <StoryViewer
            target={storyViewer}
            viewerName={identity?.displayName ?? "You"}
            viewerAvatarPath={identity?.avatarPath ?? null}
            accent={identity?.accent ?? "violet"}
            userId={space.userId}
            userName={identity?.displayName ?? null}
            ownerId={space.userId}
            onSeen={(story) => seenStore.mark(story.id)}
            onDelete={storyViewer ? deleteHomeStory : undefined}
            onClose={() => setStoryViewer(null)}
          />
        </>
      ) : null}

      {!trackers.hydrated ? (
        <div
          className="pointer-events-none fixed left-4 z-20 flex items-center gap-2 rounded-full border border-border bg-surface/90 px-3 py-1.5 text-[11px] text-muted-foreground lg:left-[228px]"
          style={{ bottom: "calc(1rem + var(--app-bottom-nav, 0px))" }}
        >
          <Loader2 className="size-3 animate-spin" /> Loading
        </div>
      ) : null}
    </div>
  );
}