#!/usr/bin/env node
/**
 * Bloom — Today (home) page migration kit  (v5: the rail is fixed — one
 * screen tall, never scrolls with the page — brand mark aligned with the nav
 * icons, taller phone header; v4: one chrome — the rail from the top of the
 * page, no second header; v3: the v3 "latest" Add-habit dialog; v2: habits
 * section, floating add-habit button, shared sidebar)
 *
 * Run from anywhere:   node "<path to this folder>\apply-today-home.mjs" [repo path]
 * Defaults to the current working directory as the repo. Idempotent: safe to
 * run twice, and safe to run on a repo that already has v1, v2, v3 or v4
 * applied (it only adds what is missing). Never deletes anything except the old
 * src/routes/index.tsx, which it first moves to src/routes/mood.tsx (Mood
 * Intelligence keeps working at /mood).
 *
 * Requires: the metrics-modal fix already applied (src/components/tk/MetricsEntryModal.tsx exists).
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(process.argv[2] ?? process.cwd());
const files = path.join(here, "files");

const ok = (m) => console.log("  \u2714 " + m);
const skip = (m) => console.log("  \u2022 " + m + " (already done)");
const fail = (m) => {
  console.error("  \u2716 " + m);
  process.exitCode = 1;
};

function read(p) {
  return fs.readFileSync(p, "utf8");
}
function write(p, text, crlf) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, crlf ? text.replace(/\r?\n/g, "\r\n") : text);
}
function isCrlf(p) {
  return fs.existsSync(p) && fs.readFileSync(p).includes("\r\n");
}
function copyFile(rel, { overwrite = true } = {}) {
  const src = path.join(files, rel);
  const dst = path.join(repo, rel);
  if (!fs.existsSync(src)) return fail(`kit is missing ${rel}`);
  if (fs.existsSync(dst) && !overwrite) return skip(rel);
  if (fs.existsSync(dst) && fs.readFileSync(dst).equals(fs.readFileSync(src))) return skip(rel);
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
  ok(`wrote ${rel}`);
}
function patch(rel, edits) {
  const p = path.join(repo, rel);
  if (!fs.existsSync(p)) return fail(`${rel} not found`);
  const crlf = isCrlf(p);
  let text = read(p).replace(/\r\n/g, "\n");
  let changed = 0;
  for (const e of edits) {
    if (e.marker && text.includes(e.marker)) continue;
    if (!text.includes(e.from)) {
      if (e.optional) continue;
      fail(`${rel}: anchor not found for "${e.name}"`);
      continue;
    }
    text = text.replace(e.from, e.to);
    changed++;
  }
  if (changed === 0) return skip(rel);
  write(p, text, crlf);
  ok(`patched ${rel} (${changed} edit${changed === 1 ? "" : "s"})`);
}

console.log(`\nBloom Today-home kit \u2192 ${repo}\n`);

/* 0. sanity */
if (!fs.existsSync(path.join(repo, "package.json")) || !fs.existsSync(path.join(repo, "src/routes"))) {
  console.error("This doesn't look like the Bloom repo (no package.json + src/routes). Pass the repo path as an argument.");
  process.exit(1);
}
if (!fs.existsSync(path.join(repo, "src/components/tk/MetricsEntryModal.tsx"))) {
  console.error("Apply the metrics-modal fix kit first (src/components/tk/MetricsEntryModal.tsx is missing).");
  process.exit(1);
}

/* 1. Mood Intelligence moves from / to /mood */
{
  const idx = path.join(repo, "src/routes/index.tsx");
  const mood = path.join(repo, "src/routes/mood.tsx");
  const current = fs.existsSync(idx) ? read(idx) : "";
  if (fs.existsSync(mood)) {
    skip("src/routes/mood.tsx");
  } else if (current.includes("Mood Intelligence") && current.includes('createFileRoute("/")')) {
    const crlf = current.includes("\r\n");
    write(mood, current.replace(/\r\n/g, "\n").replace('createFileRoute("/")', 'createFileRoute("/mood")'), crlf);
    ok("moved src/routes/index.tsx \u2192 src/routes/mood.tsx (route /mood)");
  } else {
    copyFile("src/routes/mood.tsx");
  }
}

/* 2. new files */
for (const rel of [
  "src/routes/index.tsx",
  "src/components/home/CoachPanel.tsx",
  "src/components/home/ConnectionMap.tsx",
  "src/components/home/HomeSidebar.tsx",
  "src/components/home/HabitsSection.tsx",
  "src/components/home/ProgressRing.tsx",
  "src/components/home/panels.tsx",
  "src/hooks/useHabits.ts",
  "src/lib/home/habits.ts",
  "src/components/tk/AddHabitModal.tsx",
  "src/styles/add-habit-modal.css",
  "src/lib/home/habits.test.ts",
  "src/lib/home/today.ts",
  "src/assets/home/leaf-dark.jpg",
  "src/assets/home/sidebar-botanical.jpg",
  "src/assets/home/window-dusk.jpg",
  "supabase/migrations/20260906_today_home.sql",
  "src/components/BloomHeader.tsx",
  "src/routes/trackers.tsx",
  "src/routes/cycle.tsx",
]) {
  copyFile(rel);
}

/* 3. styles: append the scoped home tokens, then the shared app-shell block */
{
  const p = path.join(repo, "src/styles.css");
  const crlf = isCrlf(p);
  let text = read(p).replace(/\r\n/g, "\n");
  let added = [];
  if (!text.includes(".home-page {")) {
    text = text.replace(/\s*$/, "\n\n") + read(path.join(files, "home-styles.css"));
    added.push("home tokens");
  }
  const shell = read(path.join(files, "app-shell-styles.css"));
  const start = text.indexOf("/* ---------------------------------------------------------------------------\n * App shell —");
  if (start === -1) {
    text = text.replace(/\s*$/, "\n\n") + shell;
    added.push("app-shell + floating button");
  } else if (!text.includes(".app-shell > .app-mobile-bar {")) {
    // v2/v3/v4 block → v5 block (fixed rail, fixed phone bar). The block runs
    // to the end of the file in every kit version, so swap the tail.
    text = text.slice(0, start) + shell;
    added.push("app-shell v5 (replaced the older block)");
  }
  if (added.length === 0) skip("src/styles.css");
  else {
    write(p, text, crlf);
    ok(`appended ${added.join(" and ")} to src/styles.css`);
  }
}

/* 4. hooks: don't touch Supabase when there's no config (keeps / up without .env) */
patch("src/hooks/useMoodSystem.ts", [
  {
    name: "import",
    marker: "hasSupabaseConfig } from \"@/lib/supabase\"",
    from: 'import { supabase } from "@/lib/supabase";',
    to: 'import { supabase, hasSupabaseConfig } from "@/lib/supabase";',
  },
  {
    name: "guard",
    marker: "so Mood entries can't be loaded here",
    from: `  useEffect(() => {
    let alive = true;

    async function start() {
      const {
        data: { session },
      } = await supabase.auth.getSession();
`,
    to: `  useEffect(() => {
    let alive = true;

    if (!hasSupabaseConfig) {
      // No project in this environment: keep the page up with an honest,
      // empty record rather than taking the route down.
      setProfileId(null);
      setEntries([]);
      setLoading(false);
      setAuthError(
        "Bloom isn't connected to a database in this environment, so Mood entries can't be loaded here.",
      );
      return;
    }

    async function start() {
      const {
        data: { session },
      } = await supabase.auth.getSession();
`,
  },
]);

patch("src/hooks/useProfileSpace.ts", [
  {
    name: "import",
    marker: "hasSupabaseConfig } from \"@/lib/supabase\"",
    from: 'import { supabase } from "@/lib/supabase";',
    to: 'import { supabase, hasSupabaseConfig } from "@/lib/supabase";',
  },
  {
    name: "guard",
    marker: `    if (!hasSupabaseConfig) {
      setUserId(null);
      setAuthState("signed-out");
      return;
    }`,
    from: `  useEffect(() => {
    let mounted = true;

    void supabase.auth.getSession().then(({ data }) => {`,
    to: `  useEffect(() => {
    let mounted = true;

    if (!hasSupabaseConfig) {
      setUserId(null);
      setAuthState("signed-out");
      return;
    }

    void supabase.auth.getSession().then(({ data }) => {`,
  },
]);

patch("src/hooks/useCoachSystem.ts", [
  {
    name: "import",
    marker: "hasSupabaseConfig } from \"@/lib/supabase\"",
    from: 'import { supabase } from "@/lib/supabase";',
    to: 'import { supabase, hasSupabaseConfig } from "@/lib/supabase";',
  },
  {
    name: "guard",
    marker: `    if (!hasSupabaseConfig) {
      apply(null);`,
    from: `    const apply = (uid: string | null) => {
      if (!mounted) return;
      setProfileId(uid);
    };
    void supabase.auth.getSession().then(({ data }) => apply(data.session?.user.id ?? null));`,
    to: `    const apply = (uid: string | null) => {
      if (!mounted) return;
      setProfileId(uid);
    };
    if (!hasSupabaseConfig) {
      apply(null);
      return () => {
        mounted = false;
      };
    }
    void supabase.auth.getSession().then(({ data }) => apply(data.session?.user.id ?? null));`,
  },
]);

patch("src/hooks/useRewardsSystem.ts", [
  {
    name: "import",
    marker: "hasSupabaseConfig } from \"@/lib/supabase\"",
    from: 'import { supabase } from "@/lib/supabase";',
    to: 'import { supabase, hasSupabaseConfig } from "@/lib/supabase";',
  },
  {
    name: "guard",
    marker: "so rewards can't be loaded here",
    from: `  const loadUserRewards = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();`,
    to: `  const loadUserRewards = useCallback(async () => {
    setLoading(true);
    setError(null);

    if (!hasSupabaseConfig) {
      // No project in this environment: keep the page up with an honest,
      // empty record rather than taking the route down.
      setUserId(null);
      setRewards([]);
      setError(
        "Bloom isn't connected to a database in this environment, so rewards can't be loaded here.",
      );
      setLoading(false);
      return;
    }

    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();`,
  },
  {
    name: "listener guard",
    marker: `    void loadUserRewards();
    if (!hasSupabaseConfig) return;`,
    from: `  useEffect(() => {
    void loadUserRewards();

    const listener = supabase.auth.onAuthStateChange((_event, session) => {`,
    to: `  useEffect(() => {
    void loadUserRewards();
    if (!hasSupabaseConfig) return;

    const listener = supabase.auth.onAuthStateChange((_event, session) => {`,
  },
]);

/* 4b. the shared sidebar on every main page (AppNav after BloomHeader + app-shell on the wrapper) */
const navImport = {
  name: "AppNav import",
  marker: 'import { AppNav } from "@/components/home/HomeSidebar";',
  from: 'import { BloomHeader } from "@/components/BloomHeader";\n',
  to: 'import { BloomHeader } from "@/components/BloomHeader";\nimport { AppNav } from "@/components/home/HomeSidebar";\n',
};
patch("src/routes/mood.tsx", [
  navImport,
  {
    name: "shell",
    marker: 'className="app-shell relative min-h-screen',
    from: `    <div className="relative min-h-screen bg-background text-foreground">
      <BloomHeader />
      <Atmosphere />

      <main className="relative mx-auto w-full max-w-[1200px] px-5 pb-24 pt-14 sm:px-8 sm:pt-20">`,
    to: `    <div className="app-shell relative min-h-screen bg-background text-foreground">
      <BloomHeader />
      <AppNav />
      <Atmosphere />

      <main className="relative mx-auto w-full max-w-[1200px] px-5 pb-28 pt-14 sm:px-8 sm:pt-20 lg:pb-24">`,
  },
]);
patch("src/components/coach/CoachPage.tsx", [
  navImport,
  {
    name: "shell",
    marker: 'className="coach-page app-shell',
    from: `    <div className="coach-page relative min-h-screen bg-background text-foreground">
      <BloomHeader />
      <div className="coach-atmosphere">
        <Atmosphere />
      </div>

      <main className="relative z-10 mx-auto w-full max-w-[1360px] px-5 pb-20 pt-10 sm:px-8 sm:pt-14">`,
    to: `    <div className="coach-page app-shell relative min-h-screen bg-background text-foreground">
      <BloomHeader />
      <AppNav />
      <div className="coach-atmosphere">
        <Atmosphere />
      </div>

      <main className="relative z-10 mx-auto w-full max-w-[1360px] px-5 pb-24 pt-10 sm:px-8 sm:pt-14 lg:pb-20">`,
  },
]);
patch("src/components/rewards/RewardsPage.tsx", [
  navImport,
  {
    name: "shell",
    marker: 'className="rewards-delivery-page app-shell',
    from: `    <div className="rewards-delivery-page relative min-h-screen bg-background text-foreground">
      <BloomHeader />
      <Atmosphere />`,
    to: `    <div className="rewards-delivery-page app-shell relative min-h-screen bg-background text-foreground">
      <BloomHeader />
      <AppNav />
      <Atmosphere />`,
  },
  {
    name: "main padding",
    marker: 'max-w-[1200px] px-5 pb-28 pt-12 sm:px-8 sm:pt-16 lg:pb-24',
    from: `      <main className="relative mx-auto w-full max-w-[1200px] px-5 pb-24 pt-12 sm:px-8 sm:pt-16">
        <header className="reward-page-header">`,
    to: `      <main className="relative mx-auto w-full max-w-[1200px] px-5 pb-28 pt-12 sm:px-8 sm:pt-16 lg:pb-24">
        <header className="reward-page-header">`,
  },
]);
patch("src/routes/profile.tsx", [
  navImport,
  {
    name: "wrapper",
    marker: 'className="app-shell relative min-h-screen bg-background text-foreground"\n      style={{',
    from: `      className="relative min-h-screen bg-background text-foreground"
      style={{
        ["--profile-accent" as string]: accentVar[accent],`,
    to: `      className="app-shell relative min-h-screen bg-background text-foreground"
      style={{
        ["--profile-accent" as string]: accentVar[accent],`,
  },
  {
    name: "nav + main padding",
    marker: 'max-w-[720px] px-5 pb-28 pt-8 sm:px-8 sm:pt-10 lg:pb-16',
    from: `      <BloomHeader />
      <Atmosphere />

      <main className="relative mx-auto w-full max-w-[720px] px-5 pb-16 pt-8 sm:px-8 sm:pt-10">`,
    to: `      <BloomHeader />
      <AppNav />
      <Atmosphere />

      <main className="relative mx-auto w-full max-w-[720px] px-5 pb-28 pt-8 sm:px-8 sm:pt-10 lg:pb-16">`,
  },
]);

/* 4c. v4: the rail is the only chrome — drop <BloomHeader /> (and its import)
   from every page that renders <AppNav />. Idempotent; leaves pages that never
   had the rail (dashboard, trackers-premium, cycle-classic…) alone. */
for (const rel of [
  "src/routes/mood.tsx",
  "src/routes/profile.tsx",
  "src/components/coach/CoachPage.tsx",
  "src/components/rewards/RewardsPage.tsx",
]) {
  const p = path.join(repo, rel);
  if (!fs.existsSync(p)) {
    fail(`${rel} not found`);
    continue;
  }
  const crlf = isCrlf(p);
  const before = read(p).replace(/\r\n/g, "\n");
  if (!before.includes("<BloomHeader />")) {
    skip(`${rel}: no second header`);
    continue;
  }
  if (!before.includes("<AppNav />")) {
    fail(`${rel}: expected <AppNav /> before removing <BloomHeader />`);
    continue;
  }
  let text = before.replace(/^[ \t]*<BloomHeader \/>[ \t]*\n/m, "");
  text = text.replace(/^import \{ BloomHeader \} from "@\/components\/BloomHeader";\n/m, "");
  write(p, text, crlf);
  ok(`removed the second header from ${rel}`);
}

/* 5. links that meant "Mood Intelligence" when it lived at / */
patch("src/components/rewards/RewardsPage.tsx", [
  {
    name: "back link",
    marker: '<Link to="/mood" className="reward-text-button">',
    from: '<Link to="/" className="reward-text-button">',
    to: '<Link to="/mood" className="reward-text-button">',
    optional: true,
  },
]);
patch("src/components/coach/CoachPage.tsx", [
  {
    name: "sign-in link",
    marker: 'href="/profile"\n                      className="coach-notice-action"',
    from: 'href="/bloom/index.html?return=/coach"',
    to: 'href="/profile"',
    optional: true,
  },
]);
patch("public/bloom/shared-bloom-header.js", [
  { name: "today", marker: '{ label: "Today", href: "/" }', from: '{ label: "Today", href: "index.html" }', to: '{ label: "Today", href: "/" }', optional: true },
  { name: "mood", marker: '{ label: "Mood", href: "/mood" }', from: '{ label: "Mood", href: "/" }', to: '{ label: "Mood", href: "/mood" }', optional: true },
]);

/* 6. verify */
console.log("\nVerify:");
const checks = [
  ["src/routes/index.tsx", 'createFileRoute("/")', "new Today page is the index route"],
  ["src/routes/index.tsx", "useHabits", "Today page wired to habits"],
  ["src/routes/mood.tsx", 'createFileRoute("/mood")', "Mood Intelligence lives at /mood"],
  ["src/components/BloomHeader.tsx", 'to="/mood"', "header Mood \u2192 /mood"],
  ["src/components/BloomHeader.tsx", "todayActive", "header Today \u2192 /"],
  ["src/styles.css", ".home-page {", "home tokens present"],
  ["src/styles.css", ".app-shell {", "app-shell + floating button styles present"],
  ["src/routes/index.tsx", "HabitsSection", "habits section on Today"],
  ["src/routes/index.tsx", "home-fab", "floating add-habit button on Today"],
  ["src/routes/trackers.tsx", "<AppNav />", "sidebar on /trackers"],
  ["src/routes/cycle.tsx", "<AppNav />", "sidebar on /cycle"],
  ["src/routes/mood.tsx", "<AppNav />", "sidebar on /mood"],
  ["src/components/coach/CoachPage.tsx", "<AppNav />", "sidebar on /coach"],
  ["src/components/rewards/RewardsPage.tsx", "<AppNav />", "sidebar on /rewards"],
  ["src/routes/profile.tsx", "<AppNav />", "sidebar on /profile"],
  ["src/hooks/useRewardsSystem.ts", "hasSupabaseConfig", "rewards hook guarded"],
  ["src/hooks/useMoodSystem.ts", "hasSupabaseConfig", "mood hook guarded"],
  ["supabase/migrations/20260906_today_home.sql", "tracker_days", "migration present"],
  ["src/components/tk/AddHabitModal.tsx", 'className="bloom-add-habit"', "v3 Add-habit dialog installed"],
  ["src/styles/add-habit-modal.css", ".bloom-add-habit .modal{", "Add-habit dialog styles installed"],
  ["src/lib/home/habits.ts", "times_per_week", "habit days / weekly target / goal persisted"],
  ["src/styles.css", ".app-sidebar-botanical {", "v4 shell styles (rail from the top)"],
  ["src/styles.css", ".app-shell > .app-mobile-bar {", "v5 shell styles (fixed rail + fixed phone bar)"],
  ["src/components/home/HomeSidebar.tsx", "HomeMobileBar", "v4 rail + phone brand bar"],
  ["src/components/home/HomeSidebar.tsx", "lg:fixed lg:inset-y-0 lg:left-0", "v5 rail (fixed, brand aligned)"],
  ["src/components/home/HomeSidebar.tsx", "h-[60px]", "v5 phone header (60px)"],
];
for (const rel of [
  "src/routes/index.tsx",
  "src/routes/trackers.tsx",
  "src/routes/cycle.tsx",
  "src/routes/mood.tsx",
  "src/routes/profile.tsx",
  "src/components/coach/CoachPage.tsx",
  "src/components/rewards/RewardsPage.tsx",
]) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && !read(p).includes("<BloomHeader />")) ok(`no second header on ${rel}`);
  else fail(`second header still on ${rel}`);
}
for (const [rel, needle, label] of checks) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && read(p).includes(needle)) ok(label);
  else fail(label);
}

console.log(
  process.exitCode
    ? "\nSome steps failed \u2014 see above. Nothing else was changed."
    : `\nDone. Next:
  1. npm run dev  \u2192 open /  (Today: the rail stays put while the page scrolls, Bloom mark in line with the nav icons; habits section, floating Add habit \u2192 the 3-step dialog), then /trackers, /cycle, /mood, /rewards, /coach \u2014 same rail on each. Narrow the window: 60px brand bar on top, tab bar below
  2. Supabase \u2192 SQL editor \u2192 run supabase/migrations/20260906_today_home.sql once
  3. git add -A && git commit -m "feat(shell): fixed rail, aligned brand, taller phone header" && git push
`,
);
