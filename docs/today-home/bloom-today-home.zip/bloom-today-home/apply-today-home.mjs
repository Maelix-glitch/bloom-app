#!/usr/bin/env node
/**
 * Bloom — Today (home) page migration kit
 *
 * Run from anywhere:   node "<path to this folder>\apply-today-home.mjs" [repo path]
 * Defaults to the current working directory as the repo. Idempotent: safe to
 * run twice. Never deletes anything except the old src/routes/index.tsx, which
 * it first moves to src/routes/mood.tsx (Mood Intelligence keeps working at
 * /mood).
 *
 * Requires: the metrics-modal fix already applied (src/components/tk/MetricsEntryModal.tsx exists).
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(process.argv[2] ?? process.cwd());
const files = path.join(here, "files");

const ok = (m) => console.log("  \u2714 " + m);
const skip = (m) => console.log("  \u2022 " + m + " (already done)");
const fail = (m) => {
  console.error("  \u2716 " + m);
  process.exitCode = 1;
};

function read(p) {
  return fs.readFileSync(p, "utf8");
}
function write(p, text, crlf) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, crlf ? text.replace(/\r?\n/g, "\r\n") : text);
}
function isCrlf(p) {
  return fs.existsSync(p) && fs.readFileSync(p).includes("\r\n");
}
function copyFile(rel, { overwrite = true } = {}) {
  const src = path.join(files, rel);
  const dst = path.join(repo, rel);
  if (!fs.existsSync(src)) return fail(`kit is missing ${rel}`);
  if (fs.existsSync(dst) && !overwrite) return skip(rel);
  if (fs.existsSync(dst) && fs.readFileSync(dst).equals(fs.readFileSync(src))) return skip(rel);
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
  ok(`wrote ${rel}`);
}
function patch(rel, edits) {
  const p = path.join(repo, rel);
  if (!fs.existsSync(p)) return fail(`${rel} not found`);
  const crlf = isCrlf(p);
  let text = read(p).replace(/\r\n/g, "\n");
  let changed = 0;
  for (const e of edits) {
    if (e.marker && text.includes(e.marker)) continue;
    if (!text.includes(e.from)) {
      if (e.optional) continue;
      fail(`${rel}: anchor not found for "${e.name}"`);
      continue;
    }
    text = text.replace(e.from, e.to);
    changed++;
  }
  if (changed === 0) return skip(rel);
  write(p, text, crlf);
  ok(`patched ${rel} (${changed} edit${changed === 1 ? "" : "s"})`);
}

console.log(`\nBloom Today-home kit \u2192 ${repo}\n`);

/* 0. sanity */
if (!fs.existsSync(path.join(repo, "package.json")) || !fs.existsSync(path.join(repo, "src/routes"))) {
  console.error("This doesn't look like the Bloom repo (no package.json + src/routes). Pass the repo path as an argument.");
  process.exit(1);
}
if (!fs.existsSync(path.join(repo, "src/components/tk/MetricsEntryModal.tsx"))) {
  console.error("Apply the metrics-modal fix kit first (src/components/tk/MetricsEntryModal.tsx is missing).");
  process.exit(1);
}

/* 1. Mood Intelligence moves from / to /mood */
{
  const idx = path.join(repo, "src/routes/index.tsx");
  const mood = path.join(repo, "src/routes/mood.tsx");
  const current = fs.existsSync(idx) ? read(idx) : "";
  if (fs.existsSync(mood)) {
    skip("src/routes/mood.tsx");
  } else if (current.includes("Mood Intelligence") && current.includes('createFileRoute("/")')) {
    const crlf = current.includes("\r\n");
    write(mood, current.replace(/\r\n/g, "\n").replace('createFileRoute("/")', 'createFileRoute("/mood")'), crlf);
    ok("moved src/routes/index.tsx \u2192 src/routes/mood.tsx (route /mood)");
  } else {
    copyFile("src/routes/mood.tsx");
  }
}

/* 2. new files */
for (const rel of [
  "src/routes/index.tsx",
  "src/components/home/CoachPanel.tsx",
  "src/components/home/ConnectionMap.tsx",
  "src/components/home/HomeSidebar.tsx",
  "src/components/home/ProgressRing.tsx",
  "src/components/home/panels.tsx",
  "src/hooks/useHabits.ts",
  "src/lib/home/habits.ts",
  "src/lib/home/today.ts",
  "src/assets/home/leaf-dark.jpg",
  "src/assets/home/sidebar-botanical.jpg",
  "src/assets/home/window-dusk.jpg",
  "supabase/migrations/20260906_today_home.sql",
  "src/components/BloomHeader.tsx",
]) {
  copyFile(rel);
}

/* 3. styles: append the scoped home tokens */
{
  const p = path.join(repo, "src/styles.css");
  const block = read(path.join(files, "home-styles.css"));
  const text = read(p);
  if (text.includes(".home-page {")) skip("src/styles.css");
  else {
    write(p, text.replace(/\r\n/g, "\n").replace(/\s*$/, "\n\n") + block, isCrlf(p));
    ok("appended home tokens to src/styles.css");
  }
}

/* 4. hooks: don't touch Supabase when there's no config (keeps / up without .env) */
patch("src/hooks/useMoodSystem.ts", [
  {
    name: "import",
    marker: "hasSupabaseConfig } from \"@/lib/supabase\"",
    from: 'import { supabase } from "@/lib/supabase";',
    to: 'import { supabase, hasSupabaseConfig } from "@/lib/supabase";',
  },
  {
    name: "guard",
    marker: "so Mood entries can't be loaded here",
    from: `  useEffect(() => {
    let alive = true;

    async function start() {
      const {
        data: { session },
      } = await supabase.auth.getSession();
`,
    to: `  useEffect(() => {
    let alive = true;

    if (!hasSupabaseConfig) {
      // No project in this environment: keep the page up with an honest,
      // empty record rather than taking the route down.
      setProfileId(null);
      setEntries([]);
      setLoading(false);
      setAuthError(
        "Bloom isn't connected to a database in this environment, so Mood entries can't be loaded here.",
      );
      return;
    }

    async function start() {
      const {
        data: { session },
      } = await supabase.auth.getSession();
`,
  },
]);

patch("src/hooks/useProfileSpace.ts", [
  {
    name: "import",
    marker: "hasSupabaseConfig } from \"@/lib/supabase\"",
    from: 'import { supabase } from "@/lib/supabase";',
    to: 'import { supabase, hasSupabaseConfig } from "@/lib/supabase";',
  },
  {
    name: "guard",
    marker: `    if (!hasSupabaseConfig) {
      setUserId(null);
      setAuthState("signed-out");
      return;
    }`,
    from: `  useEffect(() => {
    let mounted = true;

    void supabase.auth.getSession().then(({ data }) => {`,
    to: `  useEffect(() => {
    let mounted = true;

    if (!hasSupabaseConfig) {
      setUserId(null);
      setAuthState("signed-out");
      return;
    }

    void supabase.auth.getSession().then(({ data }) => {`,
  },
]);

patch("src/hooks/useCoachSystem.ts", [
  {
    name: "import",
    marker: "hasSupabaseConfig } from \"@/lib/supabase\"",
    from: 'import { supabase } from "@/lib/supabase";',
    to: 'import { supabase, hasSupabaseConfig } from "@/lib/supabase";',
  },
  {
    name: "guard",
    marker: `    if (!hasSupabaseConfig) {
      apply(null);`,
    from: `    const apply = (uid: string | null) => {
      if (!mounted) return;
      setProfileId(uid);
    };
    void supabase.auth.getSession().then(({ data }) => apply(data.session?.user.id ?? null));`,
    to: `    const apply = (uid: string | null) => {
      if (!mounted) return;
      setProfileId(uid);
    };
    if (!hasSupabaseConfig) {
      apply(null);
      return () => {
        mounted = false;
      };
    }
    void supabase.auth.getSession().then(({ data }) => apply(data.session?.user.id ?? null));`,
  },
]);

/* 5. links that meant "Mood Intelligence" when it lived at / */
patch("src/components/rewards/RewardsPage.tsx", [
  {
    name: "back link",
    marker: '<Link to="/mood" className="reward-text-button">',
    from: '<Link to="/" className="reward-text-button">',
    to: '<Link to="/mood" className="reward-text-button">',
    optional: true,
  },
]);
patch("src/components/coach/CoachPage.tsx", [
  {
    name: "sign-in link",
    marker: 'href="/profile"\n                      className="coach-notice-action"',
    from: 'href="/bloom/index.html?return=/coach"',
    to: 'href="/profile"',
    optional: true,
  },
]);
patch("public/bloom/shared-bloom-header.js", [
  { name: "today", marker: '{ label: "Today", href: "/" }', from: '{ label: "Today", href: "index.html" }', to: '{ label: "Today", href: "/" }', optional: true },
  { name: "mood", marker: '{ label: "Mood", href: "/mood" }', from: '{ label: "Mood", href: "/" }', to: '{ label: "Mood", href: "/mood" }', optional: true },
]);

/* 6. verify */
console.log("\nVerify:");
const checks = [
  ["src/routes/index.tsx", 'createFileRoute("/")', "new Today page is the index route"],
  ["src/routes/index.tsx", "useHabits", "Today page wired to habits"],
  ["src/routes/mood.tsx", 'createFileRoute("/mood")', "Mood Intelligence lives at /mood"],
  ["src/components/BloomHeader.tsx", 'to="/mood"', "header Mood \u2192 /mood"],
  ["src/components/BloomHeader.tsx", "todayActive", "header Today \u2192 /"],
  ["src/styles.css", ".home-page {", "home tokens present"],
  ["src/hooks/useMoodSystem.ts", "hasSupabaseConfig", "mood hook guarded"],
  ["supabase/migrations/20260906_today_home.sql", "tracker_days", "migration present"],
];
for (const [rel, needle, label] of checks) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && read(p).includes(needle)) ok(label);
  else fail(label);
}

console.log(
  process.exitCode
    ? "\nSome steps failed \u2014 see above. Nothing else was changed."
    : `\nDone. Next:
  1. npm run dev  \u2192 open /  (Today), /mood (Mood Intelligence)
  2. Supabase \u2192 SQL editor \u2192 run supabase/migrations/20260906_today_home.sql once
  3. git add -A && git commit -m "feat(home): Today page from insight-map, wired to Supabase" && git push
`,
);
