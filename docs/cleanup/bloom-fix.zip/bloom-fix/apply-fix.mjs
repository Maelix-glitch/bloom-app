#!/usr/bin/env node
/**
 * Bloom — fix + clean (tip c0a8b79)
 *
 * One run does both:
 *   1. installs 47 new files and updates 32 changed ones
 *   2. deletes the dead weight — the old static HTML site, stale delivery
 *      notes, the _backup snapshot, and the superseded kits in docs/
 *
 * Highlights of what's fixed:
 *   · the coach answers again (it silently refused whenever you were signed
 *     out, which is why pressing send did nothing at all)
 *   · the coach knows ~25 subjects instead of demanding logged data
 *   · saving works, and says so plainly when there's no database configured
 *   · no flicker or lag when switching tabs; the mood photo no longer pinches
 *
 * Safe by default: files you edited yourself are copied to <name>__BEFORE__,
 * deletions are verified first, and re-running is a no-op.
 *
 *   node apply-fix.mjs [path-to-repo]
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(process.argv[2] ?? process.cwd());
const files = path.join(here, "files");

const ok = (m) => console.log("  \u2714 " + m);
const gone = (m) => console.log("  \u2717 " + m);
const skip = (m) => console.log("  \u2022 " + m + " (already done)");
const note = (m) => console.log("  \u2139 " + m);
const fail = (m) => {
  console.error("  \u2716 " + m);
  process.exitCode = 1;
};

const read = (p) => fs.readFileSync(p, "utf8");
const norm = (t) => t.replace(/\r\n/g, "\n");
const isCrlf = (p) => fs.existsSync(p) && fs.readFileSync(p).includes("\r\n");
const md5 = (t) => crypto.createHash("md5").update(norm(t).replace(/\s+$/, "")).digest("hex");
function write(p, text, crlf) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, crlf ? text.replace(/\r?\n/g, "\r\n") : text);
}

const INSTALL = [
  ".env.example",
  ".gitignore",
  "scripts/clean.mjs",
  "src/components/BloomHeader.tsx",
  "src/components/ci/CycleIntelligence.tsx",
  "src/components/ci/CycleNotYours.tsx",
  "src/components/ci/SignatureStrip.tsx",
  "src/components/coach/CoachPage.tsx",
  "src/components/coach/ProviderPicker.tsx",
  "src/components/home/HomeSidebar.tsx",
  "src/components/profile/AccountRow.tsx",
  "src/components/profile/PresetPicker.tsx",
  "src/components/profile/PrivacySheet.tsx",
  "src/components/profile/ProfileAvatar.tsx",
  "src/components/profile/ProfileEditor.tsx",
  "src/components/profile/SignedOutProfile.tsx",
  "src/components/system/ConnectionNotice.tsx",
  "src/components/tk/TrackersPage.tsx",
  "src/components/ui/bloom-sheet.tsx",
  "src/components/welcome/AdminBar.tsx",
  "src/components/welcome/AdminPanel.tsx",
  "src/components/welcome/Welcome.tsx",
  "src/components/welcome/WelcomeGate.tsx",
  "src/hooks/useAmbientSound.ts",
  "src/hooks/useCoachSystem.ts",
  "src/hooks/useCycleMode.ts",
  "src/hooks/useCycleSystem.ts",
  "src/hooks/useCycleVisible.ts",
  "src/hooks/useHabits.ts",
  "src/hooks/useOnboarding.ts",
  "src/hooks/useProfileSpace.ts",
  "src/hooks/useRailIdentity.ts",
  "src/hooks/useSound.ts",
  "src/hooks/useTypewriter.ts",
  "src/lib/coach/breadth.test.ts",
  "src/lib/coach/brevity.test.ts",
  "src/lib/coach/brevity.ts",
  "src/lib/coach/cancel.test.ts",
  "src/lib/coach/compose.ts",
  "src/lib/coach/edge.ts",
  "src/lib/coach/engine.ts",
  "src/lib/coach/knowledge.ts",
  "src/lib/coach/providers.ts",
  "src/lib/coach/responder.ts",
  "src/lib/coach/reveal.test.ts",
  "src/lib/coach/topics.test.ts",
  "src/lib/coach/topics.ts",
  "src/lib/cycle/themes.ts",
  "src/lib/home/today.ts",
  "src/lib/onboarding/adminTargets.test.ts",
  "src/lib/onboarding/adminTargets.ts",
  "src/lib/onboarding/profileKind.test.ts",
  "src/lib/onboarding/profileKind.ts",
  "src/lib/prefsStore.test.ts",
  "src/lib/prefsStore.ts",
  "src/lib/profile/presetAvatars.test.ts",
  "src/lib/profile/presetAvatars.ts",
  "src/lib/sound/sound.test.ts",
  "src/lib/sound/sound.ts",
  "src/lib/supabase.guard.test.ts",
  "src/lib/supabase.ts",
  "src/lib/voice/copy.ts",
  "src/lib/voice/messages.test.ts",
  "src/lib/voice/messages.ts",
  "src/routes/__root.tsx",
  "src/routes/cycle.tsx",
  "src/routes/profile.tsx",
  "src/styles.css",
  "src/styles/admin-panel.css",
  "src/styles/bloom-sheet.css",
  "src/styles/coach.css",
  "src/styles/connection-notice.css",
  "src/styles/cycle2.css",
  "src/styles/mood-motion.css",
  "src/styles/motion.css",
  "src/styles/profile.css",
  "src/styles/welcome.css",
  "supabase/functions/coach/README.md",
  "supabase/functions/coach/index.ts"
];
const KNOWN_BEFORE = {
  ".gitignore": [
    "5c2b910c59c2d0e902da6043966db945"
  ],
  "src/components/BloomHeader.tsx": [
    "82c362644071975810b9f6d9e27f45c5"
  ],
  "src/components/ci/CycleIntelligence.tsx": [
    "861eb0a1ce675b4e8d1c7ca86104331e"
  ],
  "src/components/ci/SignatureStrip.tsx": [
    "855809bf72a4af141a1096838f651aeb"
  ],
  "src/components/coach/CoachPage.tsx": [
    "0b1048b7625808f44151d23fde51a37b"
  ],
  "src/components/home/HomeSidebar.tsx": [
    "69541f3f23ff5f552d8bb43f1fe5a36c"
  ],
  "src/components/profile/AccountRow.tsx": [
    "e77f414e784c7389c4c5b1c86c6fa61c"
  ],
  "src/components/profile/PrivacySheet.tsx": [
    "d67acf04d2ead08e9b4e901857dc1e95"
  ],
  "src/components/profile/ProfileAvatar.tsx": [
    "18fdd40488265a3da7eed88cc781bff4"
  ],
  "src/components/profile/ProfileEditor.tsx": [
    "f97df5bd4dce98acf5dd135b44b68efc"
  ],
  "src/components/profile/SignedOutProfile.tsx": [
    "c89d7cb6bae7ae0a5711e1e2800b7ae8"
  ],
  "src/components/tk/TrackersPage.tsx": [
    "0d26f24302d0bec13d7d10f2e8a4e1ca"
  ],
  "src/components/ui/bloom-sheet.tsx": [
    "da86684d5e214428b87c5060d2a741f1"
  ],
  "src/hooks/useCoachSystem.ts": [
    "30ba87bcccc04905ba8a5810bbf3c934"
  ],
  "src/hooks/useCycleMode.ts": [
    "10f44f0ef879d413d859a29a1ed11543"
  ],
  "src/hooks/useCycleSystem.ts": [
    "6042b5ef4c0ed4846effc36e48210443"
  ],
  "src/hooks/useHabits.ts": [
    "d264051d6bb34cea6ac1ae155de3dc00"
  ],
  "src/hooks/useProfileSpace.ts": [
    "bb908be7b89fafe33aca17dc2bdb1ad9"
  ],
  "src/hooks/useRailIdentity.ts": [
    "17e9f57bbd9f852b859719ef55ac9f5d"
  ],
  "src/lib/coach/responder.ts": [
    "66e9fcb99c77e260169f229cc6d72fc3"
  ],
  "src/lib/cycle/themes.ts": [
    "d722f94b77d667b1894af275954caba4"
  ],
  "src/lib/home/today.ts": [
    "7e9c9a65e23ee916d2f2a9765eb74cc4"
  ],
  "src/lib/supabase.ts": [
    "abbab47652f79ed8cf4d4d8ca0359df8"
  ],
  "src/routes/__root.tsx": [
    "c03a400cf12d48437147f07da5dbc81d"
  ],
  "src/routes/cycle.tsx": [
    "abddcde51d8ba996b80d788e9d5c4281"
  ],
  "src/routes/profile.tsx": [
    "2a2fd5499d93dcf30015e16e9c35f0a7"
  ],
  "src/styles.css": [
    "1ecb3e4b5699c6e8525321ca0ab92872"
  ],
  "src/styles/bloom-sheet.css": [
    "199b96677969872807b639028256745e"
  ],
  "src/styles/coach.css": [
    "e4c46abeea8c5f9c0968f1b0a3dff42d"
  ],
  "src/styles/cycle2.css": [
    "f9907c3359ab136f31952e4e91decc2c"
  ],
  "src/styles/mood-motion.css": [
    "2b95e8fbe469da7d7a7d104818dd610f"
  ],
  "src/styles/profile.css": [
    "32dfdd2b988c0267133f876c96a4dfd9"
  ]
};
const DELETE_FILES = [
  "COMPLETE_DELIVERY.md",
  "FINAL_TESTING.md",
  "IMPLEMENTATION_CHECKLIST.md",
  "PROJECT_COMPLETE.md",
  "QUICK_START.md",
  "README_TRACKERS.md",
  "TRACKERS_FIX_SUMMARY.md",
  "WORK_COMPLETED.md",
  "public/bloom/README.md",
  "public/bloom/SETUP_SUPABASE.md",
  "public/bloom/bloom-add-habit-modal-v3.html",
  "public/bloom/capacitor.config.json",
  "public/bloom/coach.html",
  "public/bloom/cycle.html",
  "public/bloom/dashboard.html",
  "public/bloom/fix-nav.js",
  "public/bloom/index.html",
  "public/bloom/manifest.json",
  "public/bloom/mood.html",
  "public/bloom/rewards.html",
  "public/bloom/service-worker.js",
  "public/bloom/shared-bloom-header.js",
  "public/bloom/trackers.html",
  "public/demo/seed.html"
];
const DELETE_DIRS = [
  "src/_backup-trackers-20260904-162359",
  "public/bloom/js",
  "public/bloom/css",
  "docs/today-home",
  "docs/add-habit-modal",
  "docs/mood-page",
  "docs/metrics-modal-issue",
  "docs/cycle-loopholes",
  "docs/mood-fixes",
  "docs/tier-a",
  "docs/tier-b-c",
  "docs/tier-b2",
  "docs/audit"
];
const PROTECTED = [
  [
    "public/bloom/icons",
    "PWA + notification icons"
  ],
  [
    "public/bloom/bloom-add-habit-modal-v3-latest.html",
    "reference for the React AddHabitModal"
  ],
  [
    "public/rewards/medals",
    "rewards admin medal images"
  ],
  [
    "public/manifest.webmanifest",
    "the app manifest"
  ],
  [
    "public/sw.js",
    "the service worker"
  ]
];
const PREREQS = [
  [
    "src/lib/prefs.ts",
    "export function setPref",
    "synced prefs"
  ],
  [
    "src/lib/cycle/periodStore.ts",
    "export function effectiveMode",
    "cycle mode"
  ],
  [
    "src/components/ui/bloom-sheet.tsx",
    "BloomSheet",
    "premium sheets"
  ],
  [
    "src/lib/coach/responder.ts",
    "export function answer",
    "coach responder"
  ]
];
const CHECKS = [
  [
    "src/components/coach/CoachPage.tsx",
    "No sign-in gate",
    "Coach answers when signed out"
  ],
  [
    "src/lib/coach/knowledge.ts",
    "export const KNOWLEDGE",
    "Coach knowledge base"
  ],
  [
    "src/lib/coach/compose.ts",
    "export function compose",
    "Coach answer composer"
  ],
  [
    "src/lib/coach/engine.ts",
    "CoachCancelled",
    "Coach cancellation fix"
  ],
  [
    "src/hooks/useCoachSystem.ts",
    "inFlight.current = null",
    "Coach controller released"
  ],
  [
    "src/lib/supabase.ts",
    "export function watchAuth",
    "Safe auth subscription"
  ],
  [
    "src/hooks/useHabits.ts",
    "watchAuth",
    "Habits load without crashing"
  ],
  [
    "src/components/system/ConnectionNotice.tsx",
    "Saving to this device only",
    "Offline notice"
  ],
  [
    "src/lib/onboarding/adminTargets.ts",
    "ADMIN_TARGETS",
    "Admin launcher"
  ],
  [
    "src/styles/mood-motion.css",
    "scale(1.06)",
    "Mood image pinch fix"
  ],
  [
    "src/lib/prefsStore.ts",
    "useSyncExternalStore",
    "Tab-flicker fix"
  ],
  [
    ".env.example",
    "VITE_SUPABASE_URL",
    "Env template"
  ]
];

console.log(`\nBloom \u2014 fix + clean \u2192 ${repo}\n`);

if (!fs.existsSync(path.join(repo, "package.json")) || !fs.existsSync(path.join(repo, "src/routes"))) {
  console.error("This doesn't look like the Bloom repo (no package.json + src/routes). Pass the repo path as an argument.");
  process.exit(1);
}

/* 1. prerequisites */
console.log("Checking your checkout:");
let missing = 0;
for (const [rel, needle, label] of PREREQS) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && norm(read(p)).includes(needle)) ok(label);
  else {
    console.error(`  \u2716 missing: ${label}  (${rel})`);
    missing += 1;
  }
}
if (missing) {
  console.error(`\n${missing} thing(s) from an earlier kit are missing. Nothing has been written.`);
  process.exit(1);
}

/*
 * 2. Protect what's load-bearing.
 *
 * Several deletions sit right beside files the app needs — public/bloom/icons
 * is the PWA icon set, public/rewards/medals is used by the rewards admin. If
 * one of those is already gone, this tree isn't what the kit expects and
 * deleting more would make it worse.
 */
for (const [rel, why] of PROTECTED) {
  if (!fs.existsSync(path.join(repo, rel))) {
    console.error(`\n\u2716 ${rel} is missing (${why}).`);
    console.error("  This repo isn't in the state this kit expects. Nothing has been written.");
    process.exit(1);
  }
}

/* 3. install */
console.log("\nUpdate:");
let wrote = 0;
for (const rel of INSTALL) {
  const src = path.join(files, rel);
  const dst = path.join(repo, rel);
  if (!fs.existsSync(src)) {
    fail(`kit is missing ${rel}`);
    continue;
  }
  const next = read(src);
  if (!fs.existsSync(dst)) {
    write(dst, next, false);
    ok(`added ${rel}`);
    wrote += 1;
    continue;
  }
  const cur = read(dst);
  if (md5(cur) === md5(next)) {
    skip(rel);
    continue;
  }
  const known = KNOWN_BEFORE[rel] ?? [];
  if (!known.includes(md5(cur))) {
    fs.copyFileSync(dst, dst + "__BEFORE__");
    note(`${rel} had local edits \u2014 your copy is kept as ${path.basename(dst)}__BEFORE__`);
  }
  write(dst, next, isCrlf(dst));
  ok(`updated ${rel}`);
  wrote += 1;
}

/* 4. clean */
console.log("\nRemove:");
let removed = 0;
let freed = 0;
const sizeOf = (p) => {
  let total = 0;
  const walk = (q) => {
    const st = fs.statSync(q);
    if (st.isDirectory()) for (const n of fs.readdirSync(q)) walk(path.join(q, n));
    else total += st.size;
  };
  try {
    walk(p);
  } catch {
    return 0;
  }
  return total;
};

for (const rel of [...DELETE_DIRS, ...DELETE_FILES]) {
  const p = path.join(repo, rel);
  if (!fs.existsSync(p)) continue;
  freed += sizeOf(p);
  fs.rmSync(p, { recursive: true, force: true });
  gone(rel);
  removed += 1;
}
if (removed === 0) console.log("  (nothing to remove \u2014 already clean)");

/* prune any empty directories the removals left behind */
const prune = (dir) => {
  if (!fs.existsSync(dir)) return;
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name);
    if (fs.statSync(full).isDirectory()) prune(full);
  }
  if (fs.readdirSync(dir).length === 0 && dir !== repo) fs.rmdirSync(dir);
};
for (const d of ["docs", "public/bloom", "public/demo", "src"]) prune(path.join(repo, d));

/* 5. verify */
console.log("\nVerify:");
for (const [rel, needle, label] of CHECKS) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && norm(read(p)).includes(needle)) ok(label);
  else fail(`${label} \u2014 check ${rel}`);
}

const mb = (n) => (n > 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : `${Math.round(n / 1024)} KB`);

if (process.exitCode) {
  console.log("\nSomething was skipped \u2014 see the \u2716 lines above. Send me this whole output.");
} else {
  console.log(`
Done. ${wrote} file(s) updated, ${removed} item(s) removed (${mb(freed)} freed).

Next:
  1. Stop the dev server, then: npm run dev
  2. Open the URL it prints \u2014 it is localhost:5173, NOT 8080.
     (8080 was the old static site; this kit deletes it.)
  3. Hard-refresh once (Ctrl+F5)
  4. Optional: npx vitest run   \u2014 385 tests

  Then try the coach. It answers signed out now; that gate was the bug.

  Commit it:
    git add -A
    git commit -m "fix: coach, saving, and repo cleanup"

  Undo everything:  git checkout -- .
`);
}
