# Bloom — metrics entry modal fix kit

Makes `/trackers` render **your** modal from `lovable-data-entry` instead of
the faded AI rewrite. See `screenshots/` for before / after.

```
bloom-metrics-modal-fix/
├── apply-fix.mjs              ← run this (deletes + adds + updates for you)
├── README.md                  ← this file (also has the manual steps)
├── bloom-metrics-modal.patch  ← alternative: git apply
├── files/                     ← complete copies of every file that changes
│   └── src/
│       ├── styles.css
│       └── components/tk/
│           ├── MetricsEntryModal.tsx        (NEW)
│           └── designs/Atlas.tsx · Ledger.tsx · Strip.tsx
└── screenshots/  BEFORE-faded.png · AFTER-fixed.png · AFTER-saved.png
```

---

## Option A — automatic (recommended)

1. Unzip anywhere (e.g. on your Desktop).
2. Open **your `bloom-app` repo** in VS Code → `Terminal → New Terminal`.
3. Run:

   ```bash
   node "<path-to-unzipped-folder>/apply-fix.mjs"
   ```

   Windows example:
   ```powershell
   node "C:\Users\you\Desktop\bloom-metrics-modal-fix\apply-fix.mjs"
   ```
   Mac example:
   ```bash
   node ~/Desktop/bloom-metrics-modal-fix/apply-fix.mjs
   ```

   Want to see what it would do first? Add `--dry-run`.
   Not in the repo folder? Pass the repo path: `node …/apply-fix.mjs C:\path\to\bloom-app`.

4. It prints every delete / add / update, verifies, and tells you the next
   commands (`npm run dev` → check `/trackers`, then `git add -A && git commit && git push`).

Safe to run twice — it skips anything already done and refuses to touch a
file it can't match exactly.

---

## Option B — git patch

From the repo root, on a clean working tree:

```bash
git apply --3way "<path>/bloom-metrics-modal-fix/bloom-metrics-modal.patch"
```

---

## Option C — by hand in VS Code

### 🗑️ DELETE these (right-click → Delete in the Explorer)

| Path | Why |
|---|---|
| `src/components/tk/MetricsModal.tsx` | the faded rewrite that was rendering |
| `src/components/tk/designs/MetricsEntryModal.tsx` | unused 3rd copy, 10 TS errors |
| `src/components/lovable/` **(whole folder)** | `metrics-entry-modal.tsx` moves out (below); `ui/` is a duplicate of `components/ui` |
| `src/styles/lovable-styles.css` | never imported |
| `src/hooks/lovable-use-mobile.tsx` | duplicate of `hooks/use-mobile.tsx` |
| `src/lib/lovable-utils.ts` | duplicate of `lib/utils.ts` |
| `src/lib/lovable-error-capture.ts` | duplicate of `lib/error-capture.ts` |

⚠️ Do **not** delete `src/lib/lovable-error-reporting.ts` — `routes/__root.tsx` uses it.

### ➕ ADD this

Copy `files/src/components/tk/MetricsEntryModal.tsx` → `src/components/tk/MetricsEntryModal.tsx`

### ✏️ UPDATE these — easiest is to copy the whole file from `files/`

| Your file | Change |
|---|---|
| `src/components/tk/designs/Atlas.tsx` | import line + JSX tag (see below) |
| `src/components/tk/designs/Ledger.tsx` | same |
| `src/components/tk/designs/Strip.tsx` | same |
| `src/styles.css` | 11 lines in `@theme inline`, 11 lines in `:root` (see below) |

**Atlas / Ledger / Strip** — two edits each (Ctrl+H find & replace works):

```diff
- import { MetricsModal } from "@/components/tk/MetricsModal";
+ import { MetricsEntryModal } from "@/components/tk/MetricsEntryModal";

- <MetricsModal store={store} open={…} onClose={…} />
+ <MetricsEntryModal store={store} open={…} onClose={…} />
```

**styles.css** — inside `@theme inline { … }`, after `--color-rose: var(--rose);` add:

```css
  --color-metric-sleep: var(--metric-sleep);
  --color-metric-water: var(--metric-water);
  --color-metric-study: var(--metric-study);
  --color-metric-movement: var(--metric-movement);
  --color-metric-energy: var(--metric-energy);
  --color-metric-screen: var(--metric-screen);
  --color-metric-surface: var(--metric-surface);
  --color-metric-surface-raised: var(--metric-surface-raised);
  --color-brand: var(--brand);
  --color-success: var(--success);
  --color-danger: var(--danger);
```

and inside `:root { … }`, after `--dim-rose: …;` add:

```css
  --metric-sleep: oklch(0.62 0.22 290);
  --metric-water: oklch(0.72 0.14 220);
  --metric-study: oklch(0.75 0.17 155);
  --metric-movement: oklch(0.72 0.19 55);
  --metric-energy: oklch(0.85 0.17 95);
  --metric-screen: oklch(0.62 0.25 355);
  --metric-surface: oklch(0.13 0.02 275);
  --metric-surface-raised: oklch(0.17 0.02 275);
  --brand: oklch(0.6 0.28 320);
  --success: oklch(0.75 0.19 165);
  --danger: oklch(0.65 0.24 20);
```

---

## What's different from your lovable-data-entry file?

JSX, classes, colours and the form → saved / reset flow are **unchanged**.
Only the data layer was adapted to Bloom:

- takes a `store` prop; opens pre-filled with today's values
- saves all six through `setTrackerValues` (one write)
- hours ↔ minutes for sleep / study / screen; energy on Bloom's **1–5** scale
- validation ranges come from `trackerDef(id).min/max`
- `var(--surface)` / `var(--surface-raised)` → `var(--metric-surface)` /
  `var(--metric-surface-raised)` (Bloom already uses `--surface` for cards)
- portalled to `<body>` at `z-[2000]`

One thing to decide: the reference **requires all six fields**. If you want to
allow partial entries, in `MetricsEntryModal.tsx` → `handleConfirm` remove the
`if (!allFilled) return;` line and only write the filled entries.

---

## Verify

```bash
npm run dev
```
Open `/trackers` → click **LOG METRICS TODAY** (or **REFLECT & LOG TODAY** on
Atlas). You should see the pink→violet header and coloured underlines
(`screenshots/AFTER-fixed.png`). Type `7.5` in Sleep, fill the rest, Confirm →
"Saved!" → View My Day → the Sleep row reads `7h 30m`.
