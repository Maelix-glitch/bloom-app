#!/usr/bin/env node
/**
 * Bloom — metrics entry modal fix
 * ================================
 * Deletes the broken/duplicate files, adds the real modal, and patches the
 * three designs + styles.css. Plain Node, no dependencies.
 *
 *   node apply-fix.mjs            → apply
 *   node apply-fix.mjs --dry-run  → only print what WOULD happen
 *
 * Run it from anywhere; point it at your repo with the first argument if the
 * repo isn't the current folder:
 *
 *   node apply-fix.mjs C:\Users\you\bloom-app
 *
 * Safe to run twice — every step checks before it acts.
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const KIT = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const DRY = args.includes("--dry-run");
const REPO = path.resolve(args.find((a) => !a.startsWith("--")) ?? process.cwd());

const c = {
  g: (s) => `\x1b[32m${s}\x1b[0m`,
  y: (s) => `\x1b[33m${s}\x1b[0m`,
  r: (s) => `\x1b[31m${s}\x1b[0m`,
  d: (s) => `\x1b[2m${s}\x1b[0m`,
  b: (s) => `\x1b[1m${s}\x1b[0m`,
};
const log = (icon, msg) => console.log(`  ${icon}  ${msg}`);
const rel = (p) => path.relative(REPO, p).split(path.sep).join("/");
const inRepo = (...p) => path.join(REPO, ...p);
const inKit = (...p) => path.join(KIT, "files", ...p);

let changed = 0;
let skipped = 0;
let failed = 0;

// ─── sanity: is this really the bloom-app repo? ─────────────────────────────
console.log(`\n${c.b("Bloom metrics modal fix")}${DRY ? c.y("  (dry run — nothing will be written)") : ""}`);
console.log(`${c.d("repo:")} ${REPO}\n`);

const mustExist = ["package.json", "src/components/tk/designs/shared.tsx", "src/lib/trackers/core.ts", "src/styles.css"];
for (const f of mustExist) {
  if (!fs.existsSync(inRepo(f))) {
    console.log(c.r(`✖ ${f} not found — this doesn't look like the bloom-app repo.`));
    console.log(c.d(`  Run from the repo root, or pass the path: node apply-fix.mjs <path-to-bloom-app>\n`));
    process.exit(1);
  }
}

// ─── 1. DELETE ──────────────────────────────────────────────────────────────
console.log(c.b("1. Delete dead / broken files"));

const DELETE = [
  ["src/components/tk/MetricsModal.tsx", "the faded AI rewrite that was rendering"],
  ["src/components/tk/designs/MetricsEntryModal.tsx", "unused 3rd copy, 10 TS errors"],
  ["src/components/lovable/metrics-entry-modal.tsx", "moved to tk/MetricsEntryModal.tsx (step 2)"],
  ["src/components/lovable/ui", "duplicate of components/ui (47 files)"],
  ["src/components/lovable", "folder, empty after the above"],
  ["src/styles/lovable-styles.css", "never imported; tokens now live in styles.css"],
  ["src/hooks/lovable-use-mobile.tsx", "duplicate of hooks/use-mobile.tsx"],
  ["src/lib/lovable-utils.ts", "duplicate of lib/utils.ts"],
  ["src/lib/lovable-error-capture.ts", "duplicate of lib/error-capture.ts"],
];

for (const [p, why] of DELETE) {
  const abs = inRepo(p);
  if (!fs.existsSync(abs)) {
    log(c.d("·"), `${c.d(p)} ${c.d("— already gone")}`);
    skipped++;
    continue;
  }
  const isDir = fs.statSync(abs).isDirectory();
  if (isDir && p === "src/components/lovable") {
    // Only remove the folder if nothing but the files handled above is in it.
    const handledAbove = new Set(["metrics-entry-modal.tsx", "ui"]);
    const leftovers = fs.readdirSync(abs).filter((n) => !handledAbove.has(n));
    if (leftovers.length > 0) {
      log(c.y("!"), `${p} has files I don't know about — left alone: ${leftovers.join(", ")}`);
      skipped++;
      continue;
    }
  }
  if (!DRY) fs.rmSync(abs, { recursive: true, force: true });
  log(c.r("−"), `${p}  ${c.d("— " + why)}`);
  changed++;
}

// ─── 2. ADD ─────────────────────────────────────────────────────────────────
console.log(`\n${c.b("2. Add the real modal")}`);

const ADD = [["src/components/tk/MetricsEntryModal.tsx", "your lovable-data-entry modal + Bloom data layer"]];

for (const [p, why] of ADD) {
  const src = inKit(p);
  const dst = inRepo(p);
  const next = fs.readFileSync(src, "utf8");
  if (fs.existsSync(dst) && fs.readFileSync(dst, "utf8") === next) {
    log(c.d("·"), `${c.d(p)} ${c.d("— already identical")}`);
    skipped++;
    continue;
  }
  if (!DRY) {
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.writeFileSync(dst, next);
  }
  log(c.g("+"), `${p}  ${c.d("— " + why)}`);
  changed++;
}

// ─── 3. UPDATE (targeted text edits, verified before writing) ───────────────
console.log(`\n${c.b("3. Update existing files")}`);

/** Replace `from` with `to` in a file exactly `expect` times; refuse otherwise. */
function edit(p, edits) {
  const abs = inRepo(p);
  if (!fs.existsSync(abs)) {
    log(c.r("✖"), `${p} — missing, cannot update`);
    failed++;
    return;
  }
  let text = fs.readFileSync(abs, "utf8");
  const eol = text.includes("\r\n") ? "\r\n" : "\n";
  const original = text;
  const notes = [];

  for (const { from, to, label, marker } of edits) {
    const f = from.replace(/\n/g, eol);
    const t = to.replace(/\n/g, eol);
    // "Already done" = the replacement's unique marker is present. (For pure
    // insertions the anchor text survives, so we can't rely on `from` being gone.)
    const already = text.includes((marker ?? to).replace(/\n/g, eol));
    if (already) {
      notes.push(c.d(`${label}: already done`));
      continue;
    }
    const count = text.split(f).length - 1;
    if (count !== 1) {
      log(c.r("✖"), `${p} — expected to find "${label}" exactly once, found ${count}. File left untouched.`);
      log(" ", c.d(`   Fall back to copying files/${p} from this kit over yours, or apply bloom-metrics-modal.patch.`));
      failed++;
      return;
    }
    text = text.replace(f, t);
    notes.push(c.g(label));
  }

  if (text === original) {
    log(c.d("·"), `${c.d(p)} ${c.d("— already up to date")}`);
    skipped++;
    return;
  }
  if (!DRY) fs.writeFileSync(abs, text);
  log(c.y("~"), `${p}  ${c.d("—")} ${notes.join(c.d(", "))}`);
  changed++;
}

// 3a. the three designs: swap the import and the JSX tag
for (const design of ["Atlas", "Ledger", "Strip"]) {
  edit(`src/components/tk/designs/${design}.tsx`, [
    {
      label: "import",
      from: 'import { MetricsModal } from "@/components/tk/MetricsModal";',
      to: 'import { MetricsEntryModal } from "@/components/tk/MetricsEntryModal";',
    },
    {
      label: "JSX tag",
      from: "<MetricsModal store=",
      to: "<MetricsEntryModal store=",
    },
  ]);
}

// 3b. styles.css: register the tokens (Tailwind utilities) and define them on :root
edit("src/styles.css", [
  {
    label: "@theme tokens",
    marker: "--color-metric-sleep: var(--metric-sleep);",
    from: `  --color-rose: var(--rose);
`,
    to: `  --color-rose: var(--rose);

  /* Metrics entry modal tokens → bg-metric-sleep, text-brand, border-danger… */
  --color-metric-sleep: var(--metric-sleep);
  --color-metric-water: var(--metric-water);
  --color-metric-study: var(--metric-study);
  --color-metric-movement: var(--metric-movement);
  --color-metric-energy: var(--metric-energy);
  --color-metric-screen: var(--metric-screen);
  --color-metric-surface: var(--metric-surface);
  --color-metric-surface-raised: var(--metric-surface-raised);
  --color-brand: var(--brand);
  --color-success: var(--success);
  --color-danger: var(--danger);
`,
  },
  {
    label: ":root values",
    marker: "--metric-sleep: oklch(0.62 0.22 290);",
    from: `  --dim-rose: color-mix(in oklab, var(--rose) 14%, transparent);
}`,
    to: `  --dim-rose: color-mix(in oklab, var(--rose) 14%, transparent);

  /*
   * Metrics entry modal ("Today's snapshot") — ported from lovable-data-entry.
   * Defined on :root because the modal is portalled to <body>, outside any
   * page-scoped token set. Bloom already owns --surface, so the modal's two
   * surfaces are namespaced as --metric-surface / --metric-surface-raised.
   */
  --metric-sleep: oklch(0.62 0.22 290);
  --metric-water: oklch(0.72 0.14 220);
  --metric-study: oklch(0.75 0.17 155);
  --metric-movement: oklch(0.72 0.19 55);
  --metric-energy: oklch(0.85 0.17 95);
  --metric-screen: oklch(0.62 0.25 355);
  --metric-surface: oklch(0.13 0.02 275);
  --metric-surface-raised: oklch(0.17 0.02 275);
  --brand: oklch(0.6 0.28 320);
  --success: oklch(0.75 0.19 165);
  --danger: oklch(0.65 0.24 20);
}`,
  },
]);

// ─── 4. VERIFY ──────────────────────────────────────────────────────────────
console.log(`\n${c.b("4. Verify")}`);

const checks = [
  ["new modal exists", () => fs.existsSync(inRepo("src/components/tk/MetricsEntryModal.tsx"))],
  ["old MetricsModal.tsx gone", () => !fs.existsSync(inRepo("src/components/tk/MetricsModal.tsx"))],
  ["no file still imports tk/MetricsModal", () => {
    const hits = [];
    const walk = (d) => {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const p = path.join(d, e.name);
        if (e.isDirectory()) walk(p);
        else if (/\.(tsx?|css)$/.test(e.name) && fs.readFileSync(p, "utf8").includes('"@/components/tk/MetricsModal"')) hits.push(rel(p));
      }
    };
    walk(inRepo("src"));
    if (hits.length) console.log(c.d(`      still importing old modal: ${hits.join(", ")}`));
    return hits.length === 0;
  }],
  ["styles.css defines --metric-sleep", () => fs.readFileSync(inRepo("src/styles.css"), "utf8").includes("--metric-sleep: oklch(")],
  ["Atlas/Ledger/Strip use MetricsEntryModal", () =>
    ["Atlas", "Ledger", "Strip"].every((d) => fs.readFileSync(inRepo(`src/components/tk/designs/${d}.tsx`), "utf8").includes("<MetricsEntryModal store="))],
];

let allOk = true;
for (const [label, fn] of checks) {
  let ok = false;
  try { ok = fn(); } catch { ok = false; }
  if (DRY && !ok) { log(c.d("·"), `${c.d(label)} ${c.d("(dry run)")}`); continue; }
  log(ok ? c.g("✔") : c.r("✖"), label);
  if (!ok) allOk = false;
}

// ─── summary ────────────────────────────────────────────────────────────────
console.log(`\n${c.b("Done.")} ${changed} changed, ${skipped} already ok, ${failed} failed.${DRY ? c.y("  (dry run)") : ""}`);
if (!DRY && allOk && failed === 0) {
  console.log(`
${c.g("Next, in the VS Code terminal:")}
  npm install               ${c.d("(only if you haven't yet)")}
  npm run dev               ${c.d("→ open /trackers → click the pink button")}

${c.g("Then commit:")}
  git add -A
  git commit -m "fix(trackers): use the real metrics entry modal"
  git push
`);
} else if (failed > 0) {
  console.log(c.y(`
Some edits didn't apply (see ✖ above). Easiest fallback — copy these from the
kit's files/ folder over the same paths in your repo, they are complete files:
  files/src/styles.css
  files/src/components/tk/designs/Atlas.tsx
  files/src/components/tk/designs/Ledger.tsx
  files/src/components/tk/designs/Strip.tsx
`));
  process.exit(1);
}
