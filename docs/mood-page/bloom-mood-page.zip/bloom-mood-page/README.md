# Bloom — Mood page kit (v2)

A separate kit, on top of the Today-home kit you already applied. It does not
touch the home page. v2 is safe over a tree that already has v1 (it only adds
the new parts) and over a tree that never had it.

## New in v2

- **Full width.** `/mood` and `/mood/intelligence` now run edge to edge with
  the same margins as Today — no more narrow centred column with empty space
  either side.
- **No flicker.** Your mood entries are loaded once and shared by every page.
  Moving between `/`, `/mood` and `/mood/intelligence` no longer shows the
  "Reading your record…" spinner or re-draws the page.
- **Less lag.** The background layer is lighter (8 motes, no blurred fields, the
  spotlight settles instead of running forever) and was removed from
  `/mood/intelligence` where it was invisible anyway; panels no longer run idle
  shimmer animations; the Intelligence panels only re-render when their own
  data changes; the trajectory chart drops the per-frame canvas blur. Range
  switches went from ~370 ms of work to ~30 ms in a headless profile.
- **Faster click-through.** Route code is fetched when you hover a link, so
  `/mood → /mood/intelligence` is ready before you click.
- **Your mood web.** A new section on `/mood`, under the journey: Mood in the
  centre, the signals you log (energy, stress, sleep, exercise, screen time…) on
  an inner ring and the emotions you name on an outer ring. Line weight and
  colour are the real correlation on your paired days (gold lifts, rose lowers,
  dashed = not enough days yet); particles flow along the strongest links.
  Hover a node to read it, click or tap to pin, Escape to release. "Open in
  Intelligence" deep-links to the Relationships section. It has an honest empty
  state until you have a few days logged.

## What v1 installed (unchanged)

1. **The Mood page from the harmonious-dashboard model at `/mood`** — hero window
   ("Today you feel *calm*, Name" once you've logged; "How are you feeling
   today?" before), **Log your mood** with the six faces (a tap is a real
   check-in saved to your mood record; tapping another face today replaces it;
   "Log an entry" opens the full composer), **Your mood journey** (last seven
   logged days, period pill 7 / 30 / 90 days, "A small insight"), **Mood
   distribution** (ring + legend), **Quick insights** (only patterns your
   entries actually support), **Streak & consistency**, and the closing banner.
   Each section is its own card, one below another, with room to breathe.
   Nothing is hardcoded — every number comes from your entries, and every
   section has an honest empty state until you have logged.
2. **Mood Intelligence moves to `/mood/intelligence`**, unchanged (heatmap,
   calendar, correlations, patterns, history). Reached from "See all",
   "Explore your insights", the Rewards back-link, and a small "← Mood" link at
   its top.
3. **The avatar block at the foot of the sidebar** (from the model): settings
   glyph · your photo (or accent-tinted initials) · your name · your bio line,
   on every main page. It refreshes the moment you change your photo or name on
   Profile. Signed out it reads "Sign in — Sync across your devices". On short
   windows the quote hides so nothing collides.
4. The model's six photos live on Lovable's private CDN and can't be fetched,
   so they were recreated to the model's own image descriptions. To use the
   originals, overwrite `src/assets/mood/*.jpg` (same filenames) — nothing else
   changes.

Requires the Today-home kit (any version from v2 on — you have v4 or v5).
Safe to run twice: it only adds what is missing.

## Apply (Windows, PowerShell or cmd)

```
cd "C:\Users\Windows 11 Pro\Documents\trae_projects\bloom-app\chronos-feel"
node "C:\Users\Windows 11 Pro\OneDrive\Desktop\bloom-mood-page\bloom-mood-page\apply-mood-page.mjs"
```

(Windows' unzip usually double-nests the folder, hence `bloom-mood-page\bloom-mood-page\`.
If you extracted it somewhere else, point the second path at wherever
`apply-mood-page.mjs` landed.)

Expected: a list of `✔ wrote …` / `✔ patched …` lines (if you never applied v1
you will also see `✔ moved src/routes/mood.tsx → src/routes/mood/intelligence.tsx`
— the old file disappearing is intended), then `Verify:` with every line `✔`,
then `Done.` Lines marked `•` mean that part was already in place.
If anything prints `✖`, send me the output.

## Then

- `npm run dev` → `/mood`. It should fill the width like Today, with "Your mood
  web" under the journey. Move between `/`, `/mood` and `/mood/intelligence` —
  no spinner, no flash. Hard-refresh (Ctrl+F5) once if the old layout lingers.
  The dev server regenerates `src/routeTree.gen.ts` on first start — commit that
  file too.
- `git add -A && git commit -m "feat(mood): full-width mood pages, shared record, mood web" && git push`

## What it changes, exactly

v2 on top of v1:

- Adds `src/lib/mood/record.ts`, `src/lib/mood/graph.ts` + `graph.test.ts`,
  `src/components/mood/page/MoodGraph.tsx`.
- Replaces (kit-owned or untouched-upstream files, byte-compared):
  `src/hooks/useMoodSystem.ts`, `src/components/mood/primitives.tsx`,
  `Atmosphere.tsx`, `MoodChart.tsx`, `History.tsx`, `Calendar.tsx`,
  `Correlations.tsx`, `Heatmap.tsx`, `Timeline.tsx`, `Distribution.tsx`,
  `Insights.tsx`, `Emotions.tsx`, `Patterns.tsx`,
  `src/components/mood/page/MoodPage.tsx`, `src/routes/mood/intelligence.tsx`.
- One marker-guarded edit in `src/router.tsx` (`defaultPreload: "intent"`).
- `src/styles.css`: the `.mood-reveal` rule (before `@utility sheen-band`) and
  the scoped "Mood web" block (before the App shell block). CRLF preserved.

v1 (still performed when missing):

- Moves `src/routes/mood.tsx` → `src/routes/mood/intelligence.tsx` (route id +
  the "← Mood" link; nothing else in the file).
- Adds `src/routes/mood/index.tsx`, `src/components/mood/page/*` (4 files),
  `src/lib/mood/page.ts` + `page.test.ts`, `src/hooks/useRailIdentity.ts`,
  `src/assets/mood/*.jpg` (6 images).
- Replaces `src/components/home/HomeSidebar.tsx` (the kit's own file, now with
  the identity row).
- Five one-line, marker-guarded edits in `src/hooks/useProfileSpace.ts`
  (`announceProfileChanged()` after each identity save); one link in
  `src/components/rewards/RewardsPage.tsx`.
- `src/styles.css`: the gold tokens (`--gold`, `--gold-soft`, `--color-gold*`),
  the scoped `.mood-page` block, and a refreshed app-shell block at the end of
  the file (adds two small rail rules). Preserves CRLF line endings.

## What's in the box

- `apply-mood-page.mjs` — the script (Node ≥ 18, no dependencies).
- `files/` — full copies of the new/replaced files + the two CSS blocks.
