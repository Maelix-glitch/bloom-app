#!/usr/bin/env node
/**
 * Bloom — Mood page kit (v1)
 *
 * Installs the Mood page from the harmonious-dashboard model at /mood, moves
 * the previous Mood Intelligence page to /mood/intelligence (unchanged), and
 * adds the avatar / name block at the foot of the sidebar.
 *
 * Run from anywhere:   node "<path to this folder>\apply-mood-page.mjs" [repo path]
 * Defaults to the current working directory as the repo. Idempotent: safe to
 * run twice — it only adds what is missing. The only file it removes is
 * src/routes/mood.tsx, which it first moves to src/routes/mood/intelligence.tsx.
 *
 * Requires: the Today-home kit already applied (any version from v2 on —
 * src/components/home/HomeSidebar.tsx must exist).
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(process.argv[2] ?? process.cwd());
const files = path.join(here, "files");

const ok = (m) => console.log("  \u2714 " + m);
const skip = (m) => console.log("  \u2022 " + m + " (already done)");
const fail = (m) => {
  console.error("  \u2716 " + m);
  process.exitCode = 1;
};

function read(p) {
  return fs.readFileSync(p, "utf8");
}
function write(p, text, crlf) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, crlf ? text.replace(/\r?\n/g, "\r\n") : text);
}
function isCrlf(p) {
  return fs.existsSync(p) && fs.readFileSync(p).includes("\r\n");
}
function copyFile(rel, { overwrite = true } = {}) {
  const src = path.join(files, rel);
  const dst = path.join(repo, rel);
  if (!fs.existsSync(src)) return fail(`kit is missing ${rel}`);
  if (fs.existsSync(dst) && !overwrite) return skip(rel);
  if (fs.existsSync(dst) && fs.readFileSync(dst).equals(fs.readFileSync(src))) return skip(rel);
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
  ok(`wrote ${rel}`);
}
function patch(rel, edits) {
  const p = path.join(repo, rel);
  if (!fs.existsSync(p)) return fail(`${rel} not found`);
  const crlf = isCrlf(p);
  let text = read(p).replace(/\r\n/g, "\n");
  let changed = 0;
  for (const e of edits) {
    if (e.marker && text.includes(e.marker)) continue;
    if (!text.includes(e.from)) {
      if (e.optional) continue;
      fail(`${rel}: anchor not found for "${e.name}"`);
      continue;
    }
    text = text.replace(e.from, e.to);
    changed++;
  }
  if (changed === 0) return skip(rel);
  write(p, text, crlf);
  ok(`patched ${rel} (${changed} edit${changed === 1 ? "" : "s"})`);
}

console.log(`\nBloom Mood-page kit \u2192 ${repo}\n`);

/* 0. sanity */
if (!fs.existsSync(path.join(repo, "package.json")) || !fs.existsSync(path.join(repo, "src/routes"))) {
  console.error("This doesn't look like the Bloom repo (no package.json + src/routes). Pass the repo path as an argument.");
  process.exit(1);
}
if (!fs.existsSync(path.join(repo, "src/components/home/HomeSidebar.tsx"))) {
  console.error("Apply the Today-home kit first (src/components/home/HomeSidebar.tsx is missing).");
  process.exit(1);
}

/* 1. Mood Intelligence: src/routes/mood.tsx → src/routes/mood/intelligence.tsx */
{
  const old = path.join(repo, "src/routes/mood.tsx");
  const intel = path.join(repo, "src/routes/mood/intelligence.tsx");
  if (fs.existsSync(intel)) {
    skip("src/routes/mood/intelligence.tsx");
    if (fs.existsSync(old)) {
      // both present would register /mood twice — the old file is the stale one
      fs.unlinkSync(old);
      ok("removed the stale src/routes/mood.tsx (its route now lives at /mood/intelligence)");
    }
  } else if (fs.existsSync(old)) {
    const crlf = isCrlf(old);
    let text = read(old).replace(/\r\n/g, "\n");
    const before = text;
    text = text.replace('createFileRoute("/mood")', 'createFileRoute("/mood/intelligence")');
    // the small "← Mood" link back to the new page, above the hero
    text = text
      .replace(
        'import { createFileRoute, useNavigate } from "@tanstack/react-router";\nimport { Loader2, PenLine, RotateCcw, Sparkles } from "lucide-react";',
        'import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";\nimport { ArrowLeft, Loader2, PenLine, RotateCcw, Sparkles } from "lucide-react";',
      )
      .replace(
        `      <main className="relative mx-auto w-full max-w-[1200px] px-5 pb-28 pt-14 sm:px-8 sm:pt-20 lg:pb-24">
        <Reveal>`,
        `      <main className="relative mx-auto w-full max-w-[1200px] px-5 pb-28 pt-8 sm:px-8 sm:pt-10 lg:pb-24">
        <Link
          to="/mood"
          className="mono mb-8 inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.08em] text-faint transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-3.5" /> Mood
        </Link>
        <Reveal>`,
      );
    if (text.includes('createFileRoute("/mood/intelligence")') && text !== before) {
      write(intel, text, crlf);
      fs.unlinkSync(old);
      ok("moved src/routes/mood.tsx \u2192 src/routes/mood/intelligence.tsx (route /mood/intelligence)");
    } else {
      // an unexpected local version — install the known-good copy and keep
      // the old file out of the router (rename, don't delete)
      copyFile("src/routes/mood/intelligence.tsx");
      fs.renameSync(old, path.join(repo, "src/routes/mood.tsx.before-mood-kit.txt"));
      ok("your src/routes/mood.tsx differed from the expected file \u2014 kept as src/routes/mood.tsx.before-mood-kit.txt (not a route); installed the kit's copy");
    }
  } else {
    copyFile("src/routes/mood/intelligence.tsx");
  }
}

/* 2. new files (the page, its view-model + tests, the rail identity hook, images) */
for (const rel of [
  "src/routes/mood/index.tsx",
  "src/components/mood/page/MoodPage.tsx",
  "src/components/mood/page/MoodBlob.tsx",
  "src/components/mood/page/MoodJourneyChart.tsx",
  "src/components/mood/page/MoodDonut.tsx",
  "src/hooks/useRailIdentity.ts",
  "src/lib/mood/page.ts",
  "src/lib/mood/page.test.ts",
  "src/assets/mood/hero-window.jpg",
  "src/assets/mood/flower-branch.jpg",
  "src/assets/mood/flower-detail.jpg",
  "src/assets/mood/bokeh.jpg",
  "src/assets/mood/candle.jpg",
  "src/assets/mood/mountain-lake.jpg",
]) {
  copyFile(rel);
}

/* 3. the sidebar with the avatar block at its foot (full copy — it is the
   kit's own file from the Today-home kit, now with RailProfile) */
copyFile("src/components/home/HomeSidebar.tsx");

/* 4. Profile edits announce themselves so the rail refreshes at once */
patch("src/hooks/useProfileSpace.ts", [
  {
    name: "import",
    marker: 'import { announceProfileChanged } from "@/hooks/useRailIdentity";',
    from: "import {\n  isStoryActive,",
    to: 'import { announceProfileChanged } from "@/hooks/useRailIdentity";\nimport {\n  isStoryActive,',
  },
  {
    name: "saveIdentity",
    marker: "        featured: patch.featured,\n      }));\n      announceProfileChanged();",
    from: "        featured: patch.featured,\n      }));\n    },",
    to: "        featured: patch.featured,\n      }));\n      announceProfileChanged();\n    },",
  },
  {
    name: "updateAccent",
    marker: "      patchIdentity((i) => ({ ...i, accent }));\n      announceProfileChanged();",
    from: "      patchIdentity((i) => ({ ...i, accent }));\n    },",
    to: "      patchIdentity((i) => ({ ...i, accent }));\n      announceProfileChanged();\n    },",
  },
  {
    name: "commitAvatar",
    marker: "avatarPath: path });\n      announceProfileChanged();",
    from: "      await saveProfile(userId, { ...toPatch(currentIdentity()), avatarPath: path });\n    },",
    to: "      await saveProfile(userId, { ...toPatch(currentIdentity()), avatarPath: path });\n      announceProfileChanged();\n    },",
  },
  {
    name: "clearAvatar",
    marker: "`${userId}/avatar.jpg`);\n    announceProfileChanged();",
    from: "    await removeAvatar(currentIdentity().avatarPath ?? `${userId}/avatar.jpg`);\n  }, [userId, patchIdentity]);",
    to: "    await removeAvatar(currentIdentity().avatarPath ?? `${userId}/avatar.jpg`);\n    announceProfileChanged();\n  }, [userId, patchIdentity]);",
  },
]);

/* 5. Rewards' "Back to Mood Intelligence" follows the page it names */
patch("src/components/rewards/RewardsPage.tsx", [
  {
    name: "back link \u2192 intelligence",
    marker: '<Link to="/mood/intelligence" className="reward-text-button">',
    from: '<Link to="/mood" className="reward-text-button">',
    to: '<Link to="/mood/intelligence" className="reward-text-button">',
    optional: true,
  },
]);

/* 6. styles: gold tokens (+ Tailwind colours), the scoped .mood-page block
   before the App shell block, and the refreshed App shell block (adds the
   rail's gold hairlines + the short-window rule for the identity row). */
{
  const p = path.join(repo, "src/styles.css");
  if (!fs.existsSync(p)) {
    fail("src/styles.css not found");
  } else {
    const crlf = isCrlf(p);
    let text = read(p).replace(/\r\n/g, "\n");
    const added = [];
    if (!text.includes("--color-gold:")) {
      if (!text.includes("  --color-rose: var(--rose);\n")) fail("src/styles.css: anchor not found for the @theme gold colours");
      else {
        text = text.replace("  --color-rose: var(--rose);\n", "  --color-rose: var(--rose);\n  --color-gold: var(--gold);\n  --color-gold-soft: var(--gold-soft);\n");
        added.push("gold colours");
      }
    }
    const homeIdx = text.indexOf(".home-page {");
    const head = homeIdx > 0 ? text.slice(0, homeIdx) : text;
    if (!/^\s*--gold:/m.test(head)) {
      if (!text.includes("  --amber: oklch(0.81 0.11 82);\n")) fail("src/styles.css: anchor not found for the gold tokens");
      else {
        text = text.replace("  --amber: oklch(0.81 0.11 82);\n", "  --amber: oklch(0.81 0.11 82);\n  --gold: oklch(0.855 0.086 82);\n  --gold-soft: oklch(0.9 0.05 88);\n");
        added.push("gold tokens");
      }
    }
    const shellBanner = "/* ---------------------------------------------------------------------------\n * App shell \u2014";
    if (!text.includes(".mood-page {")) {
      const at = text.indexOf(shellBanner);
      const block = read(path.join(files, "mood-page-styles.css"));
      text = at === -1 ? text.replace(/\s*$/, "\n\n") + block : text.slice(0, at) + block + text.slice(at);
      added.push("the .mood-page block");
    }
    const shell = read(path.join(files, "app-shell-styles.css"));
    const at = text.indexOf(shellBanner);
    if (at === -1) {
      text = text.replace(/\s*$/, "\n\n") + shell;
      added.push("the app-shell block");
    } else if (!text.includes(".app-sidebar-gold-rule {")) {
      // the app-shell block runs to the end of the file in every Today-home
      // kit version, so swap the tail for the refreshed one
      text = text.slice(0, at) + shell;
      added.push("the refreshed app-shell block");
    }
    if (added.length === 0) skip("src/styles.css");
    else {
      write(p, text, crlf);
      ok(`src/styles.css: added ${added.join(", ")}`);
    }
  }
}

/* 7. verify */
console.log("\nVerify:");
const checks = [
  ["src/routes/mood/index.tsx", 'createFileRoute("/mood/")', "Mood page (model) lives at /mood"],
  ["src/routes/mood/intelligence.tsx", 'createFileRoute("/mood/intelligence")', "Mood Intelligence lives at /mood/intelligence"],
  ["src/routes/mood/intelligence.tsx", "<AppNav />", "sidebar on /mood/intelligence"],
  ["src/components/mood/page/MoodPage.tsx", 'data-testid="mood-log"', "Mood page installed"],
  ["src/lib/mood/page.ts", "export function entryFromFace", "Mood page view-model installed"],
  ["src/components/home/HomeSidebar.tsx", "RailProfile", "avatar block at the foot of the rail"],
  ["src/hooks/useRailIdentity.ts", "export function useRailIdentity", "rail identity hook installed"],
  ["src/hooks/useProfileSpace.ts", "announceProfileChanged", "rail refreshes after profile edits"],
  ["src/styles.css", ".mood-page {", "Mood page styles present"],
  ["src/styles.css", "--color-gold:", "gold tokens registered"],
  ["src/styles.css", ".app-sidebar-gold-rule {", "rail identity-row styles present"],
];
for (const [rel, needle, label] of checks) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && read(p).includes(needle)) ok(label);
  else fail(`${label} \u2014 check ${rel}`);
}
if (fs.existsSync(path.join(repo, "src/routes/mood.tsx"))) fail("src/routes/mood.tsx still exists \u2014 it would register /mood twice");
else ok("no duplicate /mood route");

if (process.exitCode) {
  console.log("\nSomething was skipped \u2014 see the \u2716 lines above. Nothing else was changed.");
} else {
  console.log(`
Done. Next:
  1. npm run dev  \u2192 open /mood  (tap a face while signed in \u2014 the hero updates; "See all" \u2192 /mood/intelligence). The dev server regenerates src/routeTree.gen.ts for the new routes on first start \u2014 commit that file too.
  2. Any main page: your avatar + name now sit at the foot of the sidebar (change your photo on Profile and it updates at once).
  3. git add -A && git commit -m "feat(mood): model Mood page at /mood, Intelligence at /mood/intelligence, rail avatar" && git push
`);
}
