#!/usr/bin/env node
/**
 * Bloom — Tier A kit (2026-09-07)
 *
 * Brings a checkout of bloom-app from what it shipped with (commit ce972cf,
 * "redesign MetricsModal") to the state of the arena/01a0702b-bloom-app branch
 * at 1c364ab — EVERY phase so far, in one run:
 *
 *   • metrics-entry modal fix           • Today home page + habits + shared rail
 *   • Add-habit dialog (v3 HTML, 1:1)   • one chrome (no duplicate header, fixed rail)
 *   • Mood page + Mood Intelligence      • full-width /cycle + period check-ins
 *   • Tier A (A1–A12): local-day mood keys, mood context kept + prefilled from
 *     trackers, habit edit/pause/archive/delete, weekly "N× a week" habits,
 *     period entries + check-in answers synced to the account, honest lateness,
 *     adaptive plausibility for long cycles, bounded "has it finished?" window,
 *     one card per situation, Clear-all confirm + undo on trackers, habits made
 *     before sign-in kept, Mood works offline / signed out.
 *
 * It is idempotent and safe on a checkout that already has some earlier kits:
 * every file is byte-compared (after CRLF/whitespace normalisation) and only
 * written when it differs; a file that is neither the shipped version nor a
 * version this branch ever produced is kept beside the new one as
 * <name>.before-tier-a.txt — nothing of yours is ever silently lost.
 *
 * Run from anywhere:   node "<path to this folder>\apply-tier-a.mjs" [repo path]
 * Defaults to the current working directory as the repo.
 *
 * Afterwards run the SQL files in ./migrations once in the Supabase SQL editor
 * (see README.md) — the app keeps working before you do, it just keeps the new
 * things on the device until the tables exist.
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const KIT = "Tier A kit (2026-09-07, branch tip 1c364ab)";
const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(process.argv[2] ?? process.cwd());
const files = path.join(here, "files");

const ok = (m) => console.log("  \u2714 " + m);
const skip = (m) => console.log("  \u2022 " + m + " (already done)");
const note = (m) => console.log("  \u2139 " + m);
const fail = (m) => {
  console.error("  \u2716 " + m);
  process.exitCode = 1;
};

const read = (p) => fs.readFileSync(p, "utf8");
const norm = (t) => t.replace(/\r\n/g, "\n");
const isCrlf = (p) => fs.existsSync(p) && fs.readFileSync(p).includes("\r\n");
// Compared after normalising line endings and trailing whitespace at EOF, so a
// Windows checkout (CRLF, editors adding a final newline) still matches.
const md5 = (t) => crypto.createHash("md5").update(norm(t).replace(/\s+$/, "")).digest("hex");
const md5file = (p) => crypto.createHash("md5").update(fs.readFileSync(p)).digest("hex");
function write(p, text, crlf) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, crlf ? text.replace(/\r?\n/g, "\r\n") : text);
}

/* Text files this kit installs (added or replaced). */
const INSTALL = [
  "public/bloom/shared-bloom-header.js",
  "src/components/BloomHeader.tsx",
  "src/components/ci/CheckIns.tsx",
  "src/components/ci/CycleIntelligence.tsx",
  "src/components/ci/HistoryTable.tsx",
  "src/components/ci/InsightsPanel.tsx",
  "src/components/ci/LogPanel.tsx",
  "src/components/ci/PredictionsCard.tsx",
  "src/components/ci/SyncLine.tsx",
  "src/components/ci/UndoToast.tsx",
  "src/components/ci/primitives.tsx",
  "src/components/coach/CoachPage.tsx",
  "src/components/home/CoachPanel.tsx",
  "src/components/home/ConnectionMap.tsx",
  "src/components/home/HabitUndo.tsx",
  "src/components/home/HabitsSection.tsx",
  "src/components/home/HomeSidebar.tsx",
  "src/components/home/ProgressRing.tsx",
  "src/components/home/panels.tsx",
  "src/components/mood/Atmosphere.tsx",
  "src/components/mood/Calendar.tsx",
  "src/components/mood/Composer.tsx",
  "src/components/mood/Correlations.tsx",
  "src/components/mood/Distribution.tsx",
  "src/components/mood/Emotions.tsx",
  "src/components/mood/Heatmap.tsx",
  "src/components/mood/History.tsx",
  "src/components/mood/Insights.tsx",
  "src/components/mood/MoodChart.tsx",
  "src/components/mood/Patterns.tsx",
  "src/components/mood/Timeline.tsx",
  "src/components/mood/page/MoodBlob.tsx",
  "src/components/mood/page/MoodDonut.tsx",
  "src/components/mood/page/MoodGraph.tsx",
  "src/components/mood/page/MoodJourneyChart.tsx",
  "src/components/mood/page/MoodPage.tsx",
  "src/components/mood/primitives.tsx",
  "src/components/rewards/RewardsPage.tsx",
  "src/components/tk/AddHabitModal.tsx",
  "src/components/tk/HistoryTable.tsx",
  "src/components/tk/MetricsEntryModal.tsx",
  "src/components/tk/TrackersPage.tsx",
  "src/components/tk/designs/Atlas.tsx",
  "src/components/tk/designs/Ledger.tsx",
  "src/components/tk/designs/Strip.tsx",
  "src/hooks/useCoachSystem.ts",
  "src/hooks/useHabits.ts",
  "src/hooks/useMoodSystem.ts",
  "src/hooks/usePeriodLog.sync.test.tsx",
  "src/hooks/usePeriodLog.ts",
  "src/hooks/useProfileSpace.ts",
  "src/hooks/useRailIdentity.ts",
  "src/hooks/useRewardsSystem.ts",
  "src/hooks/useTrackers.ts",
  "src/lib/cycle/cycleCloud.test.ts",
  "src/lib/cycle/dayLogs.ts",
  "src/lib/cycle/periodCloud.test.ts",
  "src/lib/cycle/periodCloud.ts",
  "src/lib/cycle/periodStore.ts",
  "src/lib/cycle/predict.test.ts",
  "src/lib/cycle/predict.ts",
  "src/lib/cycle/reconcile.test.ts",
  "src/lib/cycle/reconcile.ts",
  "src/lib/home/habits.test.ts",
  "src/lib/home/habits.ts",
  "src/lib/home/today.ts",
  "src/lib/localDay.test.ts",
  "src/lib/localDay.ts",
  "src/lib/mood/analytics.ts",
  "src/lib/mood/context.test.ts",
  "src/lib/mood/context.ts",
  "src/lib/mood/graph.test.ts",
  "src/lib/mood/graph.ts",
  "src/lib/mood/page.test.ts",
  "src/lib/mood/page.ts",
  "src/lib/mood/pending.test.ts",
  "src/lib/mood/pending.ts",
  "src/lib/mood/record.ts",
  "src/lib/mood/storage.ts",
  "src/lib/profile/journey.ts",
  "src/lib/undo.test.ts",
  "src/lib/undo.ts",
  "src/routeTree.gen.ts",
  "src/router.tsx",
  "src/routes/cycle-styles.tsx",
  "src/routes/cycle.tsx",
  "src/routes/index.tsx",
  "src/routes/mood/index.tsx",
  "src/routes/mood/intelligence.tsx",
  "src/routes/profile.tsx",
  "src/routes/trackers.tsx",
  "src/styles.css",
  "src/styles/add-habit-modal.css",
  "src/styles/cycle2.css",
  "supabase/migrations/20260906_today_home.sql",
  "supabase/migrations/20260907_cycle_periods.sql",
  "supabase/migrations/20260907_habit_pause.sql",
  "supabase/migrations/20260908_mood_context.sql"
];

/* Images (compared byte-for-byte). */
const BINARIES = [
  "src/assets/home/leaf-dark.jpg",
  "src/assets/home/sidebar-botanical.jpg",
  "src/assets/home/window-dusk.jpg",
  "src/assets/mood/bokeh.jpg",
  "src/assets/mood/candle.jpg",
  "src/assets/mood/flower-branch.jpg",
  "src/assets/mood/flower-detail.jpg",
  "src/assets/mood/hero-window.jpg",
  "src/assets/mood/mountain-lake.jpg"
];

/* Every version of each replaced file that the shipped app or this branch ever
   had (md5 of LF-normalised text). Anything else is a local edit → backed up. */
const KNOWN_BEFORE = {
  "public/bloom/shared-bloom-header.js": ["4ffca8bbdf2b0c0b16cb61116f2c3512"],
  "src/components/BloomHeader.tsx": ["d115bbcdaaea5fd8031ff784a70373b1"],
  "src/components/ci/CycleIntelligence.tsx": ["5f103dee6a88b0c4c904c961fc8b688f", "cbe8498d228bf5d12925858d5bddf7cc"],
  "src/components/ci/HistoryTable.tsx": ["1eea5f51f00ed2ae4e82a06a5013fb8b", "4e09153ae656e24d20022035d70655ad"],
  "src/components/ci/InsightsPanel.tsx": ["5c063c1442721c58c7bdc76531196313"],
  "src/components/ci/LogPanel.tsx": ["b3658cf3dbf0421bd09acc3a430a31f5"],
  "src/components/ci/PredictionsCard.tsx": ["7d31204b7dc806fed4d67bac9150ecb0"],
  "src/components/ci/SyncLine.tsx": ["19c5d4bb7f94ff49116ff69f706446d4", "9b244d020383348174a9fdf254b0c3c7"],
  "src/components/ci/UndoToast.tsx": ["347ef6a74d90c39c57228e4125e20ec8"],
  "src/components/ci/primitives.tsx": ["b1a0aee2167cbd5cfe6492823da2abba"],
  "src/components/coach/CoachPage.tsx": ["2fbfb3b180c97c28f385a8c10cabd684", "786e385923f4c84ac8201af259c891d3", "ede250d520228ca3b0d8e50f27e82efc"],
  "src/components/home/HabitsSection.tsx": ["d60338f4657ecc4a0662cb6489576ed6", "e2ff7135cfaed84e1cbfb1442628fdc9"],
  "src/components/home/HomeSidebar.tsx": ["2b2a4b567dc161e01823f6740d40366c", "619e09aba5535097944e9c36dbc1dcd9", "a8375cc06e527326525b87ba89370fb3", "ec7505bf220a297132dec9536b5f3922"],
  "src/components/home/panels.tsx": ["da51f941610962701b25cada3d15a486"],
  "src/components/mood/Atmosphere.tsx": ["f89d4e87078586ea8d89bb6950137ff8"],
  "src/components/mood/Calendar.tsx": ["03041dc368c335abc4a7f0c3cfa8f5b9"],
  "src/components/mood/Composer.tsx": ["ac6665176d345c291107aa052d0b1256"],
  "src/components/mood/Correlations.tsx": ["0ced19c605dc290219b2f14086672597"],
  "src/components/mood/Distribution.tsx": ["282353db2e50eff7bbec30f2c1dcc552"],
  "src/components/mood/Emotions.tsx": ["33a76cd68517329ef02f2d6edf58f8a9"],
  "src/components/mood/Heatmap.tsx": ["1ef8ca80e775cda55532f8287cb0edb7"],
  "src/components/mood/History.tsx": ["afb93675684689eae712107104c6980c"],
  "src/components/mood/Insights.tsx": ["b659517e1de1ad52180bc66c70dbfa78"],
  "src/components/mood/MoodChart.tsx": ["703aac4e0a201cdf74541c46c8034914"],
  "src/components/mood/Patterns.tsx": ["8e9f3d17e0d297c71a766c953bf6eb08"],
  "src/components/mood/Timeline.tsx": ["e8463e3171b2f4fd39e544b262179785"],
  "src/components/mood/page/MoodPage.tsx": ["92305c751e1971a4d9e53b3c6c0f8346", "e9fd4a840c0e01fee0fa67062e3cc28f"],
  "src/components/mood/primitives.tsx": ["424d3d9e347dc0e40caf4654f25f20d5"],
  "src/components/rewards/RewardsPage.tsx": ["9111560da57bc41286a857d7cbac53b2", "9f156065f1d37a0785ada5731cd60425", "acf2c56049672449accf38f3f85d82eb", "b8e62be28a8a0b6ace7ae7f2cd5c3f8a"],
  "src/components/tk/AddHabitModal.tsx": ["0bc064e592ab7f76a89ffec870398044", "fbaec51215b34cea15e07320a57a11b6"],
  "src/components/tk/HistoryTable.tsx": ["11c684a5d581bdbfbe38a22df44c970a"],
  "src/components/tk/TrackersPage.tsx": ["44ff02c97e07df93c16a16187c4c21f0"],
  "src/components/tk/designs/Atlas.tsx": ["2fd145db70ec561301632ed7c9059fc3"],
  "src/components/tk/designs/Ledger.tsx": ["483177354895a1aff9a1041b373a29a3"],
  "src/components/tk/designs/Strip.tsx": ["c989d4f20c57b4e275b7ac70fdf7d775"],
  "src/hooks/useCoachSystem.ts": ["58bb7b837f95c61e7570abf3aaf9c924", "68f340bd797f3b38aea958648f4c7aef", "eed37c710c1a09d85a5f2b77802f6f01"],
  "src/hooks/useHabits.ts": ["16351cf672fe65961798c7ccdb9ec7af", "9b1781c628389eafdcc23ebf5ac7ea8f"],
  "src/hooks/useMoodSystem.ts": ["611b1c5acc4a1646b3dc3996b7520451", "77c1a3095101cb0fe3183242aca4cfef", "aec5c790338fa9fd6e59629b54ef885d", "b15af6dc2dcd31eaa550a33537bfc666"],
  "src/hooks/usePeriodLog.sync.test.tsx": ["9f32727d2c64c4540fec38dcda7e826f"],
  "src/hooks/usePeriodLog.ts": ["2491d14378a4a7e8e7d4f8c732f2daca", "30156965070afe977e299ff2f287f0c2", "4d401c15432b1e3a0b5300ce12df87a1", "ed6b9789a246929907635a1540dbdff8"],
  "src/hooks/useProfileSpace.ts": ["06a295f267520aa1a921508aa91ee60b", "ddcdaf587f44895ec0de98bfd28370fb"],
  "src/hooks/useRewardsSystem.ts": ["e2f9ba641a10f8f34b6c572d479100bb"],
  "src/hooks/useTrackers.ts": ["1258db0ba54f7a23d21bc3b38ba2318f"],
  "src/lib/cycle/cycleCloud.test.ts": ["461e47cf0f877f156cda312f5f052308"],
  "src/lib/cycle/dayLogs.ts": ["ac90b263ea102f6cc3732293e5a16db9"],
  "src/lib/cycle/periodStore.ts": ["377202f23f5276b06ca250ca7ca2c8a3", "d3587b70801239efbfc1805e80070620", "dec0586dc32a6735c34a86d290f28571"],
  "src/lib/cycle/predict.test.ts": ["2c4d6915dec6f5832b1fcac2d936cec2"],
  "src/lib/cycle/predict.ts": ["07bc3048ade98737afa22abf5cc1aa7f", "27fe7d17b483529e86b4aa174ef53fa6"],
  "src/lib/cycle/reconcile.test.ts": ["86218da3133270aff2c75c22fd2740fb"],
  "src/lib/cycle/reconcile.ts": ["4dc90d8afb400c013c755583221876e6"],
  "src/lib/home/habits.test.ts": ["292c588d1afd7ea3c107d0c42c6c978e"],
  "src/lib/home/habits.ts": ["76136dda3e13dc1dc2c603daa41be49d", "950542bdacb3a63bde4d4c62d37b5467", "c06b43d81043ba05af5938d25a7a93a6", "c632e40231533d9955f9bee301c380c1"],
  "src/lib/home/today.ts": ["9b5c5f6ea8737930ef3dc5badbc205b2"],
  "src/lib/mood/analytics.ts": ["c96316f140d6ba6abbac52e3c53b7b5c"],
  "src/lib/mood/page.ts": ["a680ae2efbd6ff5274fea1625016037a"],
  "src/lib/mood/record.ts": ["525ed48735264eb5df947dbdfb63299f"],
  "src/lib/mood/storage.ts": ["684d24fc14c82c913e1d1357edacfb61", "ad21dfe6bb31613c3b16e557ebd2e021"],
  "src/lib/profile/journey.ts": ["d449769345eda3ff37bc0ccbc2cfc38e"],
  "src/routeTree.gen.ts": ["9b0e23c3672f37d6979bec1e1bbe7d3d", "c8f68f81442db654051cbaef5fb54945"],
  "src/router.tsx": ["078d80bb6d6c537cf360f6d7e625d882"],
  "src/routes/cycle-styles.tsx": ["34119f796a898052944bfd7a19a50e30"],
  "src/routes/cycle.tsx": ["86a4e33c9191cbc99cde3efa162f1a72", "da88eaa4f25cd2a55b53f6806e38ca2f"],
  "src/routes/index.tsx": ["3e8f836aff937279a5858a3b7f6f0d84", "755062b7079576f1a5990257025e610e", "ab5a47523f7abd5b2f9c62c794b203b0", "d7fcb93b866dbdb8d79f617db92b7882"],
  "src/routes/mood/intelligence.tsx": ["211d411d902d267f701fdcaed2136034", "7e1af07266f74f44072c07f0609aa35e"],
  "src/routes/profile.tsx": ["02699c6973881fa431cf278eb04287fc", "aacafa00d1692b4efa935283a0623927"],
  "src/routes/trackers.tsx": ["3f73e16e23f6b1835119c47c8bbc34ba", "53a87ff57459f6c5550c2a71e21b8577"],
  "src/styles.css": ["249c9dc1de59c669a819d1bd7d863941", "481f11949964520cee913dc9f3289c23", "48aeb6016f788a2f1ddfb8bc711344e3", "59ec4770b9aede20ca4ad9bbd7f2c093", "69dd2f45ca325af29fb215f9c491b32c", "b30c689d0bcf943b3ab04ee7c2b4c27f", "d373ce39fde87fa5740f94164fbb01e8", "ed5e3cccff55d4f2c884cc6aa4c48831", "ff8aa6545150632b4c52664648f28718"],
  "src/styles/cycle2.css": ["e65045bdd378997b2417684fdb7fda48"]
};

/* Files the branch removed (dead duplicates from the Lovable export). Only
   deleted when they are byte-identical to what the app shipped with. */
const REMOVE = [
  ["src/components/lovable/metrics-entry-modal.tsx", "d2fd68d31aea3712cb86e9f7e50eade7"],
  ["src/components/tk/MetricsModal.tsx", "983b3886a062198d05dec1d9394350e4"],
  ["src/components/tk/designs/MetricsEntryModal.tsx", "c99c2353552bef74c4b6b8c205970877"],
  ["src/hooks/lovable-use-mobile.tsx", "acb595d81fdb00a478c23eab1c95910c"],
  ["src/lib/lovable-error-capture.ts", "d80edfc03670b7465befc0183871e5d2"],
  ["src/lib/lovable-utils.ts", "24764f4ccdc48e54a80defc6a93312a7"],
  ["src/styles/lovable-styles.css", "86dd6e31f0a343a49db1cbe6f24e07c0"]
];
const REMOVE_UI = [
  ["src/components/lovable/ui/accordion.tsx", "8bb7af39d78a0402c36430ed5ba0f74d"],
  ["src/components/lovable/ui/alert-dialog.tsx", "a172f833ca943f0c387402d5d133fc0f"],
  ["src/components/lovable/ui/alert.tsx", "ce9de7cf8a34a47ac98dc1ae2e9eabc1"],
  ["src/components/lovable/ui/aspect-ratio.tsx", "4a7908490f20cbb865809aec793d5cb4"],
  ["src/components/lovable/ui/avatar.tsx", "b26bc48064a1581b7355ff4b885828c9"],
  ["src/components/lovable/ui/badge.tsx", "59356a2674673b331d3d795cc288a519"],
  ["src/components/lovable/ui/breadcrumb.tsx", "031eb6fbd1d71691fcc7f29acb07c3a2"],
  ["src/components/lovable/ui/button.tsx", "97186e51ca55f89f47f3dfc1bf50ab29"],
  ["src/components/lovable/ui/calendar.tsx", "11f967e2be3936149ad37b6f5ff3657b"],
  ["src/components/lovable/ui/card.tsx", "fa37ff2f367aee39ef1310ca07790a0b"],
  ["src/components/lovable/ui/carousel.tsx", "3ad1ff723ce96906797963be67f7ed3e"],
  ["src/components/lovable/ui/chart.tsx", "0e9b90f1d3c34f48c99aed328b112774"],
  ["src/components/lovable/ui/checkbox.tsx", "ef31bd772f339e95d73a1c57e507add3"],
  ["src/components/lovable/ui/collapsible.tsx", "6d06ab3cee9d2b6b2168c7f4d5770bdd"],
  ["src/components/lovable/ui/command.tsx", "0aa40bcaf561034de04083b501ce75ec"],
  ["src/components/lovable/ui/context-menu.tsx", "be8ad8a1ac8f6dde02cfb1201b171004"],
  ["src/components/lovable/ui/dialog.tsx", "2c22cfe4af70082af2edd964de68df66"],
  ["src/components/lovable/ui/drawer.tsx", "b78eda3bafc4f956df65489093ac3862"],
  ["src/components/lovable/ui/dropdown-menu.tsx", "714786077b94a908181955db92fa1645"],
  ["src/components/lovable/ui/form.tsx", "16f818ff22f71eeb70c17b7767af1a16"],
  ["src/components/lovable/ui/hover-card.tsx", "0e315b2c69460427241856290477f037"],
  ["src/components/lovable/ui/input-otp.tsx", "7f7d84718db81476f961eda8781fac32"],
  ["src/components/lovable/ui/input.tsx", "665dd4a22eb759305506bc03f451d339"],
  ["src/components/lovable/ui/label.tsx", "7b43d3ce329c3879df0c92b1133c57e3"],
  ["src/components/lovable/ui/menubar.tsx", "87f376c6b846ecf9e92171de32cd7d15"],
  ["src/components/lovable/ui/navigation-menu.tsx", "0d1b92631255632bdb33cb2ea94e6ecd"],
  ["src/components/lovable/ui/pagination.tsx", "912855e23468b696349fba4c08deb534"],
  ["src/components/lovable/ui/popover.tsx", "3054eb96c1bffe8fc68f835d07af96be"],
  ["src/components/lovable/ui/progress.tsx", "325ec71ff7fd2e215e711f64e1be3d3c"],
  ["src/components/lovable/ui/radio-group.tsx", "8a51e09f47bef916876c594d89d222ee"],
  ["src/components/lovable/ui/resizable.tsx", "e560284667f5c35d73d01b398d958a8b"],
  ["src/components/lovable/ui/scroll-area.tsx", "4c224a75763d6743ba6f6a49ed5e5c3b"],
  ["src/components/lovable/ui/select.tsx", "38a15b493a1c86895f16c389f2a70f30"],
  ["src/components/lovable/ui/separator.tsx", "d92ac66d1a8d31f28452f7a9c2f0758b"],
  ["src/components/lovable/ui/sheet.tsx", "a6a08a343026a8c0997a0fc44041fa11"],
  ["src/components/lovable/ui/sidebar.tsx", "c07e18c392536488365367c3ebf15e31"],
  ["src/components/lovable/ui/skeleton.tsx", "4a92bd7bbc27e04bc5368a566a593d4f"],
  ["src/components/lovable/ui/slider.tsx", "c5007f96f7471840a9a2d08d21e260d1"],
  ["src/components/lovable/ui/sonner.tsx", "8517ce898ed2ca99f5a78f17d3022baf"],
  ["src/components/lovable/ui/switch.tsx", "13804b4f1dcfa652f1562fb5c2e157ba"],
  ["src/components/lovable/ui/table.tsx", "c6770881c182282ab42578cb9b5f8430"],
  ["src/components/lovable/ui/tabs.tsx", "dcad41f4f1d3604aa1527adb8d2a120b"],
  ["src/components/lovable/ui/textarea.tsx", "c0bc17032586ccf18546551e149d4224"],
  ["src/components/lovable/ui/toggle-group.tsx", "2982833fef1c5c371edc12a3223101ad"],
  ["src/components/lovable/ui/toggle.tsx", "dc1d411021c8a072c3349a8566c0b0b8"],
  ["src/components/lovable/ui/tooltip.tsx", "d5e629a70dbb68fa2da17f48a48bf708"]
];

function installText(rel) {
  const src = path.join(files, rel);
  const dst = path.join(repo, rel);
  if (!fs.existsSync(src)) return fail(`kit is missing ${rel}`);
  const next = read(src);
  if (!fs.existsSync(dst)) {
    write(dst, next, false);
    return ok(`added ${rel}`);
  }
  const cur = read(dst);
  if (md5(cur) === md5(next)) return skip(rel);
  const known = KNOWN_BEFORE[rel] ?? [];
  if (!known.includes(md5(cur))) {
    const bak = dst + ".before-tier-a.txt";
    fs.copyFileSync(dst, bak);
    note(`${rel} had local edits \u2014 your copy is kept as ${path.basename(bak)}`);
  }
  write(dst, next, isCrlf(dst));
  ok(`updated ${rel}`);
}

function installBinary(rel) {
  const src = path.join(files, rel);
  const dst = path.join(repo, rel);
  if (!fs.existsSync(src)) return fail(`kit is missing ${rel}`);
  if (fs.existsSync(dst) && md5file(dst) === md5file(src)) return skip(rel);
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
  ok(`${fs.existsSync(dst) ? "updated" : "added"} ${rel}`);
}

function removeFile(rel, shippedMd5) {
  const p = path.join(repo, rel);
  if (!fs.existsSync(p)) return;
  if (shippedMd5 && md5(read(p)) !== shippedMd5) {
    return note(`${rel} differs from the shipped file \u2014 left in place (safe to delete by hand if unused)`);
  }
  fs.unlinkSync(p);
  ok(`removed ${rel}`);
}

console.log(`\nBloom \u2014 ${KIT} \u2192 ${repo}\n`);

/* 0. sanity */
if (!fs.existsSync(path.join(repo, "package.json")) || !fs.existsSync(path.join(repo, "src/routes"))) {
  console.error("This doesn't look like the Bloom repo (no package.json + src/routes). Pass the repo path as an argument.");
  process.exit(1);
}
const pkg = JSON.parse(read(path.join(repo, "package.json")));
const deps = { ...(pkg.dependencies ?? {}), ...(pkg.devDependencies ?? {}) };
for (const d of ["@tanstack/react-router", "@supabase/supabase-js", "vitest", "dayjs"]) {
  if (!deps[d]) fail(`package.json has no ${d} \u2014 is this the chronos-feel checkout?`);
}
if (process.exitCode) process.exit(1);

/* 1. what state is the tree in? */
console.log("Found:");
{
  const has = (rel, needle) => {
    const p = path.join(repo, rel);
    return fs.existsSync(p) && (!needle || norm(read(p)).includes(needle));
  };
  const state = (cond, yes, no) => console.log("  " + (cond ? "\u2714 " + yes : "\u2192 " + no));
  state(has("src/components/tk/MetricsEntryModal.tsx"), "metrics-entry modal fix present", "metrics-entry modal fix not applied yet (this kit includes it)");
  state(has("src/components/home/HomeSidebar.tsx"), "Today home page + rail present", "Today home page not applied yet (this kit includes it)");
  state(has("src/routes/mood/index.tsx"), "Mood page present", "Mood page not applied yet (this kit includes it)");
  state(has("src/lib/cycle/reconcile.ts"), "cycle check-ins present", "cycle check-ins not applied yet (this kit includes it)");
  state(has("src/lib/localDay.ts"), "Tier A already started", "no Tier A files yet");
  state(has("src/lib/cycle/periodCloud.ts"), "period sync present", "period entries still device-only");
  state(has("src/lib/mood/pending.ts"), "mood outbox present", "Mood still fails offline / signed out");
}
console.log("");

/* 2. install */
console.log("Apply:");
for (const rel of INSTALL) installText(rel);
for (const rel of BINARIES) installBinary(rel);

/* 3. remove dead duplicates (only shipped-identical copies) */
for (const [rel, h] of REMOVE) removeFile(rel, h);
/* the Today-home kit's flat /mood route was replaced by routes/mood/index.tsx —
   two files for one path would make the router complain */
{
  const p = path.join(repo, "src/routes/mood.tsx");
  if (fs.existsSync(p)) {
    const known = ["21721fc4b5f242e1b7ebf51aa45fb73c", "634b5f1fef5970dfbaab3b318eb93bd1", "8e910350e86ba23bb583959ea7603519"];
    if (known.includes(md5(read(p)))) {
      fs.unlinkSync(p);
      ok("removed src/routes/mood.tsx (superseded by src/routes/mood/index.tsx)");
    } else {
      const bak = p + ".before-tier-a.txt";
      fs.renameSync(p, bak);
      note(`src/routes/mood.tsx had local edits \u2014 moved aside to ${path.basename(bak)} (routes/mood/index.tsx takes over /mood)`);
    }
  }
}
for (const [rel, h] of REMOVE_UI) removeFile(rel, h);
for (const dir of ["src/components/lovable/ui", "src/components/lovable"]) {
  const p = path.join(repo, dir);
  if (fs.existsSync(p) && fs.readdirSync(p).length === 0) {
    fs.rmdirSync(p);
    ok(`removed empty folder ${dir}`);
  }
}

/* 4. migrations + docs */
{
  const mdir = path.join(repo, "supabase/migrations");
  fs.mkdirSync(mdir, { recursive: true });
  for (const f of fs.readdirSync(path.join(here, "migrations"))) {
    const src = path.join(here, "migrations", f);
    const dst = path.join(mdir, f);
    if (fs.existsSync(dst) && md5(read(dst)) === md5(read(src))) skip(`supabase/migrations/${f}`);
    else {
      fs.copyFileSync(src, dst);
      ok(`added supabase/migrations/${f}`);
    }
  }
  for (const [srcName, dstRel] of [["REPORT.md", "docs/tier-a/REPORT.md"], ["WHAT-IS-MISSING.md", "docs/audit/WHAT-IS-MISSING.md"]]) {
    const src = path.join(here, srcName);
    if (!fs.existsSync(src)) continue;
    const dst = path.join(repo, dstRel);
    if (fs.existsSync(dst) && md5(read(dst)) === md5(read(src))) skip(dstRel);
    else {
      fs.mkdirSync(path.dirname(dst), { recursive: true });
      fs.copyFileSync(src, dst);
      ok(`added ${dstRel}`);
    }
  }
}

/* 5. .gitignore: screenshots folder */
{
  const gi = path.join(repo, ".gitignore");
  const cur = fs.existsSync(gi) ? read(gi) : "";
  if (!/^\.shots\/?$/m.test(cur)) {
    fs.writeFileSync(gi, cur.replace(/\s*$/, "\n") + ".shots/\n");
    ok("added .shots/ to .gitignore");
  } else skip(".gitignore");
}

/* 6. verify */
console.log("\nVerify:");
const checks = [
  ["src/components/tk/MetricsEntryModal.tsx", "export function MetricsEntryModal", "metrics-entry modal"],
  ["src/routes/index.tsx", "HabitsSection", "Today page with habits"],
  ["src/components/home/HomeSidebar.tsx", "export function AppNav", "shared rail"],
  ["src/routes/mood/index.tsx", "MoodPage", "Mood page"],
  ["src/lib/localDay.ts", "export function localDay", "A1 local-day authority"],
  ["src/lib/mood/context.ts", "contextFromTrackerDay", "A2 mood context from trackers"],
  ["src/lib/mood/storage.ts", "withContextFallback", "A2 context column round-trip (with fallback)"],
  ["src/hooks/useHabits.ts", "setPause", "A3 pause / archive / delete"],
  ["src/lib/home/habits.ts", "export function weeklyProgress", "A4 weekly habits"],
  ["src/lib/cycle/periodCloud.ts", "export function mergePeriodRecords", "A5 period sync"],
  ["src/hooks/usePeriodLog.ts", "pullPeriods", "A5 hook wired"],
  ["src/lib/cycle/predict.ts", "lateAfterDaysLowConfidence", "A6 honest lateness"],
  ["src/lib/cycle/predict.ts", "personalMaxPlausible", "A7 adaptive plausibility"],
  ["src/lib/cycle/reconcile.ts", "openAskUntilDays", "A8 bounded still-open window"],
  ["src/lib/undo.ts", "export const UNDO_WINDOW_MS", "A10 shared undo"],
  ["src/hooks/useTrackers.ts", "undoable", "A10 trackers undo"],
  ["src/lib/home/habits.ts", "export async function uploadLocalHabits", "A11 pre-sign-in habits kept"],
  ["src/lib/mood/pending.ts", "export function applyPending", "A12 mood outbox"],
  ["src/lib/mood/record.ts", "retry()", "A12 retry wired"],
  ["supabase/migrations/20260907_cycle_periods.sql", "create table if not exists public.cycle_periods", "cycle_periods migration file"],
  ["supabase/migrations/20260908_mood_context.sql", "add column if not exists context jsonb", "mood context migration file"],
];
for (const [rel, needle, label] of checks) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && norm(read(p)).includes(needle)) ok(label);
  else fail(`${label} \u2014 check ${rel}`);
}

if (process.exitCode) {
  console.log("\nSomething was skipped \u2014 see the \u2716 lines above. Send me this whole output.");
} else {
  console.log(`
Done. Next:
  1. npm install            (no new packages, but the lockfile may refresh)
  2. Stop the dev server if it is running, then:  npm run dev
     (it regenerates src/routeTree.gen.ts on start \u2014 commit that file too).
  3. Hard-refresh once (Ctrl+F5).
  4. Supabase \u2192 SQL editor: run the four files in this folder's migrations/
     in order (README.md explains each; all are safe to re-run):
       20260906_today_home.sql   20260907_habit_pause.sql
       20260907_cycle_periods.sql   20260908_mood_context.sql
  5. Optional: npx vitest run   (150 tests)
  6. git add -A && git commit -m "feat: Tier A \u2014 trust and data first (A1\u2013A12)" && git push
`);
}
