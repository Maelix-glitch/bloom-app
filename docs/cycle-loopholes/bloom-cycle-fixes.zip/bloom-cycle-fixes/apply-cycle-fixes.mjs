#!/usr/bin/env node
/**
 * Bloom — Cycle fixes kit (v1, 2026-09-07)
 *
 * Two things for /cycle:
 *
 *   1. Width      — the page runs edge to edge inside the app shell, with the
 *                   same margins as Today and Mood (it was capped at 1060px).
 *   2. Loopholes  — period logging now understands the person instead of
 *                   assuming. "First day of a period" is pre-ticked only when
 *                   the date plausibly starts a cycle; a bleed on day 3 extends
 *                   the current period instead of creating a 2-day "cycle";
 *                   "None" inside an open period offers to close it; and a
 *                   Check-ins card asks the questions the record needs:
 *                     "Bleeding stopped on day 3 — did your period end early?"
 *                     "You logged bleeding the day after your period ended — did it continue?"
 *                     "Bleeding on 5 Sep — the same period, or a new one?"
 *                     "Your period was due 3 days ago — has it started?"
 *                   …each with Yes / No / Not now, remembered so nothing is
 *                   asked twice. Plus Undo for delete / clear-all, a real
 *                   "Spotting" option, softer validation walls (long bleeds
 *                   and old dates save with a note instead of being refused).
 *
 * The full numbered list (103 items) is in REPORT.md next to this script.
 *
 * It does NOT need the Mood or Today kits — the cycle files it replaces are the
 * ones the app shipped with — but it must be run on the same repo they were.
 *
 * Run from anywhere:   node "<path to this folder>\apply-cycle-fixes.mjs" [repo path]
 * Defaults to the current working directory as the repo. Idempotent: a second
 * run makes no edits. Any file it replaces that is not the version it expects
 * is kept next to it as <name>.before-cycle-fixes.txt (never silently lost).
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const KIT = "Cycle fixes kit v1 (2026-09-07)";
const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(process.argv[2] ?? process.cwd());
const files = path.join(here, "files");

const ok = (m) => console.log("  \u2714 " + m);
const skip = (m) => console.log("  \u2022 " + m + " (already done)");
const note = (m) => console.log("  \u2139 " + m);
const fail = (m) => {
  console.error("  \u2716 " + m);
  process.exitCode = 1;
};

const read = (p) => fs.readFileSync(p, "utf8");
const norm = (t) => t.replace(/\r\n/g, "\n");
const isCrlf = (p) => fs.existsSync(p) && fs.readFileSync(p).includes("\r\n");
// Compared after normalising line endings and trailing whitespace at EOF, so a
// Windows checkout (CRLF, editors adding a final newline) still matches.
const md5 = (t) => crypto.createHash("md5").update(norm(t).replace(/\s+$/, "")).digest("hex");
function write(p, text, crlf) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, crlf ? text.replace(/\r?\n/g, "\r\n") : text);
}

/* Known versions of the files this kit replaces (md5 of the LF-normalised
   text) — what the app shipped with. Anything else is a local edit and gets
   backed up first. */
const KNOWN_BEFORE = {
  "src/lib/cycle/predict.ts": ["27fe7d17b483529e86b4aa174ef53fa6"],
  "src/lib/cycle/dayLogs.ts": ["ac90b263ea102f6cc3732293e5a16db9"],
  "src/lib/cycle/periodStore.ts": ["377202f23f5276b06ca250ca7ca2c8a3"],
  "src/hooks/usePeriodLog.ts": ["4d401c15432b1e3a0b5300ce12df87a1"],
  "src/components/ci/LogPanel.tsx": ["b3658cf3dbf0421bd09acc3a430a31f5"],
  "src/components/ci/CycleIntelligence.tsx": ["cbe8498d228bf5d12925858d5bddf7cc"],
  "src/components/ci/HistoryTable.tsx": ["1eea5f51f00ed2ae4e82a06a5013fb8b"],
  "src/components/ci/SyncLine.tsx": ["9b244d020383348174a9fdf254b0c3c7"],
  "src/styles/cycle2.css": ["e65045bdd378997b2417684fdb7fda48"],
  "src/routes/cycle-styles.tsx": ["34119f796a898052944bfd7a19a50e30"],
  "src/lib/cycle/cycleCloud.test.ts": ["461e47cf0f877f156cda312f5f052308"],
};

function installFile(rel) {
  const src = path.join(files, rel);
  const dst = path.join(repo, rel);
  if (!fs.existsSync(src)) return fail(`kit is missing ${rel}`);
  const next = read(src);
  if (!fs.existsSync(dst)) {
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(src, dst);
    return ok(`added ${rel}`);
  }
  const cur = read(dst);
  if (md5(cur) === md5(next)) return skip(rel);
  const known = KNOWN_BEFORE[rel] ?? [];
  if (known.length && !known.includes(md5(cur))) {
    const bak = dst + ".before-cycle-fixes.txt";
    fs.copyFileSync(dst, bak);
    note(`${rel} was not the version this kit expected \u2014 your copy is kept as ${path.basename(bak)}`);
  }
  write(dst, next, isCrlf(dst));
  ok(`updated ${rel}`);
}

console.log(`\nBloom \u2014 ${KIT} \u2192 ${repo}\n`);

/* 0. sanity — this must be the Bloom repo with the Cycle Intelligence page */
if (!fs.existsSync(path.join(repo, "package.json")) || !fs.existsSync(path.join(repo, "src/routes"))) {
  console.error("This doesn't look like the Bloom repo (no package.json + src/routes). Pass the repo path as an argument.");
  process.exit(1);
}
const needed = [
  "src/routes/cycle.tsx",
  "src/components/ci/CycleIntelligence.tsx",
  "src/components/ci/LogPanel.tsx",
  "src/lib/cycle/predict.ts",
  "src/lib/cycle/dayLogs.ts",
  "src/lib/cycle/periodStore.ts",
  "src/hooks/usePeriodLog.ts",
  "src/styles/cycle2.css",
].filter((rel) => !fs.existsSync(path.join(repo, rel)));
if (needed.length) {
  console.error("The Cycle Intelligence page isn't in this repo (missing: " + needed.join(", ") + ").");
  console.error("This kit is for the bloom-app repo (chronos-feel). Check the path and run again.");
  process.exit(1);
}

/* 1. what state is the tree in? (so "nothing changed" can never be a mystery) */
console.log("Found:");
{
  const css = norm(read(path.join(repo, "src/styles/cycle2.css")));
  const panel = norm(read(path.join(repo, "src/components/ci/LogPanel.tsx")));
  const page = norm(read(path.join(repo, "src/components/ci/CycleIntelligence.tsx")));
  const hook = norm(read(path.join(repo, "src/hooks/usePeriodLog.ts")));
  const state = (cond, yes, no) => console.log("  " + (cond ? "\u2714 " + yes : "\u2192 " + no));
  state(!/\.ci-shell \{[^}]*max-width: 1060px/.test(css), "/cycle already full width", "/cycle is still the 1060px centred column");
  state(fs.existsSync(path.join(repo, "src/lib/cycle/reconcile.ts")), "check-in engine already installed", "no check-in engine yet (nothing asks \"did the period end early?\")");
  state(panel.includes("classifyBleedDay"), "log form already understands which day of a period this is", "any bleed level still auto-ticks \"first day of a period\" (the 2-day-cycle loophole)");
  state(page.includes("<CheckIns"), "check-ins card already on the page", "no check-ins card on the page yet");
  state(hook.includes("undoable"), "undo for delete / clear already in place", "delete and \"clear all\" are still final");
  state(panel.includes('value: "spotting"'), "spotting option already present", "no spotting option yet");
}
console.log("");

/* 2. new files */
console.log("Apply:");
for (const rel of [
  "src/lib/cycle/reconcile.ts",
  "src/lib/cycle/reconcile.test.ts",
  "src/lib/cycle/predict.test.ts",
  "src/components/ci/CheckIns.tsx",
  "src/components/ci/UndoToast.tsx",
]) {
  installFile(rel);
}

/* 3. replaced files (byte-compared; local edits backed up) */
for (const rel of Object.keys(KNOWN_BEFORE)) installFile(rel);

/* 4. docs */
{
  const dst = path.join(repo, "docs/cycle-loopholes/REPORT.md");
  const src = path.join(here, "REPORT.md");
  if (fs.existsSync(src)) {
    if (fs.existsSync(dst) && md5(read(dst)) === md5(read(src))) skip("docs/cycle-loopholes/REPORT.md");
    else {
      fs.mkdirSync(path.dirname(dst), { recursive: true });
      fs.copyFileSync(src, dst);
      ok("added docs/cycle-loopholes/REPORT.md (the 103-item loophole list)");
    }
  }
}

/* 5. verify */
console.log("\nVerify:");
const checks = [
  ["src/styles/cycle2.css", "max-width: none;", "/cycle is full width"],
  ["src/styles/cycle2.css", ".ci-shell--narrow {", "design gallery keeps its centred column"],
  ["src/routes/cycle-styles.tsx", "ci-shell ci-shell--narrow", "design gallery uses the narrow shell"],
  ["src/lib/cycle/reconcile.ts", "export function reconcile(", "check-in engine installed"],
  ["src/lib/cycle/reconcile.ts", "did your period end early?", "\"did your period end early?\" question present"],
  ["src/lib/cycle/reconcile.ts", "did it continue?", "\"did it continue?\" question present"],
  ["src/lib/cycle/reconcile.ts", "has it started?", "\"has it started?\" question present"],
  ["src/lib/cycle/predict.ts", "export function assessLogDraft(", "soft warnings (save + note) installed"],
  ["src/lib/cycle/predict.ts", "export const MAX_BLEED_DAYS = 30", "bleed ceiling widened to 30 days"],
  ["src/lib/cycle/dayLogs.ts", '"spotting"', "spotting is a real flow value"],
  ["src/lib/cycle/periodStore.ts", "bloom.cycle.checkins.v1", "answers are remembered"],
  ["src/hooks/usePeriodLog.ts", "answerCheckIn", "hook applies check-in answers"],
  ["src/hooks/usePeriodLog.ts", "UNDO_WINDOW_MS", "undo window installed"],
  ["src/components/ci/LogPanel.tsx", "classifyBleedDay", "form pre-ticks \"first day\" only for a real new start"],
  ["src/components/ci/LogPanel.tsx", "log-close-period", "\"the period ended early\" tick in the form"],
  ["src/components/ci/LogPanel.tsx", "log-extend-period", "\"same period, still going\" tick in the form"],
  ["src/components/ci/CheckIns.tsx", 'data-testid="cycle-checkins"', "check-ins card component installed"],
  ["src/components/ci/UndoToast.tsx", 'data-testid="cycle-undo"', "undo strip component installed"],
  ["src/components/ci/CycleIntelligence.tsx", "<CheckIns", "check-ins card on the page"],
  ["src/components/ci/CycleIntelligence.tsx", "<UndoToast", "undo strip on the page"],
  ["src/components/ci/HistoryTable.tsx", "no last day logged", "history shows open periods honestly"],
  ["src/components/ci/SyncLine.tsx", "period dates stay on this device", "sync line says what actually syncs"],
];
for (const [rel, needle, label] of checks) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && norm(read(p)).includes(needle)) ok(label);
  else fail(`${label} \u2014 check ${rel}`);
}

if (process.exitCode) {
  console.log("\nSomething was skipped \u2014 see the \u2716 lines above. Send me this whole output.");
} else {
  console.log(`
Done. Next:
  1. Stop the dev server if it is running, then:  npm run dev
     (it regenerates src/routeTree.gen.ts on start \u2014 commit that file too).
  2. Open /cycle and hard-refresh once (Ctrl+F5). It should fill the width like
     Today. Pick "Medium" on a day inside a logged period: the form now says
     "Same period, still going" instead of ticking "first day of a period".
     Log "None" on day 2+ of an open period: it offers to close it.
  3. Optional: npx vitest run   (86 tests, 42 of them new)
  4. git add -A && git commit -m "feat(cycle): full-width page + period check-ins that close the logging loopholes" && git push
`);
}
