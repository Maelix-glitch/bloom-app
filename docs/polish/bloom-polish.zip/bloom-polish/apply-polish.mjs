#!/usr/bin/env node
/**
 * Bloom — premium polish pass (66 files, branch tip d79c746)
 *
 * Everything since the Tier B part 2 kit:
 *   · rotating copy, app-wide sound, motion primitives
 *   · premium cycle palette + wording, finished popup edges, preset avatars
 *   · the welcome/onboarding gate, cycle hidden for people who don't track one
 *   · the coach rebuilt — 30 topics, answer length matched to the question,
 *     your Supabase edge function, model picker, progressive reveal
 *   · fixes: tab-change flicker, remount lag, the mood image pinch
 *   · "Launch as admin" rebuilt as a real launcher
 *
 * Assumes your checkout is ALREADY at the Tier B part 2 kit. It checks that
 * first and stops without writing anything if something is missing.
 *
 * Idempotent: files that already match are skipped, and a file you edited
 * yourself is copied to <name>__BEFORE__ before being replaced.
 *
 * Run from anywhere:  node "<path to this folder>\apply-polish.mjs" [repo path]
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(process.argv[2] ?? process.cwd());
const files = path.join(here, "files");

const ok = (m) => console.log("  \u2714 " + m);
const skip = (m) => console.log("  \u2022 " + m + " (already done)");
const note = (m) => console.log("  \u2139 " + m);
const fail = (m) => {
  console.error("  \u2716 " + m);
  process.exitCode = 1;
};

const read = (p) => fs.readFileSync(p, "utf8");
const norm = (t) => t.replace(/\r\n/g, "\n");
const isCrlf = (p) => fs.existsSync(p) && fs.readFileSync(p).includes("\r\n");
const md5 = (t) => crypto.createHash("md5").update(norm(t).replace(/\s+$/, "")).digest("hex");
function write(p, text, crlf) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, crlf ? text.replace(/\r?\n/g, "\r\n") : text);
}

const INSTALL = [
  "src/components/ci/CycleIntelligence.tsx",
  "src/components/ci/CycleNotYours.tsx",
  "src/components/ci/SignatureStrip.tsx",
  "src/components/coach/CoachPage.tsx",
  "src/components/coach/ProviderPicker.tsx",
  "src/components/home/HomeSidebar.tsx",
  "src/components/profile/AccountRow.tsx",
  "src/components/profile/PresetPicker.tsx",
  "src/components/profile/PrivacySheet.tsx",
  "src/components/profile/ProfileAvatar.tsx",
  "src/components/profile/ProfileEditor.tsx",
  "src/components/tk/TrackersPage.tsx",
  "src/components/ui/bloom-sheet.tsx",
  "src/components/welcome/AdminBar.tsx",
  "src/components/welcome/AdminPanel.tsx",
  "src/components/welcome/Welcome.tsx",
  "src/components/welcome/WelcomeGate.tsx",
  "src/hooks/useAmbientSound.ts",
  "src/hooks/useCoachSystem.ts",
  "src/hooks/useCycleMode.ts",
  "src/hooks/useCycleVisible.ts",
  "src/hooks/useOnboarding.ts",
  "src/hooks/useRailIdentity.ts",
  "src/hooks/useSound.ts",
  "src/hooks/useTypewriter.ts",
  "src/lib/coach/breadth.test.ts",
  "src/lib/coach/brevity.test.ts",
  "src/lib/coach/brevity.ts",
  "src/lib/coach/compose.ts",
  "src/lib/coach/edge.ts",
  "src/lib/coach/engine.ts",
  "src/lib/coach/knowledge.ts",
  "src/lib/coach/providers.ts",
  "src/lib/coach/responder.ts",
  "src/lib/coach/reveal.test.ts",
  "src/lib/coach/topics.test.ts",
  "src/lib/coach/topics.ts",
  "src/lib/cycle/themes.ts",
  "src/lib/home/today.ts",
  "src/lib/onboarding/adminTargets.test.ts",
  "src/lib/onboarding/adminTargets.ts",
  "src/lib/onboarding/profileKind.test.ts",
  "src/lib/onboarding/profileKind.ts",
  "src/lib/prefsStore.test.ts",
  "src/lib/prefsStore.ts",
  "src/lib/profile/presetAvatars.test.ts",
  "src/lib/profile/presetAvatars.ts",
  "src/lib/sound/sound.test.ts",
  "src/lib/sound/sound.ts",
  "src/lib/voice/copy.ts",
  "src/lib/voice/messages.test.ts",
  "src/lib/voice/messages.ts",
  "src/routes/__root.tsx",
  "src/routes/cycle.tsx",
  "src/routes/profile.tsx",
  "src/styles.css",
  "src/styles/admin-panel.css",
  "src/styles/bloom-sheet.css",
  "src/styles/coach.css",
  "src/styles/cycle2.css",
  "src/styles/mood-motion.css",
  "src/styles/motion.css",
  "src/styles/profile.css",
  "src/styles/welcome.css",
  "supabase/functions/coach/README.md",
  "supabase/functions/coach/index.ts"
];
const KNOWN_BEFORE = {
  "src/components/ci/CycleIntelligence.tsx": [
    "861eb0a1ce675b4e8d1c7ca86104331e"
  ],
  "src/components/ci/SignatureStrip.tsx": [
    "855809bf72a4af141a1096838f651aeb"
  ],
  "src/components/coach/CoachPage.tsx": [
    "0b1048b7625808f44151d23fde51a37b"
  ],
  "src/components/home/HomeSidebar.tsx": [
    "69541f3f23ff5f552d8bb43f1fe5a36c"
  ],
  "src/components/profile/AccountRow.tsx": [
    "e77f414e784c7389c4c5b1c86c6fa61c"
  ],
  "src/components/profile/PrivacySheet.tsx": [
    "d67acf04d2ead08e9b4e901857dc1e95"
  ],
  "src/components/profile/ProfileAvatar.tsx": [
    "18fdd40488265a3da7eed88cc781bff4"
  ],
  "src/components/profile/ProfileEditor.tsx": [
    "f97df5bd4dce98acf5dd135b44b68efc"
  ],
  "src/components/tk/TrackersPage.tsx": [
    "0d26f24302d0bec13d7d10f2e8a4e1ca"
  ],
  "src/components/ui/bloom-sheet.tsx": [
    "da86684d5e214428b87c5060d2a741f1"
  ],
  "src/hooks/useCoachSystem.ts": [
    "30ba87bcccc04905ba8a5810bbf3c934"
  ],
  "src/hooks/useCycleMode.ts": [
    "10f44f0ef879d413d859a29a1ed11543"
  ],
  "src/hooks/useRailIdentity.ts": [
    "17e9f57bbd9f852b859719ef55ac9f5d"
  ],
  "src/lib/coach/responder.ts": [
    "66e9fcb99c77e260169f229cc6d72fc3"
  ],
  "src/lib/cycle/themes.ts": [
    "d722f94b77d667b1894af275954caba4"
  ],
  "src/lib/home/today.ts": [
    "7e9c9a65e23ee916d2f2a9765eb74cc4"
  ],
  "src/routes/__root.tsx": [
    "c03a400cf12d48437147f07da5dbc81d"
  ],
  "src/routes/cycle.tsx": [
    "abddcde51d8ba996b80d788e9d5c4281"
  ],
  "src/routes/profile.tsx": [
    "2a2fd5499d93dcf30015e16e9c35f0a7"
  ],
  "src/styles.css": [
    "1ecb3e4b5699c6e8525321ca0ab92872"
  ],
  "src/styles/bloom-sheet.css": [
    "199b96677969872807b639028256745e"
  ],
  "src/styles/coach.css": [
    "e4c46abeea8c5f9c0968f1b0a3dff42d"
  ],
  "src/styles/cycle2.css": [
    "f9907c3359ab136f31952e4e91decc2c"
  ],
  "src/styles/mood-motion.css": [
    "2b95e8fbe469da7d7a7d104818dd610f"
  ],
  "src/styles/profile.css": [
    "32dfdd2b988c0267133f876c96a4dfd9"
  ]
};
const PREREQS = [
  [
    "src/lib/prefs.ts",
    "export function setPref",
    "synced prefs document"
  ],
  [
    "src/lib/cycle/periodStore.ts",
    "export function effectiveMode",
    "cycle mode"
  ],
  [
    "src/components/ui/bloom-sheet.tsx",
    "BloomSheet",
    "premium sheet primitive"
  ],
  [
    "src/lib/data/erase.ts",
    "eraseEverything",
    "Tier B2 · erase"
  ],
  [
    "src/lib/reminders/schedule.ts",
    "dueReminders",
    "Tier B2 · reminders"
  ],
  [
    "src/lib/coach/responder.ts",
    "export function answer",
    "coach responder"
  ],
  [
    "src/components/coach/CoachPage.tsx",
    "CoachPage",
    "coach page"
  ],
  [
    "src/components/mood/page/MoodPage.tsx",
    "mm-hero-img",
    "mood page"
  ],
  [
    "src/hooks/useRailIdentity.ts",
    "useRailIdentity",
    "sidebar identity"
  ]
];
const CHECKS = [
  [
    "src/lib/voice/messages.ts",
    "export function pick",
    "Voice · rotation core"
  ],
  [
    "src/lib/voice/copy.ts",
    "saidSaved",
    "Voice · shared phrases"
  ],
  [
    "src/lib/home/today.ts",
    "greeting(part",
    "Voice · rotating greeting"
  ],
  [
    "src/lib/sound/sound.ts",
    "export function play",
    "Sound · engine"
  ],
  [
    "src/hooks/useAmbientSound.ts",
    "SILENT_ROUTES",
    "Sound · delegated listener, Rewards silent"
  ],
  [
    "src/routes/__root.tsx",
    "useAmbientSound",
    "Sound · wired at the root"
  ],
  [
    "src/styles/motion.css",
    "bm-press",
    "Motion · primitives"
  ],
  [
    "src/styles.css",
    "motion.css",
    "Motion · imported"
  ],
  [
    "src/styles/cycle2.css",
    "#a58bff",
    "Cycle · nocturne palette"
  ],
  [
    "src/lib/cycle/themes.ts",
    "#a58bff",
    "Cycle · palette mirrored in TS"
  ],
  [
    "src/hooks/useCycleVisible.ts",
    "optedOut",
    "Cycle · visibility model"
  ],
  [
    "src/components/ci/CycleNotYours.tsx",
    "CycleNotYours",
    "Cycle · invitation page"
  ],
  [
    "src/lib/profile/presetAvatars.ts",
    "preset:",
    "Profile · preset avatars"
  ],
  [
    "src/components/profile/PresetPicker.tsx",
    "PresetPicker",
    "Profile · avatar picker"
  ],
  [
    "src/styles/bloom-sheet.css",
    "bmoment-hero-art",
    "Popups · finished edges"
  ],
  [
    "src/components/welcome/Welcome.tsx",
    "Launch as admin",
    "Welcome · onboarding flow"
  ],
  [
    "src/components/welcome/WelcomeGate.tsx",
    "needsWelcome",
    "Welcome · gate"
  ],
  [
    "src/lib/onboarding/profileKind.ts",
    "export const isAdmin",
    "Admin · mode flag"
  ],
  [
    "src/lib/onboarding/adminTargets.ts",
    "ADMIN_TARGETS",
    "Admin · launcher targets"
  ],
  [
    "src/components/welcome/AdminPanel.tsx",
    "Admin launcher",
    "Admin · launcher panel"
  ],
  [
    "src/components/welcome/AdminBar.tsx",
    "adm-bar",
    "Admin · exit bar"
  ],
  [
    "src/routes/__root.tsx",
    "AdminBar",
    "Admin · bar mounted"
  ],
  [
    "src/styles/admin-panel.css",
    "adm-panel",
    "Admin · styles"
  ],
  [
    "src/lib/coach/topics.ts",
    "appHelp",
    "Coach · 30 topics"
  ],
  [
    "src/lib/coach/brevity.ts",
    "fitToBudget",
    "Coach · answer length"
  ],
  [
    "src/lib/coach/edge.ts",
    "askEdge",
    "Coach · edge client"
  ],
  [
    "src/lib/coach/engine.ts",
    "export async function ask",
    "Coach · engine"
  ],
  [
    "src/lib/coach/providers.ts",
    "PROVIDERS",
    "Coach · pluggable providers"
  ],
  [
    "src/hooks/useCoachSystem.ts",
    "askCoach",
    "Coach · engine wired to the UI"
  ],
  [
    "src/hooks/useTypewriter.ts",
    "useTypewriter",
    "Coach · progressive reveal"
  ],
  [
    "src/components/coach/ProviderPicker.tsx",
    "ProviderPicker",
    "Coach · model picker"
  ],
  [
    "src/components/coach/CoachPage.tsx",
    "QUICK_PROMPT_POOL",
    "Coach · wider prompts"
  ],
  [
    "src/lib/coach/knowledge.ts",
    "export const KNOWLEDGE",
    "Coach · knowledge base (25 subjects)"
  ],
  [
    "src/lib/coach/compose.ts",
    "export function compose",
    "Coach · answer composer"
  ],
  [
    "src/lib/coach/engine.ts",
    "export function isGrounded",
    "Coach · no more empty-record refusal"
  ],
  [
    "src/lib/coach/breadth.test.ts",
    "breadth",
    "Coach · breadth regression tests"
  ],
  [
    "supabase/functions/coach/index.ts",
    "COACH_MODEL",
    "Coach · edge function"
  ],
  [
    "src/lib/prefsStore.ts",
    "useSyncExternalStore",
    "Fix · no flicker on tab change"
  ],
  [
    "src/hooks/useOnboarding.ts",
    "usePrefValue",
    "Fix · onboarding reads the cache"
  ],
  [
    "src/hooks/useCycleMode.ts",
    "useSyncExternalStore",
    "Fix · cycle mode reads the cache"
  ],
  [
    "src/hooks/useRailIdentity.ts",
    "cachedIdentity",
    "Fix · rail identity cached"
  ],
  [
    "src/styles/mood-motion.css",
    "scale(1.06)",
    "Fix · mood image pinch"
  ]
];

console.log(`\nBloom \u2014 premium polish (66 files) \u2192 ${repo}\n`);

/* 0. is this the repo? */
if (!fs.existsSync(path.join(repo, "package.json")) || !fs.existsSync(path.join(repo, "src/routes"))) {
  console.error("This doesn't look like the Bloom repo (no package.json + src/routes). Pass the repo path as an argument.");
  process.exit(1);
}

/* 1. is it new enough? these files build on the earlier tiers */
console.log("Checking your checkout is at the Tier B part 2 kit:");
let missing = 0;
for (const [rel, needle, label] of PREREQS) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && norm(read(p)).includes(needle)) ok(label);
  else {
    console.error(`  \u2716 missing: ${label}  (${rel})`);
    missing += 1;
  }
}
if (missing) {
  console.error(`
${missing} thing(s) from the earlier kits are missing, so this kit would leave
the app broken \u2014 these files import them.

Apply bloom-tier-b2-slim.zip first, then run this one. Nothing has been written.`);
  process.exit(1);
}
console.log("");

/* 2. install */
console.log("Apply:");
for (const rel of INSTALL) {
  const src = path.join(files, rel);
  const dst = path.join(repo, rel);
  if (!fs.existsSync(src)) {
    fail(`kit is missing ${rel}`);
    continue;
  }
  const next = read(src);
  if (!fs.existsSync(dst)) {
    write(dst, next, false);
    ok(`added ${rel}`);
    continue;
  }
  const cur = read(dst);
  if (md5(cur) === md5(next)) {
    skip(rel);
    continue;
  }
  const known = KNOWN_BEFORE[rel] ?? [];
  if (!known.includes(md5(cur))) {
    fs.copyFileSync(dst, dst + "__BEFORE__");
    note(`${rel} had local edits \u2014 your copy is kept as ${path.basename(dst)}__BEFORE__`);
  }
  write(dst, next, isCrlf(dst));
  ok(`updated ${rel}`);
}

/* 3. verify */
console.log("\nVerify:");
for (const [rel, needle, label] of CHECKS) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && norm(read(p)).includes(needle)) ok(label);
  else fail(`${label} \u2014 check ${rel}`);
}

if (process.exitCode) {
  console.log("\nSomething was skipped \u2014 see the \u2716 lines above. Send me this whole output.");
} else {
  console.log(`
Done. Next:
  1. Stop the dev server, then: npm run dev   \u2014 hard-refresh once (Ctrl+F5)
  2. No new migrations. No new packages.
  3. Optional: npx vitest run   (368 tests / 30 files)

  Seeing it:
    \u00b7 Welcome flow \u2014 it runs on first load. To see it again later:
      the amber "Admin" bar (bottom-left) \u2192 Exit.
    \u00b7 Launch as admin \u2014 top-right of the welcome flow. Opens a launcher;
      type to filter, arrows to move, enter to go. It reaches the design
      pages nothing links to (/cycle-styles, /trackers-styles, ...).
    \u00b7 Coach \u2014 answers now reveal as they're read, and the model picker
      sits beside the ready/thinking pill. Add your key with:
        supabase functions deploy coach
        supabase secrets set OPENAI_API_KEY=...
      Without it the coach still answers, on-device.
    \u00b7 Cycle \u2014 new palette. Profile \u2192 Your Bloom to hide it entirely.
    \u00b7 Sound \u2014 on by default, and silent on Rewards as you asked.

  To remove it all again: git checkout -- . (if committed: git revert).
`);
}
