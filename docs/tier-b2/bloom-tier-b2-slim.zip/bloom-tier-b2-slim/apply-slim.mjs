#!/usr/bin/env node
/**
 * Bloom — Tier B part 2, SLIM kit (20 files, branch tip fde1e60)
 *
 * Only the files this tier touched:
 *   B4  reminders that actually fire (habits, cycle, the evening nudge)
 *   B6  installable on the phone (manifest + offline shell + install prompt)
 *   B7  "Download everything" — one file with the whole record
 *   B8  import period history from another app (with a preview)
 *   B9  erase everything — this device and the account
 *
 * This kit assumes your checkout is ALREADY at the previous kit (Tier B/C +
 * the profile redesign + premium sheets). It checks for that first and stops
 * if anything is missing — these files import things the earlier tiers added,
 * so installing them on an older tree would leave the app broken. If the check
 * stops you, use the full cumulative kit (bloom-tier-b2.zip) instead: it
 * carries every earlier file too and repairs any checkout in one run.
 *
 * Idempotent: files that already match are skipped, and a file you edited
 * yourself is copied to <name>__BEFORE__ before being replaced.
 *
 * Run from anywhere:  node "<path to this folder>\apply-slim.mjs" [repo path]
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(process.argv[2] ?? process.cwd());
const files = path.join(here, "files");

const ok = (m) => console.log("  \u2714 " + m);
const skip = (m) => console.log("  \u2022 " + m + " (already done)");
const note = (m) => console.log("  \u2139 " + m);
const fail = (m) => {
  console.error("  \u2716 " + m);
  process.exitCode = 1;
};

const read = (p) => fs.readFileSync(p, "utf8");
const norm = (t) => t.replace(/\r\n/g, "\n");
const isCrlf = (p) => fs.existsSync(p) && fs.readFileSync(p).includes("\r\n");
const md5 = (t) => crypto.createHash("md5").update(norm(t).replace(/\s+$/, "")).digest("hex");
function write(p, text, crlf) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, crlf ? text.replace(/\r?\n/g, "\r\n") : text);
}

const INSTALL = [
  "public/manifest.webmanifest",
  "public/sw.js",
  "src/components/ci/CycleIntelligence.tsx",
  "src/components/ci/HistoryTable.tsx",
  "src/components/ci/ImportPeriods.tsx",
  "src/components/profile/AccountRow.tsx",
  "src/components/profile/DataSheets.tsx",
  "src/hooks/useExportBundle.ts",
  "src/hooks/useInstallPrompt.ts",
  "src/hooks/useReminders.ts",
  "src/lib/data/erase.ts",
  "src/lib/data/exportAll.test.ts",
  "src/lib/data/exportAll.ts",
  "src/lib/data/importPeriods.test.ts",
  "src/lib/data/importPeriods.ts",
  "src/lib/reminders/schedule.test.ts",
  "src/lib/reminders/schedule.ts",
  "src/routes/__root.tsx",
  "src/routes/profile.tsx",
  "supabase/migrations/20260910_erase_account.sql"
];
const KNOWN_BEFORE = {
  "src/components/ci/CycleIntelligence.tsx": [
    "5bdb0e332197254d6febe09a7b9f242a"
  ],
  "src/components/ci/HistoryTable.tsx": [
    "2badb98a39e386d10274f9986ef6b367"
  ],
  "src/components/profile/AccountRow.tsx": [
    "578221b54970d698043c77f0901a1ea9"
  ],
  "src/routes/__root.tsx": [
    "fb7063232c6fdefb8cd4ae29954c1bc4"
  ],
  "src/routes/profile.tsx": [
    "568ce4df5f4d433ba71d404e9180be67"
  ]
};
const PREREQS = [
  [
    "src/components/ui/bloom-sheet.tsx",
    "export function BloomSheet",
    "premium sheets (BloomSheet primitive)"
  ],
  [
    "src/lib/prefs.ts",
    "export function setPref",
    "synced prefs document (C2)"
  ],
  [
    "src/lib/cycle/periodStore.ts",
    "export function effectiveMode",
    "cycle mode (B1)"
  ],
  [
    "src/hooks/useProfileSpace.ts",
    "useProfileSpace",
    "profile space hook"
  ],
  [
    "src/lib/profile/record.ts",
    "export function recordGrid",
    "redesigned profile"
  ],
  [
    "src/hooks/useTrackers.ts",
    "customSubjects",
    "trackers with active set (B2/C1)"
  ],
  [
    "src/hooks/useHabits.ts",
    "todayHabits",
    "habits store"
  ],
  [
    "src/lib/localDay.ts",
    "export function localDay",
    "local-day authority (Tier A)"
  ]
];
const CHECKS = [
  [
    "src/lib/reminders/schedule.ts",
    "export function dueReminders",
    "B4 · reminder scheduler"
  ],
  [
    "src/hooks/useReminders.ts",
    "export function useReminders",
    "B4 · reminder delivery"
  ],
  [
    "public/manifest.webmanifest",
    "shortcuts",
    "B6 · web app manifest"
  ],
  [
    "public/sw.js",
    "bloom-notify",
    "B6 · service worker"
  ],
  [
    "src/hooks/useInstallPrompt.ts",
    "beforeinstallprompt",
    "B6 · install prompt"
  ],
  [
    "src/routes/__root.tsx",
    "manifest.webmanifest",
    "B6 · manifest linked in the head"
  ],
  [
    "src/routes/__root.tsx",
    "registerServiceWorker",
    "B6 · worker registered"
  ],
  [
    "src/lib/data/exportAll.ts",
    "export function buildExport",
    "B7 · one export"
  ],
  [
    "src/hooks/useExportBundle.ts",
    "export function useExportBundle",
    "B7 · export sources"
  ],
  [
    "src/components/profile/DataSheets.tsx",
    "pf-export-all-go",
    "B7 · export sheet"
  ],
  [
    "src/lib/data/importPeriods.ts",
    "export function previewImport",
    "B8 · import parser"
  ],
  [
    "src/components/ci/ImportPeriods.tsx",
    "cycle-import-go",
    "B8 · import sheet"
  ],
  [
    "src/components/ci/HistoryTable.tsx",
    "cycle-import-open",
    "B8 · Import history button"
  ],
  [
    "src/components/ci/CycleIntelligence.tsx",
    "ImportPeriods",
    "B8 · wired into the Cycle page"
  ],
  [
    "src/lib/data/erase.ts",
    "export async function eraseEverything",
    "B9 · erase"
  ],
  [
    "src/components/profile/DataSheets.tsx",
    "pf-erase-go",
    "B9 · erase sheet"
  ],
  [
    "supabase/migrations/20260910_erase_account.sql",
    "erase_my_data",
    "B9 · erase migration"
  ],
  [
    "src/components/profile/AccountRow.tsx",
    "pf-row-reminders",
    "Profile · new settings rows"
  ],
  [
    "src/routes/profile.tsx",
    "RemindersSheet",
    "Profile · sheets mounted"
  ]
];

console.log(`\nBloom \u2014 Tier B part 2 (slim, 20 files) \u2192 ${repo}\n`);

/* 0. is this the repo? */
if (!fs.existsSync(path.join(repo, "package.json")) || !fs.existsSync(path.join(repo, "src/routes"))) {
  console.error("This doesn't look like the Bloom repo (no package.json + src/routes). Pass the repo path as an argument.");
  process.exit(1);
}

/* 1. is it new enough? these files depend on the earlier tiers */
console.log("Checking your checkout is at the previous kit:");
let missing = 0;
for (const [rel, needle, label] of PREREQS) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && norm(read(p)).includes(needle)) ok(label);
  else {
    console.error(`  \u2716 missing: ${label}  (${rel})`);
    missing += 1;
  }
}
if (missing) {
  console.error(`
${missing} thing(s) from the earlier kits are missing, so this slim kit would
leave the app broken \u2014 the new files import them.

Use the full kit instead:  bloom-tier-b2.zip \u2192 node apply-tier-b2.mjs
It contains every earlier file as well and brings any checkout up to date in
one run. Nothing has been written.`);
  process.exit(1);
}
console.log("");

/* 2. install */
console.log("Apply:");
for (const rel of INSTALL) {
  const src = path.join(files, rel);
  const dst = path.join(repo, rel);
  if (!fs.existsSync(src)) {
    fail(`kit is missing ${rel}`);
    continue;
  }
  const next = read(src);
  if (!fs.existsSync(dst)) {
    write(dst, next, false);
    ok(`added ${rel}`);
    continue;
  }
  const cur = read(dst);
  if (md5(cur) === md5(next)) {
    skip(rel);
    continue;
  }
  const known = KNOWN_BEFORE[rel] ?? [];
  if (!known.includes(md5(cur))) {
    fs.copyFileSync(dst, dst + "__BEFORE__");
    note(`${rel} had local edits \u2014 your copy is kept as ${path.basename(dst)}__BEFORE__`);
  }
  write(dst, next, isCrlf(dst));
  ok(`updated ${rel}`);
}

/* 3. the report, for reference */
{
  const src = path.join(here, "REPORT.md");
  const dst = path.join(repo, "docs/tier-b2/REPORT.md");
  if (fs.existsSync(src)) {
    if (fs.existsSync(dst) && md5(read(dst)) === md5(read(src))) skip("docs/tier-b2/REPORT.md");
    else {
      fs.mkdirSync(path.dirname(dst), { recursive: true });
      fs.copyFileSync(src, dst);
      ok("added docs/tier-b2/REPORT.md");
    }
  }
}

/* 4. verify */
console.log("\nVerify:");
for (const [rel, needle, label] of CHECKS) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && norm(read(p)).includes(needle)) ok(label);
  else fail(`${label} \u2014 check ${rel}`);
}

if (process.exitCode) {
  console.log("\nSomething was skipped \u2014 see the \u2716 lines above. Send me this whole output.");
} else {
  console.log(`
Done. Next:
  1. npm install            (no new packages, but the lockfile may refresh)
  2. Stop the dev server, then: npm run dev   \u2014 hard-refresh once (Ctrl+F5)
  3. Supabase \u2192 SQL editor: run migrations/20260910_erase_account.sql
     (the ONLY new migration; everything else already ran with the last kit.
      Only the Erase button needs it \u2014 B4/B6/B7/B8 need no SQL.)
  4. Optional: npx vitest run   (229 tests / 20 files)
  5. git add -A && git commit -m "feat: Tier B part 2" && git push

  Trying it out:
    \u00b7 Reminders  \u2014 Profile \u2192 Account & data \u2192 "Remind me" \u2192 allow \u2192 "Show me one"
    \u00b7 Install    \u2014 same sheet (needs https or localhost)
    \u00b7 Export     \u2014 Profile \u2192 "Download everything"
    \u00b7 Import     \u2014 Cycle \u2192 "Every entry you've logged" \u2192 "Import history"
    \u00b7 Erase      \u2014 Profile \u2192 "Erase everything" (type: erase everything)
`);
}
