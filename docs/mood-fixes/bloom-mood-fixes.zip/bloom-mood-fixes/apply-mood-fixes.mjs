#!/usr/bin/env node
/**
 * Bloom — Mood fixes kit (v1, 2026-09-07)
 *
 * A separate, focused kit for the three problems on /mood and
 * /mood/intelligence, plus the mood web:
 *
 *   1. Width    — both pages run edge to edge, same margins as Today.
 *   2. Flicker  — one shared mood record per session; no spinner / redraw
 *                 when moving between /, /mood and /mood/intelligence.
 *   3. Lag      — lighter background layer, no idle shimmer, memoised
 *                 Intelligence panels, cheaper chart, hover-preloaded routes.
 *   4. Mood web — the connection map under "Your mood journey".
 *
 * It does NOT install the Mood page itself — it needs the Mood-page kit (v1 or
 * later) to be applied already, and it never touches the home page.
 *
 * Run from anywhere:   node "<path to this folder>\apply-mood-fixes.mjs" [repo path]
 * Defaults to the current working directory as the repo. Idempotent: a second
 * run makes no edits. Any file it replaces that is not the version it expects
 * is kept next to it as <name>.before-mood-fixes.txt (never silently lost).
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const KIT = "Mood fixes kit v1 (2026-09-07)";
const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(process.argv[2] ?? process.cwd());
const files = path.join(here, "files");

const ok = (m) => console.log("  \u2714 " + m);
const skip = (m) => console.log("  \u2022 " + m + " (already done)");
const note = (m) => console.log("  \u2139 " + m);
const fail = (m) => {
  console.error("  \u2716 " + m);
  process.exitCode = 1;
};

const read = (p) => fs.readFileSync(p, "utf8");
const norm = (t) => t.replace(/\r\n/g, "\n");
const isCrlf = (p) => fs.existsSync(p) && fs.readFileSync(p).includes("\r\n");
// Compared after normalising line endings and trailing whitespace at EOF, so a
// Windows checkout (CRLF, editors adding a final newline) still matches.
const md5 = (t) => crypto.createHash("md5").update(norm(t).replace(/\s+$/, "")).digest("hex");
function write(p, text, crlf) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, crlf ? text.replace(/\r?\n/g, "\r\n") : text);
}

/* Known versions of the files this kit replaces (md5 of the LF-normalised
   text). "before" = what the Mood-page kit v1 / the app shipped; "after" = this
   kit's copy. Anything else is a local edit and gets backed up first. */
const KNOWN_BEFORE = {
  "src/components/mood/page/MoodPage.tsx": ["92305c751e1971a4d9e53b3c6c0f8346"],
  "src/routes/mood/intelligence.tsx": ["7e1af07266f74f44072c07f0609aa35e"],
  "src/hooks/useMoodSystem.ts": [
    "aec5c790338fa9fd6e59629b54ef885d", // after the Today-home kit's guard
    "611b1c5acc4a1646b3dc3996b7520451", // original app file
  ],
  "src/components/mood/primitives.tsx": ["424d3d9e347dc0e40caf4654f25f20d5"],
  "src/components/mood/Atmosphere.tsx": ["f89d4e87078586ea8d89bb6950137ff8"],
  "src/components/mood/MoodChart.tsx": ["703aac4e0a201cdf74541c46c8034914"],
  "src/components/mood/History.tsx": ["afb93675684689eae712107104c6980c"],
  "src/components/mood/Calendar.tsx": ["03041dc368c335abc4a7f0c3cfa8f5b9"],
  "src/components/mood/Correlations.tsx": ["0ced19c605dc290219b2f14086672597"],
  "src/components/mood/Heatmap.tsx": ["1ef8ca80e775cda55532f8287cb0edb7"],
  "src/components/mood/Timeline.tsx": ["e8463e3171b2f4fd39e544b262179785"],
  "src/components/mood/Distribution.tsx": ["282353db2e50eff7bbec30f2c1dcc552"],
  "src/components/mood/Insights.tsx": ["b659517e1de1ad52180bc66c70dbfa78"],
  "src/components/mood/Emotions.tsx": ["33a76cd68517329ef02f2d6edf58f8a9"],
  "src/components/mood/Patterns.tsx": ["8e9f3d17e0d297c71a766c953bf6eb08"],
};

function installFile(rel) {
  const src = path.join(files, rel);
  const dst = path.join(repo, rel);
  if (!fs.existsSync(src)) return fail(`kit is missing ${rel}`);
  const next = read(src);
  if (!fs.existsSync(dst)) {
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(src, dst);
    return ok(`added ${rel}`);
  }
  const cur = read(dst);
  if (md5(cur) === md5(next)) return skip(rel);
  const known = KNOWN_BEFORE[rel] ?? [];
  if (known.length && !known.includes(md5(cur))) {
    const bak = dst + ".before-mood-fixes.txt";
    fs.copyFileSync(dst, bak);
    note(`${rel} was not the version this kit expected \u2014 your copy is kept as ${path.basename(bak)}`);
  }
  write(dst, next, isCrlf(dst));
  ok(`updated ${rel}`);
}

function patch(rel, edits) {
  const p = path.join(repo, rel);
  if (!fs.existsSync(p)) return fail(`${rel} not found`);
  const crlf = isCrlf(p);
  let text = norm(read(p));
  let changed = 0;
  for (const e of edits) {
    if (e.marker && text.includes(e.marker)) continue;
    if (!text.includes(e.from)) {
      fail(`${rel}: anchor not found for "${e.name}"`);
      continue;
    }
    text = text.replace(e.from, e.to);
    changed++;
  }
  if (changed === 0) return skip(rel);
  write(p, text, crlf);
  ok(`patched ${rel}`);
}

/* The fixed file mentions "<Atmosphere />" inside a comment explaining why it
   is gone — only an actual import counts as "still in use". */
const usesAtmosphere = (text) => /^import \{ Atmosphere \}/m.test(text);

console.log(`\nBloom \u2014 ${KIT} \u2192 ${repo}\n`);

/* 0. sanity — the Mood page must already be installed */
if (!fs.existsSync(path.join(repo, "package.json")) || !fs.existsSync(path.join(repo, "src/routes"))) {
  console.error("This doesn't look like the Bloom repo (no package.json + src/routes). Pass the repo path as an argument.");
  process.exit(1);
}
const needsMoodKit = [
  "src/routes/mood/index.tsx",
  "src/components/mood/page/MoodPage.tsx",
  "src/routes/mood/intelligence.tsx",
  "src/components/home/HomeSidebar.tsx",
].filter((rel) => !fs.existsSync(path.join(repo, rel)));
const css0 = fs.existsSync(path.join(repo, "src/styles.css")) ? norm(read(path.join(repo, "src/styles.css"))) : "";
if (needsMoodKit.length || !css0.includes(".mood-page {") || !css0.includes("--color-gold:")) {
  console.error("The Mood page itself isn't installed yet (missing: " + (needsMoodKit.join(", ") || "its styles") + ").");
  console.error("Apply the Mood-page kit first, then run this one:\n  https://github.com/Maelix-glitch/bloom-app/raw/arena/01a0702b-bloom-app/docs/mood-page/bloom-mood-page.zip");
  process.exit(1);
}
if (fs.existsSync(path.join(repo, "src/routes/mood.tsx"))) {
  fail("src/routes/mood.tsx still exists next to src/routes/mood/ \u2014 it registers /mood twice. Run the Mood-page kit again (it moves it), then re-run this.");
}

/* 1. what state is the tree in? (so "nothing changed" can never be a mystery) */
console.log("Found:");
{
  const mp = norm(read(path.join(repo, "src/components/mood/page/MoodPage.tsx")));
  const it = norm(read(path.join(repo, "src/routes/mood/intelligence.tsx")));
  const hook = norm(read(path.join(repo, "src/hooks/useMoodSystem.ts")));
  const state = (cond, yes, no) => console.log("  " + (cond ? "\u2714 " + yes : "\u2192 " + no));
  state(mp.includes("lg:px-10 lg:pt-7"), "/mood already full width", "/mood is still the narrow centred column");
  state(it.includes("lg:px-10 lg:pb-24 lg:pt-7"), "/mood/intelligence already full width", "/mood/intelligence is still the narrow column");
  state(hook.includes("moodRecord"), "shared mood record already in use", "each page still loads the record on its own (the flicker)");
  state(!usesAtmosphere(it), "Intelligence already free of the invisible background layer", "the invisible background layer still runs on Intelligence (lag)");
  state(mp.includes("<MoodGraph"), "mood web already on /mood", "no mood web on /mood yet");
}
console.log("");

/* 2. new files */
console.log("Apply:");
for (const rel of [
  "src/lib/mood/record.ts",
  "src/lib/mood/graph.ts",
  "src/lib/mood/graph.test.ts",
  "src/components/mood/page/MoodGraph.tsx",
]) {
  installFile(rel);
}

/* 3. replaced files (byte-compared; local edits backed up) */
for (const rel of Object.keys(KNOWN_BEFORE)) installFile(rel);

/* 4. hover-preload route chunks */
patch("src/router.tsx", [
  {
    name: "defaultPreload intent",
    marker: 'defaultPreload: "intent"',
    from: "    defaultPreloadStaleTime: 0,",
    to:
      "    // Fetch a route's code chunk as soon as a link to it is hovered/focused,\n" +
      "    // so the page is already in memory by the time it is clicked (the\n" +
      '    // "click \u2192 wait" on /mood \u2192 /mood/intelligence was the chunk download).\n' +
      '    defaultPreload: "intent",\n' +
      "    defaultPreloadStaleTime: 0,",
  },
]);

/* 5. styles: the .mood-reveal rule + the scoped Mood-web block */
{
  const p = path.join(repo, "src/styles.css");
  const crlf = isCrlf(p);
  let text = norm(read(p));
  const added = [];
  if (!text.includes(".mood-reveal {")) {
    const block = read(path.join(files, "mood-reveal-styles.css"));
    const sheenComment = "/* One wide band of light that crosses a panel on a slow idle cycle. */\n@utility sheen-band {";
    const sheen = "@utility sheen-band {";
    if (text.includes(sheenComment)) text = text.replace(sheenComment, block + sheenComment);
    else if (text.includes(sheen)) text = text.replace(sheen, block + sheen);
    else text = text.replace(/\s*$/, "\n\n") + block;
    added.push("the .mood-reveal rule");
  }
  if (!text.includes(" * Mood web \u2014")) {
    const block = read(path.join(files, "mood-web-styles.css"));
    const shellBanner = "/* ---------------------------------------------------------------------------\n * App shell \u2014";
    const at = text.indexOf(shellBanner);
    text = at === -1 ? text.replace(/\s*$/, "\n\n") + block : text.slice(0, at) + block + text.slice(at);
    added.push("the Mood-web block");
  }
  if (added.length === 0) skip("src/styles.css");
  else {
    write(p, text, crlf);
    ok(`src/styles.css: added ${added.join(" and ")}`);
  }
}

/* 6. verify */
console.log("\nVerify:");
const checks = [
  ["src/components/mood/page/MoodPage.tsx", "lg:px-10 lg:pt-7", "/mood is full width"],
  ["src/routes/mood/intelligence.tsx", "lg:px-10 lg:pb-24 lg:pt-7", "/mood/intelligence is full width"],
  ["src/lib/mood/record.ts", "export const moodRecord", "shared mood record installed"],
  ["src/hooks/useMoodSystem.ts", "moodRecord", "mood hook reads the shared record (no reload flicker)"],
  ["src/components/mood/primitives.tsx", "mood-reveal", "CSS-only reveal (no blank first paint)"],
  ["src/styles.css", ".mood-reveal {", "reveal styles present"],
  ["src/components/mood/Atmosphere.tsx", "Array.from({ length: 8 }", "lighter background layer"],
  ["src/components/mood/History.tsx", "memo(", "Intelligence panels memoised"],
  ["src/components/mood/MoodChart.tsx", "replaceMerge", "chart merge-updates"],
  ["src/router.tsx", 'defaultPreload: "intent"', "routes preload on hover"],
  ["src/lib/mood/graph.ts", "export function buildMoodGraph", "mood web model installed"],
  ["src/components/mood/page/MoodGraph.tsx", 'data-testid="mood-graph"', "mood web component installed"],
  ["src/components/mood/page/MoodPage.tsx", "<MoodGraph", "mood web on /mood"],
  ["src/routes/mood/intelligence.tsx", 'id="relationships"', "deep link target for the mood web"],
  ["src/styles.css", " * Mood web \u2014", "mood web styles present"],
];
for (const [rel, needle, label] of checks) {
  const p = path.join(repo, rel);
  if (fs.existsSync(p) && norm(read(p)).includes(needle)) ok(label);
  else fail(`${label} \u2014 check ${rel}`);
}
{
  const it = norm(read(path.join(repo, "src/routes/mood/intelligence.tsx")));
  if (usesAtmosphere(it)) fail("the invisible background layer is still on Intelligence");
  else ok("no invisible background layer on Intelligence");
}

if (process.exitCode) {
  console.log("\nSomething was skipped \u2014 see the \u2716 lines above. Send me this whole output.");
} else {
  console.log(`
Done. Next:
  1. Stop the dev server if it is running, then:  npm run dev
     (it regenerates src/routeTree.gen.ts on start \u2014 commit that file too).
  2. Open /mood and hard-refresh once (Ctrl+F5). It should fill the width like
     Today, with "Your mood web" under the journey. Move between /, /mood and
     /mood/intelligence \u2014 no spinner, no flash.
  3. git add -A && git commit -m "fix(mood): full-width pages, no reload flicker, lighter motion, mood web" && git push
`);
}
